<?php

define('ERR_SESSION_EXPIRED', 1);

define('ERR_UNKNOWN', 2);

?>
