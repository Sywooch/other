function getStatistic() {
    $.post(
        'index.php?cmd=Reports&do=getStatistic',
        {},
        function (data) {
            if (! data.error) {
                $('#CallCount').html(sdf_FTS(data.CallCount, 0, ' '));
                $('#DailyCallCount').html(sdf_FTS(data.DailyCallCount, 0, ' '));
                $('#MonthlyCallCount').html(sdf_FTS(data.MonthlyCallCount, 0, ' '));

                $('#TotalLengthTranslatedTextsDailyCallCount').html(sdf_FTS(data.TotalLengthTranslatedTextsDailyCallCount, 0, ' '));
                $('#TotalLengthTranslatedTextsMonthlyCallCount').html(sdf_FTS(data.TotalLengthTranslatedTextsMonthlyCallCount, 0, ' '));
                $('#TotalLengthTranslatedTextsTotalCallCount').html(sdf_FTS(data.TotalLengthTranslatedTextsTotalCallCount, 0, ' '));

                $('#LengthExternalTranslatedTextsDailyCallCount').html(sdf_FTS(data.LengthExternalTranslatedTextsDailyCallCount, 0, ' '));
                $('#LengthExternalTranslatedTextsMonthlyCallCount').html(sdf_FTS(data.LengthExternalTranslatedTextsMonthlyCallCount, 0, ' '));
                $('#LengthExternalTranslatedTextsTotalCallCount').html(sdf_FTS(data.LengthExternalTranslatedTextsTotalCallCount, 0, ' '));

                $('#CachedDailyCallCount').html(data.CachedDailyCallCount.toFixed(2) + '%');
                $('#CachedMonthlyCallCount').html(data.CachedMonthlyCallCount.toFixed(2) + '%');
                $('#CachedTotalCount').html(data.CachedTotalCount.toFixed(2) + '%');
            } else {
                showError(data);
            }
        }, 'json'
    );
}

setInterval(getStatistic, 5000);
