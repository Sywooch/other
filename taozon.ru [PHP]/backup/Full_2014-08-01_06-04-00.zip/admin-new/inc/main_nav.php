<?php
$request = new RequestWrapper();
$cmd = $request->getValue('cmd') ? ucfirst($request->getValue('cmd')) : Permission::default_cmd();
$action = $request->getValue('do');
$url = new AdminUrlWrapper();
$url->Set("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");

$adminStructure = simplexml_load_file(dirname(dirname(__FILE__)) . '/cfg/admin_structure.xml');
$currentAdminPartXPath = $adminStructure->xpath('//part/page[@cmd="'.strtolower($cmd).'" and (@do="*" or @do="'.$action.'")]/..');
$currentAdminPart = (string)$currentAdminPartXPath[0]['name'];
?>

<!--<li data-route="orders" class="disabled"><a data-href="<?/*=$url->AssignClearCmd('toolbar')*/?>"><i class="icon-home"></i><?/*=LangAdmin::get('Toolbar')*/?></a></li>-->

<li data-route="orders"><a href="<?=$url->AssignClearCmd('orders')?>"><i class="icon-shopping-cart"></i><span class="hidden-tablet"> <?=LangAdmin::get('Orders')?></span></a></li>

<li data-route="pricing"><a href="<?=$url->AssignClearCmd('pricing')?>"><i class="icon-">＄</i><?=LangAdmin::get('Pricing')?></a></li>

<li data-route="promo"><a href="<?=$url->AssignClearCmd('promo')?>"><i class="icon-flag"></i><?=LangAdmin::get('Seo')?></a></li>

<li data-route="contents"><a href="<?=$url->AssignClearCmd('contents')?>"><i class="icon-file"></i><?=LangAdmin::get('Contents')?></a></li>

<li data-route="catalog"><a href="<?=$url->AssignClearCmd('categories')?>"><i class="icon-list-alt"></i><span class="hidden-tablet"> <?=LangAdmin::get('Catalog')?></span></a></li>

<li data-route="users"><a href="<?=$url->AssignClearCmd('users')?>"><i class="icon icon-black icon-group"></i><?=LangAdmin::get('Users')?></a></li>

<li data-route="site_configuration"><a href="<?=$url->AssignClearCmd('SiteConfiguration')?>"><i class="icon-wrench"></i><?=LangAdmin::get('Configuration')?></a></li>

<li data-route="reports"><a href="<?=$url->AssignClearCmd('Reports')?>"><i class="icon-bar-chart"></i><?=LangAdmin::get('Reports')?></a></li>

<!-- 
<? if (CMS::IsFeatureEnabled('ReferralProgram')) { ?>
    <li data-route="referral" <? if($url->GetCmd() == 'referral') {?>class="active"<?}?>>
        <a href="<?=$url->AssignClearCmd('referral')?>"><i class="icon icon-black icon-plus"></i><span class="hidden-tablet"> <?=LangAdmin::get('Referral_system')?></span></a>
    </li>
<? } ?>
-->

<?=Plugins::invokeEvent('onAdminNewMainMenuRender', array('url' => $url))?>

<script>
    $('[data-route="<?=$currentAdminPart?>"]').addClass('active');
</script>
