<?php

class InstanceOptionsInfo
{
    /**
     * @var OTAPILib
     */
    protected $otapilib;

    /**
     * @param OTAPILib $otapilib
     */
    public function __construct($otapilib)
    {
        $this->otapilib = $otapilib;
    }

    /**
     * @param $data
     * @return stdClass
     */
    public function prepareTariff($data)
    {
        $result = new stdClass();
        $data = $data['Tariff'];

        $result->Id = $data['Id'];
        $result->Name = $data['Name'];
        $result->IsEnabled = $data['IsEnabled'];
        $result->CallLimit = $data['CallLimit'];
        $result->CallPrice = round($data['CallPrice'], 2);
        $result->TurnoverPercent = round($data['TurnoverPercent'], 2);

        return $result;
    }

    public function GetTariff($sid)
    {
        return $this->prepareTariff($this->otapilib->GetInstanceOptionsInfo($sid));
    }
}