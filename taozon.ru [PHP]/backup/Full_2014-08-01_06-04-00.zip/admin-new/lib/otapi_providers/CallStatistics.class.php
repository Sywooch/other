<?php

class CallStatistics
{
    /**
     * @var OTAPILib
     */
    protected $otapilib;

    /**
     * @param OTAPILib $otapilib
     */
    public function __construct($otapilib)
    {
        $this->otapilib = $otapilib;
    }

    /**
     * @param $data
     * @return array
     */
    private function prepareCallStatistic($data)
    {
        $result = array();

        $result['DailyCallCount'] = $data['DailyCallCount'];
        $result['MonthlyCallCount'] = $data['MonthlyCallCount'];
        $result['CallCount'] = $data['CallCount'];

        $translatorInfoByTime = $data['TotalLengthTranslatedTexts']['StatisticsByTimePeriod'];
        $result['TotalLengthTranslatedTextsTotalCallCount'] = $data['TotalLengthTranslatedTexts']['TotalCount'];
        $result['TotalLengthTranslatedTextsDailyCallCount'] = $translatorInfoByTime['DailyCallCount'];
        $result['TotalLengthTranslatedTextsMonthlyCallCount'] = $translatorInfoByTime['MonthlyCallCount'];

        $externalTranslatorInfoByTime = $data['LengthExternalTranslatedTexts']['StatisticsByTimePeriod'];
        $result['LengthExternalTranslatedTextsTotalCallCount'] = $data['LengthExternalTranslatedTexts']['TotalCount'];
        $result['LengthExternalTranslatedTextsDailyCallCount'] = $externalTranslatorInfoByTime['DailyCallCount'];
        $result['LengthExternalTranslatedTextsMonthlyCallCount'] = $externalTranslatorInfoByTime['MonthlyCallCount'];

        $cachedAdapter = $data['CachedAdapterCalltatistics'];
        $adapter = $data['AdapterCalltatistics'];
        if ($cachedAdapter['StatisticsByTimePeriod']['DailyCallCount'] != 0) {
            $result['CachedDailyCallCount'] = round(100-($adapter['StatisticsByTimePeriod']['DailyCallCount']/$cachedAdapter['StatisticsByTimePeriod']['DailyCallCount']), 2);
        } else {
            $result['CachedDailyCallCount'] = 0;
        }
        if ($cachedAdapter['StatisticsByTimePeriod']['MonthlyCallCount'] != 0) {
            $result['CachedMonthlyCallCount'] = round(100-($adapter['StatisticsByTimePeriod']['MonthlyCallCount']/$cachedAdapter['StatisticsByTimePeriod']['MonthlyCallCount']), 2);
        } else {
            $result['CachedMonthlyCallCount'] = 0;
        }        
        $result['CachedTotalCount'] = round(100-($adapter['TotalCount']/$cachedAdapter['TotalCount']), 2);

        return $result;
    }

    public function getCallStatistics()
    {
        return $this->prepareCallStatistic($this->otapilib->GetCallStatistics());
    }
}
