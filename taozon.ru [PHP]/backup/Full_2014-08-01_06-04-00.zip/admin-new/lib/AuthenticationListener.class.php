<?php

class AuthenticationListener {
    protected $otapilib;

    public function __construct(){
        global $otapilib;
        $this->otapilib = $otapilib;
        $this->otapilib->setErrorsAsExceptionsOn();
    }

    /**
     * @param RequestWrapper $request
     */
    public function CheckAuthentication($request){
        if(!$this->IsAuthenticated($request)){
            $pageUrl = new AdminUrlWrapper();
            $pageUrl->Set("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
            $pageUrl->Add('cmd', 'Login')->DeleteKey('do')->DeleteKey('expired');
            $request->LocationRedirect($pageUrl->Get());
        }
    }

    /**
     * @param RequestWrapper $request
     * @throws Exception
     */
    public function CheckAuthenticationWithException($request){
        if(!$this->IsAuthenticated($request)){
            throw new Exception('session expired');
        }
    }

    /**
     * @param RequestWrapper $request
     */
    public function Authenticate($request){
        $authResult = $this->otapilib->AuthenticateInstanceOperator($request->post('login'), $request->post('password'));
        Session::set('sid', (string)$authResult['SessionId']);
    }

    /**
     * @param RequestWrapper $request
     */
    public function Logout($request){
        $this->ClearSession();
        $this->CheckAuthentication($request);
    }

    /**
     * @param RequestWrapper $request
     * @return bool
     */
    public function IsAuthenticated($request){
        if($request->valueExists('expired'))
            $this->ClearSession();
        return Session::get('sid') && !$request->valueExists('expired');
    }

    public function ClearSession(){
        Session::set('sid', false);
    }
}