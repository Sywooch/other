<?php

OTBase::import('system.uploader.php.UploadHandler');
OTBase::import('system.lib.Validation.*');
OTBase::import('system.lib.Validation.Rules.*');

class SiteConfiguration extends GeneralUtil
{
    protected $_template = 'site_construction';
    protected $_template_path = 'site_config/';
    /**
     * @var SiteConfigurationRepository
     */
    protected $siteConfigRepository;
    /**
     * @var OrderSettings
     */
    protected $orderSettings;
    /**
     * @var ShipmentProvider
     */
    protected $shipmentProvider;

    /**
     * @var TranslationsRepository
     */
    protected $translationsRepository;

    public function __construct()
    {
        parent::__construct();
        $this->cms->checkTable('site_config');
        $this->cms->checkTable('site_langs');
        $this->siteConfigRepository = new SiteConfigurationRepository($this->cms);
        $this->orderSettings = new OrderSettings();
        $this->shipmentProvider = new ShipmentProvider();
        $this->translationsRepository = new TranslationsRepository($this->cms);
    }

    public function defaultAction($request)
    {
        $this->assignSiteConfig();
        $this->assignSearchProvidersConfig();
        $this->assignAvailableSiteThemes();

        print $this->fetchTemplate();
    }

    public function getConfigInJSAction()
    {
        $this->_template_path = 'site_config/';
        $this->_template = 'config_js';
        $this->assignSiteConfig();
        print $this->fetchTemplateWithoutHeaderAndFooter();
    }

    public function ordersAction($request)
    {
        $this->_template_path = 'site_config/orders/';
        $this->_template = 'general';
        try {
            $this->tpl->assign('OrderSettings', $this->orderSettings->Get());
            $this->tpl->assign('Showcase', $this->shipmentProvider->GetShowCase());
        }
        catch (Exception $e) {
            $this->tpl->assign('OrderSettings', false);
            $this->tpl->assign('Showcase', false);
            ErrorHandler::registerError($e);
        }
        $this->langRepository = new LanguageRepository($this->cms);
        $CMSLanguages = $this->langRepository->GetLanguages();
        $langCodes = array();
        foreach ($CMSLanguages as $l) {
            $langCodes[] = $l['lang_code'];
        }
        $this->tpl->assign('langCodes', $langCodes);
        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    public function bankAction($request)
    {
        $this->_template_path = 'site_config/orders/';
        $this->_template = 'bank';

        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    public function saveLogoAction($request)
    {
        try {
            if ($request->getValue('delete_logo')) {
                $this->siteConfigRepository->Set('logo', '');
                $logoUrl = '/i/logo.png';
            } else {
                if (empty($_FILES['uploaded_logo']['tmp_name'])) {
                    $this->respondAjaxError('No image was selected to upload.');
                }
                $uploadResult = $this->uploadImage();
                if (isset($uploadResult['uploaded_logo'][0])) {
                    if (isset($uploadResult['uploaded_logo'][0]->url)) {
                        $logoUrl = $uploadResult['uploaded_logo'][0]->url;
                        $this->siteConfigRepository->Set('logo', $logoUrl);
                    } else if (isset($uploadResult['uploaded_logo'][0]->error)) {
                        $this->respondAjaxError($uploadResult['uploaded_logo'][0]->error);
                    }
                } else {
                    $this->respondAjaxError('Unknown error occured while uploading image. Try again.');
                }
            }
        } catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse(array(
            'logoUrl' => $logoUrl,
        ));
    }

    public function systemAction()
    {
        $this->_template_path = 'site_config/system/';
        $this->_template = 'general';

        $this->assignSiteConfig();

        print $this->fetchTemplate();
    }

    private function assignSiteConfig()
    {
        $this->siteConfigRepository->SetActiveLang(Session::get('active_lang_siteconfiguration'));

        $this->tpl->assign('Config', $this->siteConfigRepository);
    }

    private function assignSearchProvidersConfig()
    {
        try {
            $searchMethods = $this->otapilib->GetProviderSearchMethodInfoList();
        } catch (ServiceException $e) {
            $searchMethods = array();
            Session::setError($e->getMessage(), $e->getErrorCode());
        }

        $newSearchMethods = array();
        foreach ($searchMethods as $method) {
            $newSearchMethods[] = $method['Provider'] . '_' . $method['SearchMethod'];
        }

        $usedSearchSettings = General::getConfigValue('orderSearchMethods') ?
            unserialize(General::getConfigValue('orderSearchMethods')) :
            $newSearchMethods;

        $unUsedSearchSettings = unserialize(General::getConfigValue('orderUnUsedSearchMethods'));
        $unUsedSearchSettings = is_array($unUsedSearchSettings) ? array_unique($unUsedSearchSettings) : array();

        $newSearchSettings = array();
        foreach ($newSearchMethods as $type) {
            if ((! in_array($type, (array)$usedSearchSettings)) && (! in_array($type, (array)$unUsedSearchSettings))) {
                $newSearchSettings[] = $type;
            }
        }
        if (count($newSearchSettings)) {
            $usedSearchSettings = array_merge((array)$usedSearchSettings, ($newSearchSettings));
        }
        foreach ($usedSearchSettings as &$searchType) {
            $searchType = str_replace('Taobao_Extended', 'China_Other', $searchType);
            $searchType = str_replace('Taobao', 'China', $searchType);
        }
        if (is_array($unUsedSearchSettings)) {
            foreach ($unUsedSearchSettings as &$searchType) {
                $searchType = str_replace('Taobao_Extended', 'China_Other', $searchType);
                $searchType = str_replace('Taobao', 'China', $searchType);
            }
        }
        $this->tpl->assign('usedSearchSettings', $usedSearchSettings);
        $this->tpl->assign('unUsedSearchSettings', $unUsedSearchSettings);
    }

    private function assignAvailableSiteThemes(){
        $themes = array();
        $themes[] = array(
            'image' => 'css/theme-default.jpg',
            'image_preview' => 'css/theme-default-preview.jpg',
            'name' => '',
            'title' => 'Стандарт',
        );
        foreach (glob(CFG_APP_ROOT . '/css/theme/*') as $themeDir) {
            $themeDirInfo = pathinfo($themeDir);
            $themes[] = array(
                'image' => 'css/theme/' . $themeDirInfo['filename'] . '/' . $themeDirInfo['filename'] . '.jpg',
                'image_preview' => 'css/theme/' . $themeDirInfo['filename'] . '/' . $themeDirInfo['filename'] . '-preview.jpg',
                'name' => $themeDirInfo['filename'],
                'title' => file_get_contents($themeDir . '/name.txt'),
            );
        }
        $this->tpl->assign('availableSiteThemes', $themes);
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveAction($request)
    {
        $this->siteConfigRepository->SetActiveLang(Session::get('active_lang_siteconfiguration'));
        $this->siteConfigRepository->Set($request->getValue('name'), $request->getValue('value'));

        $name = explode('_', $request->getValue('name'));
        foreach ($name as &$n) {
            $n = ucfirst($n);
        }
        $name = implode('', $name);
        if (method_exists($this, 'on' . $name . 'Save')) {
            call_user_func(array($this, 'on' . $name . 'Save'));
        }
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveOrderSettingsAction($request)
    {
        $this->orderSettings->Set($request->getValue('name'), $request->getValue('value'));
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveShowcaseAction($request)
    {
        $request->set($request->getValue('name'), $request->getValue('value'));
        $this->shipmentProvider->SaveCase($request);
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveBankAction($request)
    {
        $bankForm = $request->getValue('bank');
        if (! is_array($bankForm)) {
            $this->respondAjaxError('Invalid form data given.');
        }
        $validator = new Validator(array(
            'name_of_payee'              => $bankForm['name_of_payee'],
            'INN_of_payee'               => $bankForm['INN_of_payee'],
            'account_number_of_payee'    => $bankForm['account_number_of_payee'],
            'bank_name_of_payee'         => $bankForm['bank_name_of_payee'],
            'bank_identification_code'   => $bankForm['bank_identification_code'],
            'correspondent_bank_account' => $bankForm['correspondent_bank_account'],
            'description_of_payment'     => $bankForm['description_of_payment']
        ));
        $validator->addRule(new NotEmptyString(), 'name_of_payee', LangAdmin::get('Field_must_be_filled'));
        $validator->addRule(new NotEmptyString(), 'bank_name_of_payee', LangAdmin::get('Field_must_be_filled'));
        $validator->addRule(new NotEmptyString(), 'description_of_payment', LangAdmin::get('Field_must_be_filled'));
        $validator->addRule(new Regexp('#^(\d{10}|\d{12})$#'), 'INN_of_payee', LangAdmin::get('Inn_must_be_10_12_numbers'));
        $validator->addRule(new Regexp('#^\d{20}$#'), 'account_number_of_payee', LangAdmin::get('Account_payee_must_be_20_numbers'));
        $validator->addRule(new Regexp('#^\d{20}$#'), 'correspondent_bank_account', LangAdmin::get('Correspond_account_must_be_20_numbers'));
        $validator->addRule(new Regexp('#^\d{8,9}$#'), 'bank_identification_code', LangAdmin::get('BIK_must_be_8_9_numbers'));

        if (! $validator->validate()) {
            $this->respondAjaxError($validator->getErrors());
        }
        try {
            foreach ($validator->getData() as $key => $value) {
                $this->siteConfigRepository->Set($key, $value);
            }
        } catch (Exception $e) {
            $this->respondAjaxError($e);
        }
        $this->sendAjaxResponse();
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveSearchOrderAction($request)
    {

        $usedSearchMethods = $request->getValue('usedSearchs');
        $unUsedSearchMethods = $request->getValue('unUsedSearchs');
        foreach($usedSearchMethods as &$searchType){
            $searchType = str_replace('China_Other', 'Taobao_Extended', $searchType);
            $searchType = str_replace('China', 'Taobao', $searchType);
        }
        if (is_array($unUsedSearchMethods)) {
            foreach($unUsedSearchMethods as &$searchType){
                $searchType = str_replace('China_Other', 'Taobao_Extended', $searchType);
                $searchType = str_replace('China', 'Taobao', $searchType);
            }
        } else {
            $unUsedSearchMethods = array();
        }
        $newParam  = array();
        if (is_array($usedSearchMethods)) {
            $newParam['orderSearchMethods'] = serialize($usedSearchMethods);
        }
        if (is_array($unUsedSearchMethods)) {
            $newParam['orderUnUsedSearchMethods'] = serialize($unUsedSearchMethods);
        }
        $this->cms->saveSiteConfig($newParam);
        $fileMysqlMemoryCache = new FileAndMysqlMemoryCache($this->cms);
        $fileMysqlMemoryCache->DelCacheEl('GetProviderSearchMethodInfoList:id');
        $this->sendAjaxResponse();

    }

    /**
     * @param RequestWrapper $request
     */
    public function saveSearchTitleAction($request)
    {
        $searchProvider = $request->getValue('search_provider');
        $searchTitle = $request->getValue('search_title');

        $validator = new Validator(array(
            'search_provider' => $searchProvider,
            'search_title'    => $searchTitle,
        ));
        $validator->addRule(new NotEmptyString(), 'search_provider', LangAdmin::get('Field_must_be_filled'));
        $validator->addRule(new NotEmptyString(), 'search_title', LangAdmin::get('Field_must_be_filled'));

        if (! $validator->validate()) {
            $this->respondAjaxError($validator->getErrors());
        }
        try {
            $key = $searchProvider . '_Flag';
            if (Session::get('active_lang_siteconfiguration')) {
                $lang = Session::get('active_lang_siteconfiguration');
            } else {
                $lang = Session::getActiveAdminLang();
            }
            $translations = array($lang => $searchTitle);
            $this->translationsRepository->AddTranslation($key, $translations);
        } catch (Exception $e) {
            $this->respondAjaxError($e);
        }
        $this->sendAjaxResponse();
    }

    // TODO: Убрать дублирование с WarehouseProducts::uploadImage
    private function uploadImage()
    {
        $uploader = new UploadHandler(array(
            'param_name' => 'uploaded_logo',
            'image_versions' => array(
                '' => array(
                    'max_width' => 300,
                    'max_height' => 100,
                    'jpeg_quality' => 95
                ),
            ),
        ), false, null, '/uploaded/logo/');
        return $uploader->post(false);
    }

    public function onMenuCountLvl1Save()
    {
        $this->onMenuTypeSave();
    }

    public function onMenuCountLvl2Save()
    {
        $this->onMenuTypeSave();
    }

    public function onMenuTypeSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/menushortnew');
    }

    public function onUseMultiSearchSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
    }

    public function onSimpleSearchPerpageSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
    }

    public function onTmallSearchPerpageSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
    }

    public function onWarehouseSearchPerpageSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
    }

    public function onCommentsSearchPerpageSave()
    {
        Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
    }
}
