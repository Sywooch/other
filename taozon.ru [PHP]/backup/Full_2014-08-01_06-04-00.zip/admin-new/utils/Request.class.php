<?php

class Request
{
    /**
     * Классы, доступность которых зависит от наличия включенной фичи
    **/
    private static $featuresClassesMap = array(
        'Warehouse' => array('Warehouse'),
        'FleaMarket' => array('Pristroy'),
    );

    /**
     * @param   RequestWrapper            $request
     * @param   AuthenticationListener    $authenticationListener
     * @return  mixed
     * @throws  Exception
     */
    static function handle($request, $authenticationListener)
    {
        $cmd = $request->request('cmd') ? $request->request('cmd') : Permission::default_cmd();
        $do = $request->request('do') ? $request->request('do') : 'default';

        if (! (strtolower($cmd) == 'login')) {
            // Если мы не на странице логаута или логина, проверим авторизованность пользователя
            if (! $authenticationListener->IsAuthenticated($request)) {
                $loginUrl = 'http://' . $request->env('HTTP_HOST') . '/' . $request->getUriPart(0) . '/?cmd=Login';
                if ($request->env('HTTP_X_REQUESTED_WITH')
                    && strtolower($request->env('HTTP_X_REQUESTED_WITH') === 'xmlhttprequest')
                ) {
                    if ($request->getReferrer()) {
                        $loginUrl .= '&retpath=' . $request->getReferrer();
                    }
                    $message = 'Session expired. Relogin is required.';
                    $response = array(
                        'error' => 1,
                        'message' => $message,
                        'redirect' => $loginUrl,
                    );
                    Session::setError($message);
                    echo json_encode($response);
                    die();
                } else {
                    $request->LocationRedirect($loginUrl);
                }
            }
        }

        $class_name = ucfirst($cmd);
        $method_name = $do . 'Action';
        if (self::isFeatureEnabled($class_name) && class_exists($class_name, true)) {
            $cmd = new $class_name();
            if (! method_exists($cmd, $method_name) && method_exists($cmd, 'getDefaultAction')) {
                $do = $cmd->getDefaultAction();
                $method_name = $do . 'Action';
            }
            if (method_exists($cmd, $method_name)) {
                if (method_exists($cmd, 'onBeforeAction')) {
                    $cmd->onBeforeAction($do);
                }

                $isMultiCurlAction = !! in_array($do, $cmd->getMultiCurlActions());

                if (OTBase::isMultiCurlEnabled() && $isMultiCurlAction) {
                    $cmd->startMulti();
                    $cmd->$method_name($request);
                    $cmd->doMulti();
                }

                $output = $cmd->$method_name($request);

                if (OTBase::isMultiCurlEnabled() && $isMultiCurlAction) {
                    $cmd->stopMulti();
                }

                return $output;
            }
        }

        throw new Exception('Unknown Request '.$class_name.'::'.$method_name, 1);
    }

    /**
     * Проверяет соотвествие запрашиваемых классов набору разрешённых фич
    **/
    private static function isFeatureEnabled($class_name)
    {
        foreach (self::$featuresClassesMap as $feature => $classes) {
            if (! CMS::isFeatureEnabled($feature) && in_array($class_name, $classes)) {
                return false;
            }
        }
        return true;
    }

    static function http($url, $method, $params) {

        $ch = curl_init();

        $url = $url . '?' . http_build_query($params,'','&');
        curl_setopt($ch, CURLOPT_URL, $url );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST,  $method );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

        $data = curl_exec($ch);
        if (curl_errno($ch)) {
            throw new Exception(curl_error($ch));
        }
        $data = new SimpleXmlElement($data);

        switch($data->ErrorCode){
            case 'Ok':
                break;
            case 'SessionExpired':
                throw new Exception($data->ErrorDescription,ERR_SESSION_EXPIRED);
                break;
            default:
                throw new Exception($data->ErrorDescription,ERR_UNKNOWN);
        }

        curl_close($ch);

        return $data;
    }
}
