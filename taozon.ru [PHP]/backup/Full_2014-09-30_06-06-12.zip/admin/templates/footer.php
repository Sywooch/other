</div>

    <div id="foot">
        <a href="http://box.opentao.net/" target="_blank">(C) 2011 - <?=date('Y', time())?> opentao.net</a>
    </div>

</body>
</html>