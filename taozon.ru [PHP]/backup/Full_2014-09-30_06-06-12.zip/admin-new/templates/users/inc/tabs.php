<?=TabsGenerator::GetTabs('templates/users/navigation/tabs.xml', $PageUrl)?>
