<?=TabsGenerator::GetTabs('templates/site_config/navigation/tabs.xml', $PageUrl)?>
