<?php

interface IAdminUtil{
    public function checkAuth();
    public function linkCMS();
    public function fetchTemplate();
}
