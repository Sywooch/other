<?php

OTBase::import('system.lib.Cache');
OTBase::import('system.lib.cache.Key');
OTBase::import('system.lib.cache.adapter.*');
OTBase::import('system.uploader.php.UploadHandler');
OTBase::import('system.lib.Validation.*');
OTBase::import('system.lib.Validation.Rules.*');

class Categories extends GeneralUtil
{
    protected $_template = 'categories';
    protected $_template_path = 'categories/';

    protected $categoriesProvider;
    protected $cacher;

    public function __construct()
    {
        parent::__construct();

        $this->categoriesProvider = new CategoriesProvider($this->cms);
        $this->cacher = new Cache('CategoriesUISettings');
    }
    
    private function generateFilter($request) 
    {
        $settings = $this->cacher->get('CategoriesUISettings');
        $settings = $settings ? $settings : array();

        $showHidden = array_key_exists('show_hidden_categories', $settings) ? $settings['show_hidden_categories'] : 1;
        $showEmpty = array_key_exists('show_empty_categories', $settings) ? $settings['show_empty_categories'] : 1;
        $showWoChild = array_key_exists('show_categories_wochild', $settings) ? $settings['show_categories_wochild'] : 1;
        
        $filter = array();
        $filter['show_hidden_categories'] = $request::post('show_hidden_categories', $showHidden);
        $filter['show_empty_categories'] = $request::post('show_empty_categories', $showEmpty) ;
        $filter['show_categories_wochild'] = $request::post('show_categories_wochild', $showWoChild);
        
        $settings['show_hidden_categories'] = $filter['show_hidden_categories'];
        $settings['show_empty_categories'] = $filter['show_empty_categories'];
        $settings['show_categories_wochild'] = $filter['show_categories_wochild'];
        $this->cacher->set($settings, 'CategoriesUISettings');
        
        return $filter;
    }
    
    function defaultAction($request)
    {
        $filter = $this->generateFilter($request);
        $this->tpl->assign('filter', $filter);
        $sid = Session::get('sid');
        try {
            $categories = $this->categoriesProvider->GetEditableCategorySubcategories($sid, 0, 'true');
            if (! is_array($categories)) {
                throw new ServiceException(__METHOD__, '', 'Could not load categories list', 1);
            }
            $categories = $this->applyFilters($categories);
            
            if (is_array($categories)) {
                foreach ($categories as $k => &$category) {
                    $category['alias'] = $this->categoriesProvider->getCategoryAlias($category['Id']);
                    $category['seo'] = $this->categoriesProvider->getCategorySEO($category['Id']);
                    $category['seo_pagetitle'] = $category['seo']['pagetitle'];
                    $category['seo_keywords'] = $category['seo']['seo_keywords'];
                    $category['seo_description'] = $category['seo']['seo_description'];
                    $category['seo_title'] = $category['seo']['seo_title'];
                }
            }

        } catch (Exception $e) {
            ErrorHandler::registerError($e);
            $categories = array();
        }    

        $this->_template = 'categories';
        $this->tpl->assign('categories', $categories);
        print $this->fetchTemplate();
    }
    
    private function applyFilters($categories)
    {
        $settings = $this->cacher->get('CategoriesUISettings');
        
        $showHidden = array_key_exists('show_hidden_categories', $settings) ? $settings['show_hidden_categories'] : 1;
        $showEmpty = array_key_exists('show_empty_categories', $settings) ? $settings['show_empty_categories'] : 1;
        $showWoChild = array_key_exists('show_categories_wochild', $settings) ? $settings['show_categories_wochild'] : 1;
        
        $filteredCategories = array();
        $i = 0;
        foreach ($categories as $key => &$category) {
            $skip = false;
            
            if (($category['IsHidden'] == 'true' || $category['ishidden'] == 'true') && $showHidden == 0) {
                $skip = true;
            } elseif (($category['IsHidden'] == 'true' || $category['ishidden'] == 'true') && $showHidden == 1) {
                $category['IsHiddenUI'] = 'true';
            } 
            
            if (($category['deletestatus'] == 'ParentOfHiddenDeleted') && ($showEmpty == 0) ) {
                $skip = true;
            } elseif (($category['deletestatus'] == 'ParentOfHiddenDeleted') && ($showEmpty == 1) ) {
                $category['DeleteStatusUI'] = 'true';
            } 
            
            if (($category['deletestatus'] == 'ParentOfHiddenDeleted') && ($category['IsParent'] == 'false') && ($showWoChild == 0)) {
                $skip = true;
            }

            if (($category['IsVirtual'] == 'true' && $category['IsParent'] == 'false') && ($showWoChild == 0)) {
                $skip = true;
            }

            if (! $skip) {
                $category['i'] = $i;
                $i++;
                $filteredCategories[] = $category;
            }
        }
        
        return $filteredCategories;
    }

    /**
     * @param RequestWrapper $request
     */
    public function getCategoriesAction($request)
    {
        $sid = Session::get('sid');
        try {
            $parentId = $request->getValue('parentId');
            $categories = $this->categoriesProvider->GetEditableCategorySubcategories($sid, $parentId, 'true');
            if (! is_array($categories)) {
                throw new ServiceException(__METHOD__, '', 'Could not load categories list', 1);
            }
            // apply filter
            $categories = $this->applyFilters($categories);
            if (is_array($categories)) {
                foreach ($categories as $k => &$category) {
                    $category['alias'] = $this->categoriesProvider->getCategoryAlias($category['Id']);
                    $category['seo'] = $this->categoriesProvider->getCategorySEO($category['Id']);
                    $category['seo_pagetitle'] = $category['seo']['pagetitle']; 
                    $category['seo_keywords'] = $category['seo']['seo_keywords'];
                    $category['seo_description'] = $category['seo']['seo_description'];
                    $category['seo_title'] = $category['seo']['seo_title'];
                }
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
            $categories = array();
        }
        
        $this->sendAjaxResponse(array(
            'categories' => $categories
        ));
    }

    /**
     * @param RequestWrapper $request
     */
    public function createCategoryAction($request)
    {
        $sid = Session::get('sid');
        try {
            $name = $request->getValue('name');
            $parentId = $request->getValue('parentId');
            $categoryId = $request->getValue('categoryId');
            $approxweight = $request->getValue('approxweight');
            $alias = $request->getValue('alias', '');
            $seoText = $request->getValue('seoText', '');
            
            $alias = str_replace("\\", "-", $alias );
            $alias = str_replace("\/", "-", $alias );
            
            $metaPagetitle = $request->getValue('meta_pagetitle', '');
            $metaTitle = $request->getValue('meta_title', '');
            $metaKeywords = $request->getValue('meta_keywords', '');
            $metaDescription = $request->getValue('meta_description', '');
            
            $validator = new Validator(array(
                'name' => trim($name),
                'alias' => $alias
            ));
            
            $validator->addRule(new NotEmptyString(), 'name', LangAdmin::get('Name_cannot_be_empty'));
            $validator->addRule(new Regexp('/^[a-z]+([-_]?[a-z0-9]+){0,2}$/i'), 'alias', LangAdmin::get('Category_alias_is_invalid'));
            if (! $validator->validate()) {
                $this->respondAjaxError($validator->getErrors());
            }
            
            if (!$categoryId) {
                $categoryId = '';
            }
            
            if ($parentId < 0) {
                $parentId = 0;
            }
            
            $newId = $this->categoriesProvider->AddCategoryByLanguage($sid, $name, $parentId, $categoryId);
                        
            if ($approxweight) {
                $xml = $this->generateApproximateWeightXML($approxweight);
                if ($xml) {
                    $result = $this->categoriesProvider->EditCategoryInfo($sid, $newId, $xml);
                }
            }
            
            if ($seoText) {
                $this->categoriesProvider->setSeoText($newId, $seoText);
            }
            
            if (in_array('Seo2', General::$enabledFeatures)) {
                $this->categoriesProvider->setCategoryAlias($newId, $alias);
                $data = array(
                    'cid' => $newId,
                    'seo_title' => $metaTitle,
                    'meta_keywords' => $metaKeywords,
                    'meta_description' => $metaDescription,
                    'meta_title'=> $metaPagetitle
                );
                $this->categoriesProvider->setCategorySEO($data);
            }
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'newId' => $newId
        ));
    }

    public function updateCategoryAction($request)
    {
        try {
            $sid = Session::get('sid');
            $id = $request->getValue('id');
            $parentId = $request->getValue('parentId');
            $newName = (string)$request->getValue('newName');
            $categoryId =  $request->getValue('categoryId');
            $externalId =  $request->getValue('externalId');
            $approxweight = $request->getValue('approxweight');
            $alias = $request->getValue('alias','');
            $seoText = $request->getValue('seoText','');
            
            $alias = str_replace("\\", "-", $alias );
            $alias = str_replace("\/", "-", $alias );
            
            $metaPagetitle = $request->getValue('meta_pagetitle', '');
            $metaTitle = $request->getValue('meta_title', '');
            $metaKeywords = $request->getValue('meta_keywords', '');
            $metaDescription = $request->getValue('meta_description', '');

            $validator = new Validator(array(
                'name' => trim($newName),
                'categoryId' => $categoryId,
                'alias' => $alias
            ));
            $validator->addRule(new NotEmptyString(), 'name', LangAdmin::get('Name_cannot_be_empty'));
            $validator->addRule(new NotEmptyString(), 'categoryId', LangAdmin::get('Category_id_cannot_be_empty'));
            $validator->addRule(new Regexp('/^[a-z]+([-_]?[a-z0-9]+){0,2}$/i'), 'alias', LangAdmin::get('Category_alias_is_invalid'));
            if (! $validator->validate()) {
                $this->respondAjaxError($validator->getErrors());
            }
            
            //update category name
            $result = $this->categoriesProvider->EditCategoryNameByLanguage($sid, $categoryId, $newName);
                        
            // update category external id
            if (!$externalId) {
                $externalId = '';
            }
            $this->categoriesProvider->EditCategoryExternalId($categoryId, $externalId, $sid);
            
            //update category approxweight
            if ($approxweight) {
                $xml = $this->generateApproximateWeightXML($approxweight);
                if ($xml) {
                    $result = $this->categoriesProvider->EditCategoryInfo($sid, $categoryId, $xml);
                }
            }
            
            //update category text
            if (!$seoText) {
                $seoText = '';
            }
            $this->categoriesProvider->setSeoText($categoryId, $seoText);
            
            if (in_array('Seo2', General::$enabledFeatures)) {
                $this->categoriesProvider->setCategoryAlias($categoryId, $alias);
                
                $data = array(
                   'cid' => $categoryId,
                    'seo_title' => $metaTitle,
                    'meta_keywords' => $metaKeywords,
                    'meta_description' => $metaDescription,
                    'meta_title'=> $metaPagetitle
                    );
                
                $this->categoriesProvider->setCategorySEO($data);
            }
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        
        $this->sendAjaxResponse();
    }
    
    private function generateApproximateWeightXML($weight = false) 
    {
        if ($weight !== false) {
            $xml = new SimpleXMLElement('<EditableCategoryInfo></EditableCategoryInfo>');
            if ($weight === '') {
                $xml->addChild('ResetApproxWeight', 'true');
            }
            else {
                $xml->addChild('ApproxWeight', $weight);
            }
            return $xml->asXML();
        }
        return '';
    }
    
        
    /**
     * @param RequestWrapper $request
     */
    public function removeCategoryAction($request)
    {
        try {
            $id = $request->getValue('id');
            $result = $this->categoriesProvider->RemoveCategory(Session::get('sid'), $id);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function visibleCategoryAction($request)
    {
        try {
            $categoryId = $request->getValue('categoryId');
            $sessionId = Session::get('sid');
            if ($request->getValue('visible') == 'false') {
                $categorySettings = $categoryId . '-0';
            } else {
                $categorySettings = $categoryId . '-1';
            }
            $data = $this->categoriesProvider->EditCategoriesVisible($categorySettings, $sessionId);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        
        $this->sendAjaxResponse();
    }
    
    public function orderCategoryAction($request)
    {
        try {
            $categoryId = $request->getValue('categoryId');
            $sessionId = Session::get('sid');
            $i = $request->getValue('i');
            
            $data = $this->categoriesProvider->EditOrderOfCategory($i, $categoryId, $sessionId);
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }
    
    /**
     * @param RequestWrapper $request
     */
    public function moveCategoryAction($request)
    {
        try {
            $sid = Session::get('sid');
            $id = $request->getValue('id');
            $parentId = $request->getValue('parentId');
            $newParentId = $request->getValue('newParentId');
            
            $validator = new Validator(array(
                'id' => trim($id),
                'parentId' => trim($parentId),
                'newParentId' => trim($newParentId),
            ));
            $validator->addRule(new NotEmptyString(), 'id', LangAdmin::get('Id_cannot_be_empty'));
            $validator->addRule(new NotEmptyString(), 'parentId', LangAdmin::get('Category_id_cannot_be_empty'));
            $validator->addRule(new NotEmptyString(), 'newParentId', LangAdmin::get('Category_id_cannot_be_empty'));
            if (! $validator->validate()) {
                $this->respondAjaxError($validator->getErrors());
            }
            
            $this->categoriesProvider->EditCategoryParent($sid, $id, $newParentId);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }
    
    public function exportTxtAction($request)
    {
        try {
            //2014_02_12
            $date = new DateTime();
            $filename = 'categories_'.$date->format('Y_m_d').'.txt';
            $sessionId = Session::get('sid');
            $data = $this->categoriesProvider->ExportStructureByLanguage($sessionId);
            if ($data) {
                header('Content-Type: text/plain; charset:utf-8;');
                header('Content-Disposition: attachment; filename="'.$filename.'"');
                echo base64_decode($data);
                echo "\r\n";
            }            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
    }

    public function exportXmlAction($request)
    {
        try {
            $date = new DateTime();
            $filename = 'categories_'.$date->format('Y_m_d').'.xml';
            $sessionId = Session::get('sid');
            $data = $this->categoriesProvider->ExportCatalog($sessionId);
            if ($data) {
                header('Content-type: text/xml; charset=utf8');
                header('Content-Disposition: attachment; filename="'.$filename.'"');
                $content = $data->Content->asXML();
                $content = str_replace('Content', 'CatalogPackage', $content);
                echo $content;
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
    }
    
    public function importAction($request)
    {
        try {
            $uploadResult = json_decode($this->uploadFile());
            if ($uploadResult && $uploadResult->uploaded_file[0]->size > 0) {
                $sessionId = Session::get('sid');
                
                $content = file_get_contents($uploadResult->uploaded_file[0]->url);
                if ($uploadResult->uploaded_file[0]->type == 'text/plain' ) {
                    $data = explode("\r\n", $content);
                    
                    $original = $this->categoriesProvider->ExportStructureByLanguage($sessionId);
                    
                    if ($original) {
                        $original = base64_decode($original);
                        foreach ($data as $line) {
                            $tmp = explode(";", $line);
                            if (isset($tmp[1]) && ($tmp[1]<>'')) {
                                    $original = str_replace($tmp[0], $tmp[1], $original);
                            }
                        }
                    }
                    
                    $sorce = base64_encode($original);
                    $data = $this->categoriesProvider->ImportStructureByLanguage($sessionId, $sorce);
                    
                } elseif ($uploadResult->uploaded_file[0]->type == 'text/xml') {
                    $data = $this->categoriesProvider->ImportCatalog($sessionId, $content);
                }
            } else {
                Session::setError(
                    LangAdmin::get('Could_not_load_file_categories') . '. ' . $uploadResult->uploaded_file[0]->error
                );
            }
        } catch (ServiceException $e) {
            Session::setError($e->getErrorMessage());
            ErrorHandler::registerError($e);
        }
        header('Location: index.php?cmd=categories');
    }
    
    private function uploadFile()
    {
        ob_start();
        new UploadHandler(array(
            'param_name' => 'uploaded_file',
            'accept_file_types' => '/\.(txt|xml)$/i'
        ), true, null, '/uploaded/categories/');
        $result = ob_get_contents();
        ob_end_clean();
        return $result;
    }
    
    public function getCategoryDataAction($request)
    {
        $seoText = '';
        try {
            $sessionId = Session::get('sid');
            $categoryId = $request->getValue('categoryId');
            $seoText = $this->categoriesProvider->getSeoText($categoryId);
            $searchprops = $this->categoriesProvider->GetCategorySearchProperties($categoryId);
            $searchFilters = $this->generateSearchFilterEditor($searchprops);
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse(array('seoText' => $seoText, 'filters' => $searchFilters));
    }
    
    private function generateSearchFilterEditor($searchprops) 
    {
        $this->_template = 'searchFilters';

        $this->tpl->assign('searchprops', $searchprops);
        return $this->fetchTemplateWithoutHeaderAndFooter(false);
    } 

    public function saveFilterAction($request) 
    {
        try {
            $sessionId = Session::get('sid');
            $langId = Session::getActiveLang();
            $categoryId = $request->get('categoryId');
            $filterId = $request->get('filterId');
            $name = $request->getValue('name');
            $value = $request->getValue('value');
            
            $this->categoriesProvider->updateSearchFilter($categoryId, $filterId, $name, $value, $sessionId, $langId);
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }

    
    public function getHintAction($request)
    {
        try {
            $sessionId = Session::get('sid');
            $name = $request->getValue('name');

            $categories = $this->categoriesProvider->FindHintCategoryInfoList($name);
            $hints = array();
            
            foreach ($categories as $category) {
                $path = '';
                if (isset($category['path'])) {
                    $paths = array();
                    foreach ($category['path'] as $pitem) {
                        $paths[] = $pitem['name'];
                    }
                    $path = implode(' > ', $paths); 
                }
                else {
                    $path = $category['name'];
                    
                }
                
                $hint = array();
                $hint['id'] = $category['id'];
                $hint['label'] = $path;
                
                $hints[] = $hint;
            }
            $this->sendAjaxResponse($hints);
        } catch (ServiceException $e) {
            ErrorHandler::registerError($e);
        }
    }
    
    private function copyCategories($parentId, $targetId) 
    {
        try {
            $sessionId = Session::get('sid');
            $categories = $this->categoriesProvider->GetEditableCategorySubcategories($sessionId, $parentId, 'true');
            if (is_array($categories)) {
                foreach ($categories as $key => &$category) {
                    try {
                        $newId = null;
                        $newId = $this->categoriesProvider->AddCategoryByLanguage($sessionId, $category['name'], $targetId, $category['externalid']);
                    } catch (ServiceException $e) {
                    }
                    if ($newId && $category['IsParent'] == 'true') {                
                        $parentId = $category['Id'];
                        $this->copyCategories($category['id'], $newId);
                    }
                }
            }
        } catch (ServiceException $e) {
            $this->errorHandler->registerError($e);
        }
    }
    
    public function copyPasteAction($request){
        try {
            $sessionId = Session::get('sid');
            $copiedId = $request->getValue('copiedId');
            $targetId = $request->getValue('targetId');
            $copiedName = $request->getValue('copiedName');
            $copiedExternalId = $request->getValue('copiedExternalId');

            if ($copiedName) {
                $newId = $this->categoriesProvider->AddCategoryByLanguage($sessionId, $copiedName, $targetId, $copiedExternalId);
                if ($newId) {                
                    $this->copyCategories($copiedId, $newId);
                }
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }
    
    
}
