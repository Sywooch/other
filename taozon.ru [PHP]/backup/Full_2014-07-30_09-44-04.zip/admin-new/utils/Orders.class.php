<?php

OTBase::import('system.lib.Assets');
OTBase::import('system.lib.Cache');
OTBase::import('system.lib.service.OrderItem.Picture');
OTBase::import('system.lib.service.PackageRecord');
OTBase::import('system.lib.service.ServiceRecord');
OTBase::import('system.lib.service.UserRecord');
OTBase::import('system.lib.Validation.*');
OTBase::import('system.lib.Validation.Rules.*');
OTBase::import('system.uploader.php.UploadHandler');

class Orders extends GeneralUtil
{
    const ITEMS_PER_PAGE = 25;

    const STATUS_WAITING_SURCHARGE = 11;

    protected $multiCurlActions = array(
        'list',
        'view',
        'package',
    );

    protected $defaulAction = 'list';

    // TODO: расшифровать эти непонятные цифры
    private $defaultFilterStatuses = array(20=>20, 30=>30, 31=>31, 32=>32, 36=>36, 37=>37, 38=>38, 39=>39);

    protected $periodsFilters = array(
        'specified_period',
        'today_period',
        'yesterday_period',
        'current_week_period',
        'last_week_period',
        'last_month_period',
        'last_three_months_period',
        'year_period',
    );

    public function __construct()
    {
        parent::__construct();

        $this->ordersProvider = new OrdersProvider($this->getOtapilib());
        $this->usersProvider = new UsersProvider($this->getOtapilib());
        $this->supportRepository = new SupportRepository($this->cms);
    }

    public function listAction($request)
    {
        $sid = Session::get('sid');

        $page = $this->getPageDisplayParams($request, self::ITEMS_PER_PAGE);

        $sort = $request->getValue('sort', array());

        if ($request->valueExists('resetFilters')) {
            $cacher = new Cache('getFilters');
            $cacher->drop();
            $this->redirect($this->getPageUrl()->generate(array('cmd' => 'orders', 'do' => 'list')));
        }
        $filter = $this->getFilters($request);
        $applyFilters = (bool) ($request->getValue('applyFilters') || ! empty($filter));

        $filter['orders_status'] = isset($filter['orders_status']) ? $filter['orders_status'] : $this->defaultFilterStatuses;

        $uids = array();
        if (! empty($filter['phone']) || ! empty($filter['email'])) {
            if ($this->inMulti) {
                $this->stopMulti();
                $uids = $this->usersProvider->getUsersByFilters($filter, $page['number'], $page['limit']);
                $this->startMulti(true);
            } elseif (! $this->continuedMulti){
                $uids = $this->usersProvider->getUsersByFilters($filter, $page['number'], $page['limit']);
            }
        }

        if (! empty($filter['client_id'])) {
            $uids[] = $filter['client_id'];
        }

        $orders = array();
        $orders['Content'] = array();
        $orders['TotalCount'] = 0;
        $languages = array();
        try {
            $xmlOrders = $this->ordersProvider->generateSearchParams($filter, $sort, implode(';', $uids));
            $orders = $this->ordersProvider->SearchOrders($sid, $xmlOrders, $page['offset'], $page['limit']);

            if (! $this->inMulti && $request->getValue('redirectToOrder') && !empty($filter['number'])) {
                if ($orders && ! empty($orders['Content'])) {
                    $foundOrder = reset($orders['Content']);
                    if ($foundOrder->getNumericId() == OrdersProxy::getOrderNumericId($filter['number'])) {
                        $this->redirect($this->getPageUrl()->generate(array(
                            'cmd' => 'orders',
                            'do' => 'view',
                            'id' => $foundOrder->id,
                        )));
                    }
                }
                Session::setError(LangAdmin::get('No_orders_found'));
            }

            $ordersStatusList = $this->ordersProvider->GetOrderStatusList($sid);

            $xmlItems = $this->ordersProvider->generateItemsSearchParams($filter, $sort, implode(';', $uids));
            $items = $this->ordersProvider->SearchOrderLines($sid, $xmlItems, 0, 1000);

            $itemsStatusList = $this->ordersProvider->getItemsStatusList($sid);

            $languages = $this->languagesProvider->GetActiveLanguages();

            if ($this->inMulti) {
                return;
            } else if (OTBase::isMultiCurlEnabled()) {
                $this->stopMulti();
            }

            $ordersPrepared = ! empty($orders['Content']) ? Permission::filter_orders($orders['Content']) : array();
            foreach ($ordersPrepared as &$order) {
                $order['items'] = array_filter(
                    $items['Content'],
                    create_function('$a', 'return $a["OrderId"] == "'.$order['id'].'";')
                );
            }
            $itemsPrepared = array();

            foreach ($items['Content'] as $item) {
                if (ProductsHelper::isWarehouseProduct($item)) {
                    $url = $this->getPageUrl()->getWarehouseProductUrl($item);
                    $item->ItemExternalURL = $url;
                    $item->itemexternalurl = $url;
                }
                $itemsPrepared[] = $item;
            }

            $items['Content'] = $itemsPrepared;

            $this->tpl->assign('orders', $ordersPrepared);
            $this->tpl->assign('items', ! empty($orders['Content']) ? $items['Content'] : array());
            $this->tpl->assign('ordersStatusList', $ordersStatusList);
            $this->tpl->assign('itemsStatusList', $itemsStatusList);

        } catch (ServiceException $e) {
            ErrorHandler::registerError($e);
        }

        $this->tpl->assign('paginator', new Paginator($orders['TotalCount'], $page['number'], $page['limit']));
        $this->tpl->assign('applyFilters', $applyFilters);
        $this->tpl->assign('sorting', $sort);
        $this->tpl->assign('perpage', $page['limit']);
        $this->tpl->assign('filter', $filter);
        $this->tpl->assign('languages', $languages);
        $this->tpl->assign('periodsFilters', $this->getPeriodFilters());

        print $this->fetchTemplate();
    }

    public function viewAction($request)
    {
        $sid = Session::get('sid');
        $id = OrdersProxy::originOrderId($request->getValue('id'));
        try {
            if ($this->inMulti) {
                $this->stopMulti();
                $order = $this->ordersProvider->getOrderInfo($sid, $id);
                $this->startMulti();
            } else {
                $order = $this->ordersProvider->getOrderInfo($sid, $id);
            }
            if (empty($order)) {
                throw new ServiceException(__METHOD__, '', 'Could not find order #' . $id, 1);
            }

            $user = array();
            if (! empty($order['custid'])) {
                // Информацию о пользователе получаем в отдельном try {} catch,
                // потому что по каким-то причинам у заказа может отсутствовать заказчик О_о
                try {
                    $userAccount = $this->getOtapilib()->GetAccountInfoForOperator($sid, $order['custid']);
                    $user = $this->getOtapilib()->GetUserInfoForOperator($sid, $order['custid']);
                    $user['account'] = $userAccount;
                    $user['orders'] = $this->ordersProvider->getOrdersByUserId($sid, $order['custid'], $order['id']);
                } catch (ServiceException $e) {}
            }
            $user = new UserRecord($user);

            $itemsStatusList = $this->ordersProvider->getItemsStatusList($sid);

            $order['packages']              = $this->ordersProvider->getOrderPackages($sid, $id, $order->items);
            $order['readyToPurchaseItems']  = $this->ordersProvider->getReadyToPurchaseOrderItems($sid, $id, $order->items);
            $order['purchasedItems']        = $this->ordersProvider->getPurchasedOrderItems($sid, $id, $order->items);
            $order['processlog']            = new ServiceRecord($this->getOtapilib()->GetSalesProcessLog($sid, $id));

            $usedStatusList = array();
            $filteredSalesLinesList = array();

            if ($this->inMulti) {
                return;
            } else if (OTBase::isMultiCurlEnabled()) {
                $this->stopMulti();
            }

            // Переписка с пользователем
            $order['ticketMessages'] = $this->getTicketMessages($order, $user);

            $itemsPrepared = array();

            foreach ($order->items as $item) {
                if (ProductsHelper::isWarehouseProduct($item)) {
                    $url = $this->getPageUrl()->getWarehouseProductUrl($item);
                    $item->ItemExternalURL = $url;
                    $item->itemexternalurl = $url;
                }
                $itemsPrepared[] = $item;
            }

            $order->items = $itemsPrepared;

            $this->tpl->assign('order', $order);
            $this->tpl->assign('user', $user);
            $this->tpl->assign('itemsStatusList', $itemsStatusList);
        } catch (ServiceException $e) {
            ErrorHandler::registerError($e);

            if (!$order) {
                $this->redirect($this->getPageUrl()->generate(array('cmd' => 'orders', 'do' => 'list')));
            }
        }

        print $this->fetchTemplate();
    }

    public function getOrderItemCommentsAction($request)
    {
        $repo = new ItemInfoRepository($this->cms);
        $comments = $repo->getItemComments($request->getValue('itemid'), $request->getValue('categoryid'));
        $comments = is_array($comments) ? array_slice($comments, 0, 2) : array();
        $this->sendAjaxResponse(array(
            'comments' => $comments,
        ));
    }

    public function deleteItemFromOrderAction($request)
    {
        $sid = Session::get('sid');
        $orderid = $request->getValue('orderid');
        $itemid = $request->getValue('itemid');
        try {
            $result = $this->getOtapilib()->CancelLineSalesOrderForOperator($sid, $orderid, $itemid);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not delete item from order', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }

    public function getItemConfigAction($request)
    {
        $sid = Session::get('sid');
        $itemId = $request->getValue('itemId');
        $configs = array();
        try {
            $result = $this->getOtapilib()->GetItemFullInfoWithPromotions($itemId);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not get item full info', 1);
            }
            if (! empty($result['configurations'])) {
                $configs['configurations'] = $result['configurations'];
            }
            if (! empty($result['item_with_config'])) {
                $configs['item_with_config'] = $result['item_with_config'];
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($configs);
    }

    public function setItemConfigAction($request)
    {
        $sid = Session::get('sid');
        $itemId = $request->getValue('itemId');
        $orderId = $request->getValue('orderId');
        $configId = $request->getValue('configId');
        try {
            $this->ordersProvider->changeOrderItemConfig($sid, $orderId, $itemId, $configId);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }

    public function changeItemPriceAction($request)
    {
        $sid = Session::get('sid');
        list($itemId, $orderId) = explode('_', $request->getValue('pk'));
        $newPrice = (string)$request->getValue('value');
        $newPrice = str_replace(',', '.', $newPrice);
        if (empty($newPrice)) {
            $this->respondAjaxError(LangAdmin::get('Value_must_not_be_empty'));
        }
        try {
            $result = $this->ordersProvider->changeOrderItemPrice($sid, $orderId, $itemId, $newPrice);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not change item price', 1);
            }
            $orderInfo = $this->getOtapilib()->GetSalesOrderDetailsForOperator($sid, $orderId, '', 1);
            $userInfo  = $this->getOtapilib()->GetUserInfoForOperator($sid, $orderInfo['salesorderinfo']['custid']);
            foreach ($orderInfo['saleslineslist'] as $item) {
                if ($item['id'] == $itemId) {
                    $itemId = $item['itemtaobaoid'];
                    break;
                }
            }
            $data = array(
                'orderid'  => OrdersProxy::normalizeOrderId($orderInfo['salesorderinfo']['id']),
                'itemid'   => $itemId,
                'newprice' => $newPrice,
                'currency' => $orderInfo['salesorderinfo']['currencysign']
            );
            Notifier::generalUserNotification(
                $userInfo['email'],
                'email_change_item_price',
                Lang::get('update_order').' '.$data['orderid'],
                $data
            );
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'amountcust' => $item['NewPriceCust'] * $item['Qty'],
        ));
    }

    public function splitItemQuantityAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('orderId');
        $itemId = $request->getValue('itemId');
        $splitQuantity = $request->getValue('splitQuantity');
        try {
            $result = $this->ordersProvider->splitOrderItemQuantity($sid, $orderId, $itemId, $splitQuantity);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not split item quantity', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function changeOrderWeightAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('pk');
        $weight  = $request->getValue('value');
        if (empty($weight)) {
            $this->respondAjaxError(LangAdmin::get('Value_must_not_be_empty'));
        }
        try {
            $xmlUpdateData = '<OrderUpdateData><Weight>' . str_replace(',', '.', $weight) . '</Weight></OrderUpdateData>';
            $result = $this->getOtapilib()->UpdateOrderForOperator($sid, $orderId, $xmlUpdateData);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not change order weight', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function changeOperatorCommentAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('orderId');
        $itemId = $request->getValue('itemId');
        $status = $request->getValue('status');
        $comment = $request->getValue('comment', '');
        $quantity = $request->getValue('quantity', '');
        $response = array();
        try {
            // TODO: костыль. Сервисы не умеют очищать комментарий. Пустой коммент будет прогнорирован.
            // Поэтому здесь, если нужен пустой коммент, отправляем пробел.
            $comment = strlen($comment) ? $comment : ' ';
            $this->getOtapilib()->ChangeLineStatus($sid, $orderId, $itemId, $status, $comment, $quantity);
            $response['comment'] = array(
                'name' => LangAdmin::get('Operator'),
                'text' => $comment,
            );
        } catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response);
    }

    public function addTicketMessageAction($request)
    {
        $sid = Session::get('sid');
        $orderId        = $request->getValue('orderId');
        $customerId     = $request->getValue('customerId');
        $customerName   = $request->getValue('customerName');
        $ticketId       = $request->getValue('ticketId');
        $comment        = $request->getValue('comment');
        $isNewTicket    = $request->getValue('isNewTicket');
        if (empty($comment)) {
            $this->respondAjaxError(LangAdmin::get('Value_must_not_be_empty'));
        }
        $response = array();
        try {
            if ($isNewTicket === 'true') {
                $result = $this->supportRepository->createTicket(
                    $customerId,
                    $orderId,
                    'Common',
                    LangAdmin::get('in_order'),
                    $comment,
                    true
                );
                $newTicketId = (int)$result;
            } else {
                $result = $this->supportRepository->createTicketMessage('-100', $ticketId, $comment, true);
            }
            if (! empty($result)) {
                $userdata = $this->getOtapilib()->GetUserInfoForOperator($sid, $customerId);
                $userdata['ticket_id'] = ! empty($newTicketId) ? $newTicketId : $ticketId;
                $userdata['txt_message'] = $comment;
                Notifier::notifyUserOnTicketAnswer($userdata);

                $response['comment'] = array(
                    'username'  => LangAdmin::get('Operator'),
                    'time'      => date('d.m.Y, H:i'),
                    'text'      => $comment,
                );
                if (! empty($newTicketId)) {
                    $response['newTicketId'] = $newTicketId;
                }
            }
        } catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response);
    }

    public function markTicketMessagesReadAction($request)
    {
        $sid = Session::get('sid');
        $orderId    = $request->getValue('orderId');
        $ticketId   = $request->getValue('ticketId');

        $response = array();
        try {
            $this->supportRepository->markRead($ticketId, 'In');
        } catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response);
    }

    public function changeOrderAdditionalInfoAction($request)
    {
        $sid = Session::get('sid');
        $info = $request->getValue('info');
        $orderId = $request->getValue('orderId');
        try {
            // TODO: костыль. Сервисы не умеют очищать комментарий. Пустой коммент будет прогнорирован.
            // Поэтому здесь, если нужен пустой коммент, отправляем пробел.
            $info = strlen($info) ? $info : ' ';
            $xmlUpdateData = '<OrderUpdateData><AdditionalInfo>' .
                $this->escape($info) . '</AdditionalInfo></OrderUpdateData>';
            $result = $this->getOtapilib()->UpdateOrderForOperator($sid, $orderId, $xmlUpdateData);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not change additional order info', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function changeItemStatusAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('orderId');
        $itemId = $request->getValue('itemId');
        $status = $request->getValue('status');
        $comment = $request->getValue('comment', '');
        $quantity = $request->getValue('quantity', '');
        $response = array();
        try {
            if (is_array($itemId)) {
                $result = $this->ordersProvider->changeOrderItemsStatus($sid, $orderId, $itemId, $status);
            } else {
                $result = $this->getOtapilib()->ChangeLineStatus($sid, $orderId, $itemId, $status, $comment, $quantity);
            }
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not change item status', 1);
            }
            $order = $this->ordersProvider->getOrderInfo($sid, $orderId);
            $response = array(
                'itemsByStatus' => $order->getItemsGrouppedByStatus(),
                'orderStatusName' => $order->statusName,
                'orderStatusCode' => $order->statusCode,
                'orderPaid' => $order->getPaidAmount(),
                'orderRemain' => TextHelper::formatPrice($order->remainamount, $order->currencysign),
            );
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response);
    }

    public function cancelOrderAction($request)
    {
        $sid = Session::get('sid');
        $id = $request->getValue('id');
        try {
            $result = $this->getOtapilib()->CancelSalesOrderForOperator($sid, $id);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not cancel order', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function closeOrderAction($request)
    {
        $sid = Session::get('sid');
        $id = $request->getValue('id');
        try {
            $result = $this->getOtapilib()->CloseSalesOrderForOperator($sid, $id);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not close order', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function deletePackageAction($request)
    {
        $sid = Session::get('sid');
        $packageId = $request->getValue('packageId');
        try {
            $this->getOtapilib()->DeletePackage($sid, $packageId);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function packageAction($request)
    {
        $sid = Session::get('sid');
        $packageId = $request->getValue('packageId', 'new');
        $orderId = $request->getValue('orderId');

        try {
            if ($this->inMulti) {
                $this->stopMulti();
                $order = $this->ordersProvider->getOrderInfo($sid, $orderId);
                $this->startMulti();
            } else {
                $order = $this->ordersProvider->getOrderInfo($sid, $orderId);
            }
            if (empty($order)) {
                throw new ServiceException(__METHOD__, '', 'Could not find order #' . $orderId, 1);
            }

            if ($order['custid']) {
                $user = $this->getOtapilib()->GetUserInfoForOperator($sid, $order['custid']);
                if (empty($user['countrycode'])) {
                    $user['countrycode'] = 'RU';
                }
            } else {
                $user['countrycode'] = 'RU';
            }

            $itemsStatusList = $this->ordersProvider->getItemsStatusList($sid);

            $countries      = $this->getOtapilib()->GetDeliveryCountryInfoList();
            $processLog     = $this->getOtapilib()->GetSalesProcessLog($sid, $orderId);

            if ($packageId == 'new') {
                $actionTitle = LangAdmin::get('Creating_package');
                $packageItems = array();
                $itemsIds = $request->getValue('itemsIds', array());
                if (! empty($itemsIds)) {
                    foreach ($order->items as $item) {
                        if (in_array($item->id, $itemsIds)) {
                            $item['in_package'] = true;
                            $packageItems[] = $item;
                        }
                    }
                }
            } else {
                $actionTitle = LangAdmin::get('Editing_package') . ' № ' . $packageId;

                $package = $this->getOtapilib()->GetPackage($sid, $packageId);

                // Если редактровать статус нельзя, то не делаем запрос.
                $packageStatuses = array();
                if ($this->inMulti || ($package && $package['CanChangeStatus'] == 'true')) {
                    $packageStatuses = $this->getOtapilib()->GetPackageAvailableStatusList($sid, $packageId);
                }
                // Определение товаров, которые относятся к данной посылке
                $packageItemsIds = array();
                if ($package && !empty($package['items'])) {
                    foreach ($package['items'] as $item) {
                        $packageItemsIds[] = $item['orderlineid'];
                    }
                }

                // TODO: Здесь происходит что-то непонятное.
                // Понять что и сделать это правильно.
                $packageItems = array();
                foreach ($order->items as $item) {
                    if (in_array($item['id'], $packageItemsIds)) {
                        $item['in_package'] = true;
                    }
                    if ($item['canmovetopackage'] == 'true') {
                        $packageItems[] = $item;
                    }
                }

                $this->tpl->assign('package', new ServiceRecord($package));
                $this->tpl->assign('packageStatuses', $packageStatuses);
            }

            if ($this->inMulti) {
                return;
            } else if (OTBase::isMultiCurlEnabled()) {
                $this->stopMulti();
            }
            // В мудьти нельзя вызвать так как необходим параметр из другого запроса.
            if ($packageId == 'new') {
                $deliveryModes  = $this->getOtapilib()->GetDeliveryModesWithPrice($order['DeliveryAddress']['CountryCode'], 0);
            } else {
                $deliveryModes  = $this->getOtapilib()->GetDeliveryModesWithPrice($order['DeliveryAddress']['CountryCode'], (float)$package['Weight']);
            }
            $this->tpl->assign('packageItems', $packageItems);
            $this->tpl->assign('order', $order);
            $this->tpl->assign('countries', $countries);
            $this->tpl->assign('deliveryModes', $deliveryModes);
            $this->tpl->assign('itemsStatusList', $itemsStatusList);
            $this->tpl->assign('actionTitle', $actionTitle);

        } catch (ServiceException $e) {
            ErrorHandler::registerError($e);
        }

        print $this->fetchTemplate();
    }

    /**
     * Перемещение товаров между посылками.
     *
     * - Если передан только toPackageId (fromPackageId == null) -  это добавление товаров в существующую посылку.
     *                                                              Товары при этом не находятся ни в одной посылке.
     *
     * - Если передан только fromPackageId (toPackageId == null) -  это перемещение товаров из существующей посылки
     *                                                              во вновь создаваемую посылку для перемещаемых
     *                                                              товаров.
     *
     * - Если переданы оба параметра toPackageId и fromPackageId -  это перемещение товаров из одной существующей
     *                                                              посылки в другую существующую посылку.
     *
     * - Если передан параметр toPackageId и doDelete            -  это удаление товаров из посылки.
    **/
    public function moveItemsToPackageAction($request)
    {
        $sid = Session::get('sid');
        $itemsIds = $request->getValue('itemsIds');
        $toPackageId = $request->getValue('toPackageId', null);
        $fromPackageId = $request->getValue('fromPackageId', null);
        $doDelete = $request->getValue('doDelete', null);
        $orderId = $request->getValue('orderId', null);

        if (! ($toPackageId || $fromPackageId)) {
            $this->respondAjaxError('There must be at least one package ID');
        }

        if ($toPackageId == $fromPackageId) {
            $this->respondAjaxError(LangAdmin::get('Choose_another_package_for_items'));
        }

        try {
            Plugins::invokeEvent('onUpdatePackage');

            if (! is_null($fromPackageId)) {
                // Если посылка, в которую нужно переместить itemsIds не передана,
                // значит ее надо создать.
                if (is_null($toPackageId)) {
                    $newPackageId = $this->ordersProvider->createPackage($sid, $orderId, $itemsIds);
                    if (empty($newPackageId)) {
                        $this->respondAjaxError('Could not create a new package');
                    }
                }
            }

            if (! is_null($toPackageId)) {
                $packageTo = new PackageRecord($this->getOtapilib()->GetPackage($sid, $toPackageId));
                $itemsTo = array();
                if (! is_null($doDelete)) {
                    foreach ($packageTo->items as $item) {
                        if (! in_array($item->orderLineId, $itemsIds)) {
                           $itemsTo[] = $item->orderLineId;
                        }
                    }
                } else {
                    $itemsTo = $itemsIds;
                    foreach ($packageTo->items as $item) {
                        $itemsTo[] = $item->orderLineId;
                    }
                }
                $this->ordersProvider->moveItemsToPackage($sid, array_unique($itemsTo), $toPackageId);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'message' => LangAdmin::get('Package_updated_successfully')
        ));
    }

    public function savePackageAction($request)
    {
        $sid = Session::get('sid');
        $packageId = $request->getValue('packageId', 'new');
        $orderId = $request->getValue('orderId');
        $itemsIds = $request->getValue('itemsIds');
        $cutomerId = $request->getValue('cutomerId');
        $PriceInternal = $request->getValue('PriceInternal');
        $CurrentPriceInternal = $request->getValue('CurrentPriceInternal');

        try {
            if ($packageId == 'new') {
                $newPackageId = $this->ordersProvider->createPackage($sid, $orderId, $itemsIds);
                if (! empty($newPackageId)) {
                    Session::setMessage(LangAdmin::get('Package_created_successfully'));
                    Notifier::sendEmailCreatePackage($cutomerId, $orderId, $newPackageId);
                }
            } else {
                $order = $this->getOtapilib()->GetSalesOrderDetailsForOperator($sid, $orderId, '', 1);
                if (empty($order)) {
                    throw new ServiceException(__METHOD__, '', 'Could not find order #' . $orderId, 1);
                }

                Plugins::invokeEvent('onUpdatePackage');

                if ($PriceInternal < 0) {
                    throw new Exception(LangAdmin::get('Price_can_not_be_below_zero'));
                }

                $this->ordersProvider->updatePackage($sid, $packageId, $request);

                if ((float)$PriceInternal != (float)$CurrentPriceInternal) {
                    $user = $this->getOtapilib()->GetUserInfoForOperator($sid, $order['salesorderinfo']['custid']);
                    Notifier::notifyUserOnChangePackagePrice($user, $order, $packageId, $PriceInternal, $CurrentPriceInternal);
                }

                if ($order['salesorderinfo']['statuscode'] == self::STATUS_WAITING_SURCHARGE) {
                    Notifier::notifyUserOnOrderNeedSurcharge($order);
                }

                Session::setMessage(LangAdmin::get('Package_updated_successfully'));

            }
        } catch (Exception $e) {
            Session::setError($e->getMessage());
            $urlParams = array(
                'cmd' => 'orders',
                'do' => 'package',
                'orderId' => $orderId,
                'packageId' => $packageId,
            );
            if (! empty($itemsIds)) {
                $urlParams['itemsIds'] = $itemsIds;
            }
            $this->redirect('index.php?' . http_build_query($urlParams));
        }

        $this->redirect('index.php?cmd=orders&do=view&id=' . $orderId);
    }

    public function paymentReserveAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('orderId');
        try {
            $paymentInfo = $this->getOtapilib()->GetSalesPaymentInfo($sid, $orderId);
            if (empty($paymentInfo)) {
                throw new ServiceException(__METHOD__, '', 'Could not get order payment info', 1);
            }
            // TODO: почему резервируется даже, если на счету денег меньше, чем надо?
            $amount = min(
                (float)$paymentInfo['custbalanceavail'],
                (float)$paymentInfo['salesamount'] - (float)$paymentInfo['salespaid']
            );
            $this->getOtapilib()->SalesPaymentReserve($sid, $orderId, $amount);
            // TODO: зачем это?
            $this->getOtapilib()->GetSalesOrderDetailsForOperator($sid, $orderId, '', 1);

        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function purchaseItemsAction($request)
    {
        $sid = Session::get('sid');
        $orderId = $request->getValue('orderId');
        $itemsIds = $request->getValue('itemsIds', array());
        try {
            $itemsIds = is_array($itemsIds) ? $itemsIds : array($itemsIds);
            $readyToPurchaseOrderItems = $this->ordersProvider->getReadyToPurchaseOrderItems($sid, $orderId);
            $items = array();
            foreach ($readyToPurchaseOrderItems as $item) {
                if (in_array($item->id, $itemsIds)) {
                    $items[] = $item;
                }
            }
            $result = $this->ordersProvider->purchaseOrderItems($sid, $orderId, $items);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', 'Could not purchase items', 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function restoreOrderAction($request)
    {
        $sid = Session::get('sid');
        $id = $request->getValue('id');
        try {
            $orderInfo = $this->getOtapilib()->GetSalesOrderDetailsForOperator($sid, $id, '', 0);
            if (empty($orderInfo)) {
                throw new ServiceException(__METHOD__, '', 'Could not get order info', 1);
            }

            // TODO: какой-то левый костыль. Убрать.
            foreach ($orderInfo['saleslineslist'] as $item) {
                $this->getOtapilib()->RestoreLineSalesOrderForOperator($sid, $id, $item['id']);
                break;
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function removeOrderItemImageAction($request)
    {
        $sid = Session::get('sid');
        $itemId = $request->getValue('itemId');
        $orderId = $request->getValue('orderId');
        $imageUrl = $request->getValue('imageUrl');

        $image = new Picture($imageUrl);
        $imageType = $image->getType();

        if (! in_array($imageType, Picture::getAvailableTypes())) {
            $this->respondAjaxError('Invalid image type given.');
        }

        $response = array();
        try {
            if ($imageType === 'link') {
                $status = $request->getValue('status');
                $comment = $request->getValue('comment', '');
                $quantity = $request->getValue('quantity', '');

                if (strpos($comment, $imageUrl) !== false) {
                    $comment = str_replace($imageUrl, '', $comment);
                    $comment = trim(preg_replace("#\n+#si", "\n", $comment), "\n");
                    // TODO: костыль. Сервисы не умеют очищать комментарий. Пустой коммент будет прогнорирован.
                    // Поэтому здесь, если нужен пустой коммент, отправляем пробел.
                    $comment = strlen($comment) ? $comment : ' ';
                    $this->getOtapilib()->ChangeLineStatus($sid, $orderId, $itemId, $status, $comment, $quantity);
                    $response = array(
                        'comment' => $comment,
                    );
                }
            } else {
                $image->remove();
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response);
    }

    public function uploadOrderItemImageAction($request)
    {
        $sid = Session::get('sid');
        $itemId = $request->request('itemId');
        $orderId = $request->request('orderId');
        $uploadType = $request->request('type', Picture::TYPE_UPLOADED);

        if (! in_array($uploadType, Picture::getAvailableTypes())) {
            $this->respondAjaxError('Unknown upload type requested.');
        }

        $response = array();
        try {
            if ($uploadType === Picture::TYPE_LINK) {
                $imagesLinks = $request->getValue('imagesLinks');
                $status = $request->getValue('status');
                $comment = $request->getValue('comment', '');
                $quantity = $request->getValue('quantity', '');
                foreach ($imagesLinks as $key => $link) {
                    if (strpos($comment, $link) !== false) {
                        unset($imagesLinks[$key]);
                    }
                }
                if (empty($imagesLinks)) {
                    $this->respondAjaxError('No new images links given.');
                }
                $validator = new Validator($imagesLinks);
                foreach ($imagesLinks as $key => $link) {
                    $validator->addRule(new URL(), $key, LangAdmin::get('Image link must be a valid URL'));
                }
                if (! $validator->validate()) {
                    $this->respondAjaxError($validator->getErrors());
                }
                $data = $validator->getData();

                $comment = str_replace('\n', "\n", $comment);
                $comment .= "\n" . implode("\n", $data) . "\n";
                $comment = trim(preg_replace("#\n+#si", "\n", $comment), "\n");
                $this->getOtapilib()->ChangeLineStatus($sid, $orderId, $itemId, $status, $comment, $quantity);
                $response = array(
                    'comment' => $comment,
                    'urls' => $data,
                );
            } else {
                $uploadResult = $this->uploadImage($itemId . '/' . OrdersProxy::originOrderId($orderId));
                if (empty($uploadResult['files'])) {
                    $this->respondAjaxError('Failed to upload images.');
                }
                $response['urls'] = array();
                foreach ($uploadResult['files'] as $file) {
                    $response['urls'][] = $file->url;
                }
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse($response, false, ($uploadType === Picture::TYPE_WEBCAM));
    }

    public function getDeliveryModesAction($request)
    {
        $countryCode = $request->getValue('countryCode');
        $weight = $request->getValue('weight');
        try {
            $deliveryModes  = $this->getOtapilib()->GetDeliveryModesWithPrice($countryCode, $weight);
            $response = array(
                'deliveryModes' => $deliveryModes
            );
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse($response);
    }

    protected function getPeriodFilters()
    {
        $periods    = array();
        $startTime  = time();
        $endTime    = time();
        foreach ($this->periodsFilters as $period) {
            $dateObj = new DateTime();
            switch ($period) {
                case 'today_period':
                    $startTime  = time();
                    $endTime    = time();
                break;
                case 'yesterday_period':
                    $startTime = strtotime($dateObj->format('Y/m/d H:i:s') . ' - 1day');
                    $endTime = $startTime;
                break;
                case 'current_week_period':
                    $diff = $dateObj->format('w') - 1;
                    $startTime = strtotime($dateObj->format('Y/m/d H:i:s') . ' - ' . $diff . 'day');
                    $endTime   = time();
                break;
                case 'last_week_period':
                    $diff = $dateObj->format('w');
                    $startTime = strtotime($dateObj->format('Y/m/d H:i:s') . ' - ' . ($diff + 6) . 'day');
                    $endTime = strtotime($dateObj->format('Y/m/d H:i:s') . ' - ' . $diff . 'day');
                break;
                case 'last_month_period':
                    $startTime = strtotime($dateObj->format('Y/m/1 H:i:s') . ' - 1month');
                    $endTime = mktime(23, 59, 59, date('m', $startTime), date('t', $startTime), date('Y', $startTime));
                break;
                case 'last_three_months_period':
                    $startTime = strtotime($dateObj->format('Y/m/1 H:i:s') . ' - 3month');
                    $endTime = strtotime($dateObj->format('Y/m/d') . ' - 1month');
                    $endTime = mktime(23, 59, 59, date('m', $endTime), date('t', $endTime), date('Y', $endTime));
                break;
                case 'year_period':
                    $startTime = strtotime($dateObj->format('Y/1/1 H:i:s'));
                    $endTime   = time();
                break;
            }
            $dateObj->setTimestamp($startTime);
            $startDate = $dateObj->format('F d, Y H:i:s');
            $dateObj->setTimestamp($endTime);
            $endDate = $dateObj->format('F d, Y H:i:s');
            $periods[$period] = array(
                'start' => $startDate,
                'end'   => $endDate,
            );
        }
        return $periods;
    }

    protected function getTicketMessages(& $order, $user)
    {
        $messages = array();
        $ticketList = $this->supportRepository->getTicketInfoList($order['custid']);
        foreach ($ticketList as $item) {
            if (($item['OrderId'] == $order['id']) && ($item['CategoryId'] == 'Common')) {
                $ticketId = str_replace('Ticket-', '', $item['ticketid']);
                $order['ticketId'] = $ticketId;
                $messages = $this->supportRepository->getTicketMessageList($order['custid'], $ticketId, true);
                break;
            }
        }
        $countNew = 0;
        foreach ($messages as $message) {
            if ($message['Direction'] == 'In' && !$message['read']) {
                $countNew++;
            }
        }
        $order['ticketMessagesNewCount'] = $countNew;
        foreach ($messages as $key => $message) {
            if ($message['Direction'] == 'In') {
                $custName = trim($order['custname']);
                $userName = ! empty($custName)? $custName : $user->getDisplayName();
            } else {
                $userName = LangAdmin::get('Operator');
            }
            $messages[$key]['username'] = $userName;
        }

        return $messages;
    }

    // TODO: Убрать дублирование с SiteConfigutaion::uploadImage
    private function uploadImage($uploadDir = null)
    {
        if ($uploadDir) {
            $uploadDir = str_replace('//', '/', '/uploaded/items/' . $uploadDir . '/');
        } else {
            $uploadDir = '/uploaded/items/';
        }
        $uploader = new UploadHandler(array(
            'image_versions' => array(
                'thumbnail_100_100' => array(
                    'max_width' => 100,
                    'max_height' => 100,
                    'jpeg_quality' => 90
                ),
                'thumbnail_310_310' => array(
                    'max_width' => 310,
                    'max_height' => 310,
                    'jpeg_quality' => 90
                ),
            )
        ), false, null, $uploadDir);
        return $uploader->post(false);
    }

    private function getFilters($request)
    {
        $cacher = new Cache('getFilters');
        if ($request->valueExists('filter')) {
            $filter = $request->getValue('filter');
            if (! empty($filter['orders_status'])) {
                $filter['orders_status'] = array_filter($filter['orders_status']);
            }
            $filterForCache = $filter;
            $excludeCacheFields = array('number');
            foreach ($excludeCacheFields as $key) {
                if (isset($filterForCache[$key])) {
                    unset($filterForCache[$key]);
                }
            }
            $cacher->set($filterForCache);
            return $filter;
        }
        return $cacher->has() ? $cacher->get() : array();
    }
}
