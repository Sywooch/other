<?php

class WebUISettings {
    /**
     * @var OTAPIlib
     */
    private $otapilib;

    public function __construct(){
        $this->otapilib = new OTAPIlib();
        $this->otapilib->setErrorsAsExceptionsOn();
    }

    /**
     * @param RequestWrapper $request
     */
    public function SetCategoryMode($request){
        $currentWebUISettings = $this->otapilib->GetWebUISettings(Session::get('sid'));
        $currentWebUISettings->Settings->SelectedCategoryStructureType =
            $request->getValue('value');
        $this->otapilib->SetWebUISettings(Session::get('sid'), $currentWebUISettings->Settings->asXML());
    }

    public function GetWebUISettings(){
        return $this->otapilib->GetWebUISettings(Session::get('sid'));
    }
}