<?php

class PromoProvider {
    /**
     * @var OTAPIlib
     */
    private $otapilib;

    function __construct(){
        $this->otapilib = new OTAPIlib();
        $this->otapilib->setErrorsAsExceptionsOn();
    }
   
}