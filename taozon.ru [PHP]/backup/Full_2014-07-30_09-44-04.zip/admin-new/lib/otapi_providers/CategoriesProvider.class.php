<?php
OTBase::import('SeoCategoryRepository');

class CategoriesProvider extends Repository
{
    /**
     * @var OTAPIlib
     */
    private $otapilib;
    private $seoRepository;

    public function __construct($cms)
    {
        parent::__construct($cms);
        $this->otapilib = new OTAPIlib();
        $this->otapilib->setErrorsAsExceptionsOn();
        $this->seoRepository = new SeoCategoryRepository($this->cms);
    }

    public function RemoveCategory($sessionId, $categoryId) 
    {
        return $this->otapilib->RemoveCategory($sessionId, $categoryId);    
    }
    
    public function EditCategoryExternalId($categoryId, $externalCategoryId, $sessionId, $predefinedData = "")
    {
        return $this->otapilib->EditCategoryExternalId($categoryId, $externalCategoryId, $sessionId);
    }
    
    public function EditOrderOfCategory($index, $categoryId, $sessionId, $predefinedData = "")
    {
        return $this->otapilib->EditOrderOfCategory($index, $categoryId, $sessionId, $predefinedData);
    }
    
    public function EditCategoriesVisible($categoriesVisibleSettings, $sessionId, $predefinedData = "")
    {
        return $this->otapilib->EditCategoriesVisible($categoriesVisibleSettings, $sessionId, $predefinedData);
    }
    
    public function EditCategoryParent($sessionId, $categoryId, $parentCategoryId, $predefinedData = "")
    {
        return $this->otapilib->EditCategoryParent($sessionId, $categoryId, $parentCategoryId);
    }
    
    public function EditCategoryNameByLanguage($sessionId, $categoryId, $categoryName)
    {
        return $this->otapilib->EditCategoryNameByLanguage($sessionId, $categoryId, $categoryName);        
    }
    
    public function GetEditableCategorySubcategories($sessionId, $parentCategoryId, $needHighlightParentsOfDeletedCategories, $predefinedData = "")
    {
        return $this->otapilib->GetEditableCategorySubcategories($sessionId, $parentCategoryId, $needHighlightParentsOfDeletedCategories, $predefinedData);
    }
    
    public function AddCategoryByLanguage($sessionId, $categoryName, $parentCategoryId, $categoryId, $predefinedData = "")
    {
        return $this->otapilib->AddCategoryByLanguage($sessionId, $categoryName, $parentCategoryId, $categoryId, $predefinedData);
    }

    public function SearchDeletedCategoriesIds($sessionId, $predefinedData = "")
    {
        return $this->otapilib->SearchDeletedCategoriesIds($sessionId, $predefinedData);
    }
    
    public function ExportStructureByLanguage($sessionId, $predefinedData = "")
    {
        return $this->otapilib->ExportStructureByLanguage($sessionId, $predefinedData);
    }    

    public function ImportStructureByLanguage($sessionId, $source, $predefinedData = "")
    {
        return $this->otapilib->ImportStructureByLanguage($sessionId, $source, $predefinedData);        
    }
    
    public function ImportCatalog($sessionId, $source, $predefinedData = "")
    {
        return $this->otapilib->ImportCatalog($sessionId, $source, $predefinedData);
    }

    public function ExportCatalog($sessionId, $predefinedData = "")
    {
        return $this->otapilib->ExportCatalog($sessionId, $predefinedData);
    }
    
    public function EditCategoryInfo($sessionId, $categoryId, $xmlCategoryInfo, $predefinedData = "")
    {
        return $this->otapilib->EditCategoryInfo($sessionId, $categoryId, $xmlCategoryInfo, $predefinedData);
    }
    
    public function getCategoryAlias($cid, $forceCreate = false, $cname = '')
    {
        return $this->seoRepository->getCategoryAlias($cid, $forceCreate, $cname);
    }
    
    public function getCategorySEO($cid)
    {
        return $this->seoRepository->getCategorySEO($cid);
    }
    
    public function setCategoryAlias($cid, $alias)
    {
        return $this->seoRepository->setCategoryAlias($cid, $alias);
    }
    
    public function setCategorySEO($data)
    {
        return $this->seoRepository->setCategorySEO($data);
    }

    public function getSeoText($id)
    {
        $this->cms->Check();
        $this->cms->checkTable('site_categories_seo_texts');
        $id = mysql_real_escape_string($id);
        $q = mysql_query('SELECT text FROM `site_categories_seo_texts` WHERE `category_id`="'.$id.'"');
        return @mysql_result($q, 0);
    }
    
    public function setSeoText($id, $text)
    {
        $this->cms->Check();
        $id = mysql_real_escape_string($id);
        $this->cms->query('DELETE FROM `site_categories_seo_texts` WHERE `category_id`="'.$id.'"');
        $this->cms->query('INSERT INTO `site_categories_seo_texts` SET `category_id`="'.$id.'", `text`="'.
                mysql_real_escape_string(stripslashes($text)).'"');
        return;
    }
    
    public function GetCategorySearchProperties($categoryId)
    {
        return $this->otapilib->GetCategorySearchProperties($categoryId);
    }
    
    public function updateSearchFilter($categoryId, $filterId, $type, $text, $sessionId, $langId)
    {
        if (!General::getConfigValue('not_use_cat_cache')) {
            $DBCacheList = new DBCache();
            if ($DBCacheList->CheckCacheEl('searchprop:' . $filterId)) {
                $SProp = array();
                $SProp[$filterId] = unserialize($DBCacheList->GetCacheEl('searchprop:' . $filterId));
                foreach ($SProp as $pid => &$pvalue) {
                    if ($pid == $categoryId) {
                        $pvalue['name'] = $text;
                    }
                    foreach ($pvalue['values'] as &$value) {
                        if ($value['id'] == $categoryId) {
                            $value['name'] = $text;
                        }
                    }
                }
                foreach ($SProp as $pid => $pvalue) {
                    $DBCacheList->AddCacheEl('searchprop:' . $pid, 21600, serialize($pvalue));
                }
            }
        }
    
            	
        switch ($type) {
            case 'ItemPropertyName': {
                $key = (string)(CFG_SERVICE_INSTANCEKEY . ':taobao:ItemProperty:Name');
                $this->otapilib->EditTranslateByKey($sessionId, $text, $key, $categoryId, $langId);
            } break;
            case 'ItemPropertyValueName': {
                $key = (string)(CFG_SERVICE_INSTANCEKEY . ':taobao:ItemPropertyValue:Name');
                $this->otapilib->EditTranslateByKey($sessionId, $text, $key, $categoryId, $langId);
            } break;
            default:
                break;
        }
    }
    
    public function FindHintCategoryInfoList($hintTitle, $predefinedData = "")
    {
        return $this->otapilib->FindHintCategoryInfoList($hintTitle, $predefinedData);
    }
}

