<?php

class SupportProvider
{
    /**
     * @var OTAPIlib
     */
    private $otapilib;

    public function __construct()
    {
        $this->otapilib = new OTAPIlib();
        $this->otapilib->setErrorsAsExceptionsOn();
    }

    public function GetTicketCatogories()
    {
        return $this->otapilib->GetTicketCatogories();
    }    
}