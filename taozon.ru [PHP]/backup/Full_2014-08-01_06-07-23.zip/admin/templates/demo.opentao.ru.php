<?

define('CFG_SERVICE_APPKEY', 'app_key_16');
define('CFG_SERVICE_INSTANCEKEY', 'demoSite');
define('CFG_SITE_NAME', 'Opentao demo');

define('CFG_VKID', '2975807');

define('CFG_CACHED', true);
define('NO_DEBUG', 1);

?>