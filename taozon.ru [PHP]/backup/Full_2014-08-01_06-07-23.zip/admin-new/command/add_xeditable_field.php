<?php

require_once __DIR__ . '/commands/XEditableField.class.php';

XEditableField::RunAdd();
