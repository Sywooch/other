var UsersForm = new Backbone.Collection();
var UsersFormPage = Backbone.View.extend({
    "el": ".users-form-wrapper",
    "events": {
        "click #addRecipientLink": "toggleRecipientForm",
    },
    render: function()
    {
        this.toggleRecipientForm(1);
        return this;
    },
    initialize: function(){
        this.render();
    },
    toggleRecipientForm: function (initial) {
        var form = this.$('.new-user-delivery-form');
        if ('undefined' !== typeof initial || !this.$('#addRecipientLink').hasClass('collapsed')) {
            form.find('input[required="required"]').removeAttr('required').attr('wasrequired', 'wasrequired');
        } else {
            form.find('input[wasrequired="wasrequired"]').removeAttr('wasrequired').attr('required', 'required');
        }
    }
});

$(function(){
    var UF = new UsersFormPage();
});
