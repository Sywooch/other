var Subscribers = Backbone.View.extend({
    "el": "#content",
    "events": {
        "click .ot_show_deletion_dialog_modal": "removeSubscriber",
        "change #per-page": "setPerPage",
        "submit #import-subscribers": "importSubscribers"
    },
    isTypeAheadInitialized: false,
    progressButton: null,
    render: function() {
        var that = this;

        this.$('#per-page').val(this.$('#per-page').attr('data-value'));

        this.$('.ot-add-subscribers').on('shown', function(e, editable) {
            setTimeout(that.initTypeahead, 100);
        });
        this.$('.ot-add-subscribers').on('save', function(e, editable) {
            if (editable.response.error) {
                showError(editable.response.message);
            } else {
                showMessage(trans.get('Subscriber_added'));
                setTimeout('window.location.reload();', 2000);
            }
            setTimeout(function() {
                $('.ot-add-subscribers').html('<i class="icon-plus font-14 color-blue"></i> Добавить пользователя');
            }, 500);
        });
        this.$('.ot-add-subscribers').editable({
            mode: 'popup',
            url: 'index.php?cmd=Subscribers&do=add',
            title: 'Начните печатать логин...',
            placeholder: 'Start typing an user login',
            emptytext : '',
            inputclass: 'input-medium ot-typehead-subscribers'
        });
    },
    initTypeahead: function() {
        var that = this;
        if (!this.isTypeAheadInitialized) {
            $('.ot-typehead-subscribers').typeahead({
                ajax: {
                    url: 'index.php?cmd=Subscribers&do=searchUserInOtapi',
                    method: 'post'
                },
                onSelect: function(data) {
                    that.$('.ot-add-subscribers').editable('option', 'pk', data.value);
                }
            });
        }
    },
    removeSubscriber: function(ev) {
        var url = $(ev.target).closest('a').attr('href');
        modalDialog('Подтверждение', 'Вы действительно хотите удалить пользователя?', function () {
            window.location.href = url;
        });
        return false;
    },
    setPerPage: function(ev) {
        window.location.href = $(ev.target).attr('data-url') + '&perPage=' + $(ev.target).val();
    },
    importSubscribers: function(ev) {
        var that = this;

        var form = $(ev.target);
        var submitButton = form.find('[type="submit"]');
        var formData = new FormData(form[0]);

        this.progressButton = Ladda.create(submitButton[0]);
        this.progressButton.start();
        submitButton.find('.ladda-label').text('Загрузка');

        $.ajax({
            url: 'index.php?cmd=Subscribers&do=import',
            type: 'POST',
            data: formData,
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                    myXhr.upload.addEventListener('progress',that.setFileUploadProgress, false);
                }
                return myXhr;
            },
            success: function(data) {
                that.progressButton.stop();
                showMessage('Пользователи импортированы');
                setTimeout('window.location.reload();', 1000);
            },
            cache: false,
            contentType: false,
            processData: false
        });

        return false;
    },
    setFileUploadProgress: function(e) {
        //this.progressButton.setProgress(e.loaded / e.total);
    }
});

$(function(){
    var N = new Subscribers();
    N.render();
});