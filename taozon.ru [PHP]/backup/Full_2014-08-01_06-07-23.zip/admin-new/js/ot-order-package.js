var OrderPackagePage = Backbone.View.extend({
    "el": ".order-package-wrapper",
    "events": {
        "submit #packageEditForm" : "checkPackageManualPrice",
        "change #DeliveryCountryCode" : "getDeliveryModes",
        "change #Weight" : "getDeliveryModes",
    },
    render: function()
    {
        return this;
    },
    initialize: function(){
        this.render();
    },
    getDeliveryModes: function(ev){        
        var countryCode = this.$('#DeliveryCountryCode').val();
        var weight = this.$('#Weight').val();
        var currentMode = this.$('#DeliveryModeId').val();
        this.$("#DeliveryModeId").prepend($('<option value="0">Загрузка</option>'));
        this.$("#DeliveryModeId :nth-child(1)").attr("selected", "selected");
        $.post(
            'index.php?cmd=orders&do=getDeliveryModes',
            {   
                countryCode : countryCode, 
                weight : weight
            },
            function (data) {
                if (! data.error) {	
                    $('#DeliveryModeId').empty();
                    $.each(data.deliveryModes, function( index, item ) {
                        $("#DeliveryModeId").prepend($('<option value="' + item.id + '">' + item.name + '</option>'));
                    });
                    $("#DeliveryModeId [value='" + currentMode + "']").attr("selected", "selected");                    				    
				} else {			
                    $("#DeliveryModeId [value='0']").remove();
                    showError(data.message);
				}
            }, 'json'
        );
        return true;
    },
    checkPackageManualPrice: function(ev){
        var currentPrice = this.$('.packagePriceBlock').find('input[name=CurrentPriceInternal]').val();
        var mayBeNewPrice = this.$('.packagePriceBlock').find('input[name=PriceInternal]').val();
		if (parseInt(mayBeNewPrice) < 0) {
			showError(trans.get('Price_can_not_be_below_zero'))
			return false;
		}
        if (parseFloat(currentPrice) != parseFloat(mayBeNewPrice)) {
            this.$('.packagePriceBlock').find('input[name=ManualPrice]').val('true');
        }
        return true;
    }
});

$(function(){
    var OPP = new OrderPackagePage();
});
