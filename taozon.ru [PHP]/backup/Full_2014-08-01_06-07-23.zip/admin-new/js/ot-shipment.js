var Shipment = new Backbone.Collection();
var ShipmentPage = Backbone.View.extend({
    "el": $("#content-wrapper")[0],
    "events": {
        "mouseup .ot_show_deletion_dialog_modal": "deleteItem",
        "mouseup .ot_show_deletion_tariff_dialog_modal": "deleteItem",
        "click #save-delivery": "saveDelivery",
        "click #save-tariff": "saveTariff",
        "click #add_tariff": "addTariff",
    },
    initialize: function(){
    },
    addTariff: function (e) {
        e.preventDefault();

        window.location.href = $(e.target).data('link') + '&delivery=' + this.$('#delivery').val();

        return false;
    },
    deleteItem: function (e) {
        e.preventDefault();

        var target = this.$(e.target).is('i') ? this.$(e.target).parent() : this.$(e.target);

        var link = target.data('link');
        var item_id = target.data('id');
        var item_name = target.data('name');
        var action = target.data('href');

        var msg = _.template(trans.get('delete_warning'), {item: item_name});

        confirmDialog(msg, function(){
            $.post(action, { id: item_id } , function(data){
            }).success(function(){
                window.location.href = link;
            }).error(function(xhr, ajaxOptions, thrownErro){
                showError(xhr.responseText);
            });
        });

        return false;
    },
    saveDelivery: function (e) {
        e.preventDefault();

        var target = this.$(e.target);

        var $button = target.button('loading');
        var action = target.closest('form').attr('action');
		
		if (! isValidForm()) {
			$button.button('reset');
			return false;
		}        
        
        $.post(action, target.closest('form').serializeArray(), function(data){
        })
            .success(function(data){
				if (! data.error) {
                    window.location.href = target.data('link');
				} else {
					$('.input-xlarge').css({'border-color': '#ccc'});
                    $button.button('reset');
					showError(data.message);
				}
                return;               
            })
            .error(function(xhr, ajaxOptions, thrownErro){
                $('.input-xlarge').css({'border-color': '#ccc'});
                $button.button('reset');                
                showError(xhr.responseText);                
            });

        return false;
    },
    saveTariff: function (e) {
        e.preventDefault();

        var target = this.$(e.target);

        var $button = target.button('loading');
        var action = target.closest('form').attr('action');			

        $.post(action, target.closest('form').serializeArray(), function(data){
        })
            .success(function(){
                window.location.href = target.data('link');
                return;
                $('.input-xlarge').css({'border-color': '#ccc'});
                $button.button('reset');
                $('#save-tariff').parent().parent().removeClass('error').addClass('success');
                $('#save-tariff').parent().parent().prepend(
                    $('<p></p>').addClass('help-inline').text(trans.get('Data_save_success'))
                );
            })
            .error(function(xhr, ajaxOptions, thrownErro){
                $('.input-xlarge').css({'border-color': '#ccc'});
                $button.button('reset');
                if(thrownErro == 1){
                    var fields = eval(xhr.responseText);
                    $.each(fields, function(key, value){
                        $('#ot_'+value).css({'border-style':'solid','border-color': '#bd4247'});
                    });
                    $('#save-tariff').parent().parent().removeClass('success').addClass('error');
                    $('#save-tariff').next().remove();
                    $('#save-tariff').parent().append(
                        $('<p></p>').addClass('help-inline').text(trans.get('Fields_incorrect'))
                    );
                } else {
                    showError(xhr.responseText);
                }
            });

        return false;
    }    
});

function isValidForm() {
	var deliveryName = $('[data-check = delivery_name]').val();
	var minWeight = parseFloat($('[data-check = min_weight]').val());
    var maxWeight = parseFloat($('[data-check = max_weight]').val()); 
	var stepWeight = parseFloat($('[data-check = step_weight]').val());
		
	var minPriceDelivery = $('[data-check = min_price_delivery]').prop("checked");	
		
	if (isNaN(minWeight)) {
		minWeight = 0;
	}
	if (isNaN(maxWeight)) {
	    maxWeight = 999;
	}
	if (deliveryName == '') {
        showError(trans.get('Must_enter_delivery_name'));                        
        return false;
    }
	if ((minWeight < 0) || (maxWeight < 0)) {
        showError(trans.get('Min_weight_or_max_weight_can_not_be_minus'));                        
        return false;
    }		
    if ((maxWeight != 0) && (minWeight > maxWeight)) {
        showError(trans.get('Min_weight_can_not_be_more_than_max_weight'));            
        return false;
    }
	if (! minPriceDelivery && isNaN(stepWeight)) {
        showError(trans.get('Must_be_checked_one_of_params_minpricedelivery_or_stepprice'));            
        return false;
    }    
	return true;
}

$(function(){
    new ShipmentPage();
});
