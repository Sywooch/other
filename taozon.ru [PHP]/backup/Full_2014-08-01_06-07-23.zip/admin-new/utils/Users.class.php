<?php
class Users extends GeneralUtil
{
    protected $_cache = false;
    protected $_life_time = 3600;
    protected $_template = 'users';
    protected $_template_path = 'users/';
    /**
     * @var SiteConfigurationRepository
     */
    protected $siteConfigRepository;
    /**
     * @var ShipmentProvider
     */
    protected $shipmentProvider;
	
	protected $multiCurlActions = array(
        'bulkBanUser',
        'bulkUnbanUser',
        'bulkRemoveUser',
    );

    public function __construct()
    {
        parent::__construct();

        $this->cms->checkTable('site_config');
        $this->cms->checkTable('site_langs');
        $this->siteConfigRepository = new SiteConfigurationRepository($this->cms);
        $this->usersProvider = new UsersProvider();
    }

    public function defaultAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);

        $filters = $this->_generateFilters();

        $perpage = RequestWrapper::get('perpage') ? RequestWrapper::get('perpage') : 10;
        $page = RequestWrapper::get('page') ? RequestWrapper::get('page') : 1;
        $from = ($page > 1) ? ($page - 1) * $perpage : 0;
        Session::set('admin_user_page', $page);

        $count = 0;
        try {
            if ($filters === false) {
                $users = array('content' => array(), 'Content' => array(), 'totalcount' => 0, 'TotalCount' => 0);
            } else {
                $users = $this->usersProvider->FindBaseUserInfoListFrame(Session::get('sid'), $filters, $from, $perpage);
                $this->protectUsersIfNecessary($users);
            }

            $count = $users['totalcount'];
            $this->tpl->assign('users', $users['content']);
			$this->tpl->assign('count', $users['totalcount']);
			$this->tpl->assign('startPos', ($page-1)*$perpage+1);
			$this->tpl->assign('endPos', ($page*$perpage >= $users['totalcount'] || $users['totalcount']<$perpage) ? $users['totalcount'] : $page*$perpage);
        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
        }

        $this->tpl->assign('paginator', new Paginator($count, $page, $perpage));

        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    private function protectUsersIfNecessary(&$users)
    {
        if (defined('CFG_PROTECT_USERS_EMAIL') && CFG_PROTECT_USERS_EMAIL) {
            $usersNew = $users;
            $usersNew['content'] = $usersNew['Content'] = array();
            foreach ($users['Content'] as $user) {
                if ($user['Login'] == Session::getUserData('username')) {
                    $usersNew['Content'][] = $user;
                }
            }
            $usersNew['content'] = $usersNew['Content'];
            $users = $usersNew;
        }
    }

    public function addUserAction()
    {
        try {
            $this->tpl->assign('countries', $this->otapilib->GetDeliveryCountryInfoList());
        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
        }

        $this->tpl->assign('actionTitle', LangAdmin::get('adding'));

        $this->assignSiteConfig();

        $this->_template = 'form';
        print $this->fetchTemplate();
    }

    public function editUserAction()
    {
        $sid = Session::get('sid');
        $userId = RequestWrapper::get('id');

        try {
            $user = $this->usersProvider->GetUserInfoForOperator($sid, $userId);
            if (empty($user['id'])) {
                throw new ServiceException(__METHOD__, '', 'User not found', 1);
            }
            $this->tpl->assign('user', $user);
            $this->tpl->assign('countries', $this->otapilib->GetDeliveryCountryInfoList());
        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
        }

        $this->tpl->assign('actionTitle', LangAdmin::get('editing'));

        $this->assignSiteConfig();

        $this->_template = 'form';
        print $this->fetchTemplate();
    }

    public function profileAction()
    {
        $sid = Session::get('sid');
        $userId = RequestWrapper::get('id');

        try {
            $user = $this->usersProvider->GetUserInfoForOperator($sid, $userId);
            if (empty($user['id'])) {
                throw new ServiceException(__METHOD__, '', 'User not found', 1);
            }

            if (CFG_MULTI_CURL) {
                // Инициализируем
                $this->otapilib->InitMulti();
            }

            $userAccount    = $this->usersProvider->GetAccountInfoForOperator($sid, $userId);
            $allOrders      = $this->usersProvider->SearchOrders($sid, $userId, 0, 1000);
            $moneyHistory   = $this->usersProvider->GetStatementForOperator($sid, $userId);            
            $statusList     = $this->otapilib->GetOrderStatusList($sid);

            if (CFG_MULTI_CURL) {
                // Делаем запросы
                $this->otapilib->MultiDo();
                // Сбрасываем
                $this->otapilib->StopMulti();
            }

            $userOrders = array();
            if (! empty($allOrders['Content'])) {
                foreach ($allOrders['Content'] as $order) {
                    if ($order['custid'] == (int)$user['id']) {
                        $userOrders[] = $order;
                    }
                }
            }

            $this->tpl->assign('user', $user);
            $this->tpl->assign('statusList', $statusList);
            $this->tpl->assign('userOrders', $userOrders);
            $this->tpl->assign('userAccount', $userAccount);
            $this->tpl->assign('moneyHistory', $moneyHistory);

            $this->_template = 'profile/about';
            $this->tpl->assign('profileAboutBlock', $this->fetchTemplateWithoutHeaderAndFooter(false));

            $this->_template = 'profile/account';
            $this->tpl->assign('profileAccountBlock', $this->fetchTemplateWithoutHeaderAndFooter(false));

            $this->_template = 'profile/orders';
            $this->tpl->assign('profileOrdersBlock', $this->fetchTemplateWithoutHeaderAndFooter(false));

        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
        }

        $this->assignSiteConfig();

        $this->_template = 'profile';
        print $this->fetchTemplate();
    }

    public function updateAccountAction()
    {
        $sid    = Session::get('sid');
        $userId = RequestWrapper::get('id');

        $amount     = RequestWrapper::post('amount');
        $comment    = RequestWrapper::post('comment');
        $isDebit    = RequestWrapper::post('isDebit');
        $date       = date('Y-m-d h-i-s');
        if (empty($amount)) {
            $this->respondAjaxError(LangAdmin::get('Value_must_not_be_empty'));
        }
        try {
            $result = $this->otapilib->PostTransaction($sid, $userId, $amount, $comment, $isDebit, $date);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', LangAdmin::get('Notify_error'), 1);
            }

            // del cache AccountInfo for user
            $user = $this->otapilib->GetUserInfoForOperator($sid, $userId);
            if (!$user) {
                throw new ServiceException(__METHOD__, '', LangAdmin::get('user_not_exist'), 1);
            }
            $userData = new UserData();
            $userData->ClearAccountInfoCacheByLogin($user['Login']);

            $userAccount = $this->usersProvider->GetAccountInfoForOperator($sid, $userId);
            $moneyHistory = $this->usersProvider->GetStatementForOperator($sid, $userId);
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'userAccount' => $userAccount,
            'moneyHistory' => $moneyHistory
        ));
    }

    public function savePasswordAction()
    {
        $sid = Session::get('sid');
        $userId = (int)RequestWrapper::post('Id');

        $password = trim(RequestWrapper::post('Password'));
        if (empty($password) || strlen($password) < 6) {
            $this->respondAjaxError(LangAdmin::get('Password_min_length_6'));
        }

        try {
            $user = $this->usersProvider->GetUserInfoForOperator($sid, $userId);
            if (empty($user['id'])) {
                throw new ServiceException(__METHOD__, '', 'User not found', 1);
            }
            foreach ($user as $key => $field){
                $_POST[$key] = $field;
            }
            $fields = $this->_generateUserFields();
            $result = $this->usersProvider->EditUser($sid, $fields);
            if ($result){
                // TODO: отправить письмо пользователю о смене его пароля. Отправку вынести в Notifier
                /*
                $newPass = trim(RequestWrapper::post('Password'));
                if (file_exists(TPLCUSTOM_DIR.'users/recovery_email.php'))
                    include(TPLCUSTOM_ABSOLUTE_PATH.'users/recovery_email.php');
                else
                    include(TPL_ABSOLUTE_PATH.'users/recovery_email.php');
                $params['message'] = $message;
                $params['email'] = $user['Email'];
                $params['subject'] = LangAdmin::get('pass_recovery');
                $this->sendEmail2($params);
                */
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'message' => LangAdmin::get('Password_successfully_changed')
        ));
    }

    /**
     * @param RequestWrapper $request
     */
    public function saveUserAction($request)
    {
        $sid = Session::get('sid');
        $userId = RequestWrapper::post('id');

        try {
            $fields = $this->_generateUserFields();
			$deliveryfields = $this->_generateUserDeliveryFields();
            if ($userId) {
                $user = $this->usersProvider->GetUserInfoForOperator($sid, $userId);				
                if (empty($user['id'])) {
                    throw new ServiceException(__METHOD__, '', 'User not found', 1);
                }
				
                $this->usersProvider->EditUser($sid, $fields);	
				if ($deliveryfields)
				    $this->usersProvider->CreateUserProfileForOperator($sid, $userId, $deliveryfields);					
				
                Plugins::invokeEvent('onEditUser', array('user' => $_POST));
                Session::setMessage(LangAdmin::get('Data_updated_successfully'));
                $this->redirect('index.php?cmd=users&do=editUser&id=' . $user['id']);
            } else {
                $newUserId = $this->usersProvider->AddUser($sid, $fields);
                if (empty($newUserId)) {
                    throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
                }
                $this->cms->SetSubscribe($request->getValue('Login'), $request->getValue('Email'));
                Plugins::invokeEvent('onAddUser', array('user' => $_POST, 'newUserId' => $newUserId));
                Session::setMessage(LangAdmin::get('Data_added_successfully'));
                $this->redirect('index.php?cmd=users&do=editUser&id=' . (int)$newUserId);
            }
        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
        } catch (Exception $e) {
            Session::setError($e->getMessage(), $e->getCode());
        }

        if ($userId) {
            $this->redirect('index.php?cmd=users&do=editUser&id=' . $userId);
        } else {
            $this->redirect('index.php?cmd=users&do=addUser');
        }
    }

    public function banUserAction($request)
    {
        $sid = Session::get('sid');
        $userId = $request->getValue('id');
        try {
            $result = $this->usersProvider->SetUserBan($sid, $userId, 'true');
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function unbanUserAction($request)
    {
        $sid = Session::get('sid');
        $userId = $request->getValue('id');
        try {
            $result = $this->usersProvider->SetUserBan($sid, $userId, 'false');
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }

    public function removeUserAction($request)
    {
        $sid = Session::get('sid');
        $userId = $request->getValue('id');
        try {
            $result = $this->usersProvider->DeleteUser($sid, $userId);
            if (empty($result)) {
                throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse();
    }
	
	public function bulkBanUserAction($request)
    {
        $sid = Session::get('sid');
        $userIds = $request->getValue('ids');		            
        try {
			foreach ($userIds as $id) {
                $result = $this->usersProvider->SetUserBan($sid, $id, 'true');
                if (empty($result)) {
                    throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
                }
			}
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
		if ($this->inMulti) {
            return;
        } else if (OTBase::isMultiCurlEnabled()) {
            $this->stopMulti();
        }
        $this->sendAjaxResponse();
    }
	
	
	public function bulkUnbanUserAction($request)
    {
        $sid = Session::get('sid');
        $userIds = $request->getValue('ids');		            
        try {
			foreach ($userIds as $id) {
                $result = $this->usersProvider->SetUserBan($sid, $id, 'false');
                if (empty($result)) {
                    throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
                }
			}
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
		if ($this->inMulti) {
            return;
        } else if (OTBase::isMultiCurlEnabled()) {
            $this->stopMulti();
        }		
        $this->sendAjaxResponse();
    }
	
	
	public function bulkRemoveUserAction($request)
    {
        $sid = Session::get('sid');
        $userIds = $request->getValue('ids');		        
        try {
			foreach ($userIds as $id) {
                $result = $this->usersProvider->DeleteUser($sid, $id);
                if (empty($result)) {
                    throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
                }
			}
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
		if ($this->inMulti) {
            return;
        } else if (OTBase::isMultiCurlEnabled()) {
            $this->stopMulti();
        }
		Session::setMessage(LangAdmin::get('Users_is_deleted'));
        $this->sendAjaxResponse();
    }

    public function ajaxSearchAction()
    {
        $sid = Session::get('sid');
        $param = RequestWrapper::post('param');
        $query = RequestWrapper::post('query');
        $_GET[$param] = $query;

        $filters = $this->_generateFilters();

        try {
            $users = $this->usersProvider->FindBaseUserInfoListFrame($sid, $filters);
            if (empty($users)) {
                throw new ServiceException(__METHOD__, '', $this->usersProvider->getError(), 1);
            }
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }

        $this->sendAjaxResponse(array(
            'items' => $users['content']
        ));
    }

    /**
     * @param RequestWrapper $request
     */
    public function loginAsUserAction($request)
    {
        $sid = Session::get('sid');
        $login = $request->getValue('login');
        try {
            $authSid = $this->usersProvider->AuthenticateAsUser($sid, $login);
            Session::setUserData(array(
                'sid' => $authSid,
                'username' => $login,
                'IsAuthenticated' => true
            ));
            $this->redirect('../');
        } catch (ServiceException $e) {
            Session::setError($e->getMessage(), $e->getErrorCode());
            $this->redirect($request->env('HTTP_REFERER'));
        }
    }

    /**
     * @param RequestWrapper $request
     */
    public function exportUsersAction($request)
    {
        $sid = Session::get('sid');
        $xmlParams = '<UserFilterParameters></UserFilterParameters>';
        if (defined('CFG_PROTECT_USERS_EMAIL') && CFG_PROTECT_USERS_EMAIL) {
            $xmlParams = '<UserFilterParameters><Login>'.Session::getUserData('username').'</Login></UserFilterParameters>';
        }
        $message = ''; 
        $totalCount = 0;
        $cacheFile = new FileAndMysqlMemoryCache($this->cms);       
        try {        
            $usersPack = $this->usersProvider->FindBaseUserInfoListFrame($sid, $xmlParams, $request->getValue('position'), 100);
            $totalCount = $usersPack['TotalCount'];
            $usersPack = $usersPack['Content'];
            
            if (! $request->getValue('position') == 0) {
                $usersPackPrev = unserialize($cacheFile->GetCacheEl('exportUsers:'.$request->getValue('type')));
                $usersPack = array_merge($usersPackPrev, $usersPack);
            }
            $cacheFile->AddCacheEl('exportUsers:'.$request->getValue('type'), 600000, serialize($usersPack)); 
            
            if (($request->getValue('position') + 100) >= $totalCount) {
                $message = $this->prepareExportFile($request->getValue('type'));
            }          
            
        } catch (ServiceException $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse(array(
            'type' => $message
        ));
    }
    
    public function dowmloadExportUsersFileAction($request)
    {
        $type = $request->getValue('type');
        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header('Content-Disposition: attachment; filename="users-' . $type . '.' . $type . '"');
        readfile('../cache/users-' . $type . '.' . $type);
    }
    
    private function prepareExportFile($type)
    {
        $cacheFile = new FileAndMysqlMemoryCache($this->cms);
        $usersPack = unserialize($cacheFile->GetCacheEl('exportUsers:'.$type));
        $cacheFile->DelCacheEl('exportUsers:'.$type);        
        $file = '../cache/users-' . $type . '.' . $type;        
        switch ($type) {
            case 'xml':
                $this->setExportFileXML($file, $usersPack);                
                break;
            case 'xls':
                $this->setExportFileXLS($file, $usersPack);
                break;
            case 'txt':
                $this->setExportFileTXT($file, $usersPack);                
                break;            
        } 
        return $type;
        
    }
    
    private function setExportFileXML($file, $usersPack)
    {
        $xml = new SimpleXMLElement('<Users/>');
        foreach($usersPack as $user){
            $el = $xml->addChild('User');
            $el->addChild('OtapiId', htmlspecialchars($user['Id']));
            $el->addChild('Login', htmlspecialchars($user['Login']));
            $el->addChild('Email', htmlspecialchars($user['Email']));
            $el->addChild('LastName', htmlspecialchars($user['LastName']));
            $el->addChild('FirstName', htmlspecialchars($user['FirstName']));
            $el->addChild('MiddleName', htmlspecialchars($user['MiddleName']));
            $el->addChild('FIO', htmlspecialchars($user['LastName'] . ' ' . $user['FirstName'] . ' ' . $user['MiddleName']));
            $el->addChild('Phone', htmlspecialchars($user['Phone']));                    
        }
        $data = $xml->asXML();
        file_put_contents($file, $data);        
    }
    
    private function setExportFileTXT($file, $usersPack)
    {
        $data = '';                
        foreach($usersPack as $user){
            $data .= $user['Login'] . '|';
            $data .= $user['Email'] . '|';
            $data .= $user['LastName'] . ' ' . $user['FirstName'] . ' ' . $user['MiddleName'] . '|';
            $data .= $user['Phone'] . '|';
            $data .= "\r\n";
        }                
        file_put_contents($file, $data);        
    }
    
    private function setExportFileXLS($file, $usersPack)
    {
        require_once CFG_APP_ROOT . '/lib/PhpExcel/PHPExcel.php';
        $pExcel = new PHPExcel();
        require_once CFG_APP_ROOT . '/lib/PhpExcel/PHPExcel/Writer/Excel5.php';
        $objWriter = new PHPExcel_Writer_Excel5($pExcel);
        $pExcel->setActiveSheetIndex(0);
        $aSheet = $pExcel->getActiveSheet();
        $aSheet->setTitle(LangAdmin::get('customers'));
                
        $aSheet->setCellValue('A1', 'Login');
        $aSheet->setCellValue('B1', 'Email');
        $aSheet->setCellValue('C1', 'FIO');
        $aSheet->setCellValue('D1', 'Phone');                
        foreach($usersPack as $i => $user){                    
            $aSheet->setCellValue('A' . ($i + 2), $user['Login']);
            $aSheet->setCellValue('B' . ($i + 2), $user['Email']);
            $aSheet->setCellValue('C' . ($i + 2), $user['LastName'] . ' ' . $user['FirstName'] . ' ' . $user['MiddleName']);
            $aSheet->setCellValue('D' . ($i + 2), $user['Phone']);
        }
        $aSheet->getColumnDimension('A')->setWidth(20);
        $aSheet->getColumnDimension('B')->setWidth(30);
        $aSheet->getColumnDimension('C')->setWidth(40);
        $aSheet->getColumnDimension('D')->setWidth(15);
        $objWriter->save($file);        
    }    

    private function _generateFilters()
    {
        $xmlParams = new SimpleXMLElement('<UserFilterParameters></UserFilterParameters>');
        if (RequestWrapper::get('login')) $xmlParams->addChild('Login', @htmlspecialchars(RequestWrapper::get('login')));
        if (RequestWrapper::get('email')) $xmlParams->addChild('Email', RequestWrapper::get('email'));
        if (RequestWrapper::get('lastname')) $xmlParams->addChild('LastName', RequestWrapper::get('lastname'));
        if (RequestWrapper::get('isactive')) $xmlParams->addChild('IsActive', RequestWrapper::get('isactive'));
        if (RequestWrapper::get('phone')) $xmlParams->addChild('Phone', @htmlspecialchars(RequestWrapper::get('phone')));

        if (defined('CFG_PROTECT_USERS_EMAIL') && CFG_PROTECT_USERS_EMAIL && Session::getUserData('username') == null){
            return false;
        } elseif (defined('CFG_PROTECT_USERS_EMAIL') && CFG_PROTECT_USERS_EMAIL) {
            $xmlParams->Login = htmlspecialchars(Session::getUserData('username'));
        }

        if (RequestWrapper::post('sort_by'))
            $xmlParams->addChild('OrderBy', RequestWrapper::post('sort_by'));
        elseif (RequestWrapper::get('sort_by'))
            $xmlParams->addChild('OrderBy', RequestWrapper::get('sort_by'));

        return str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());
    }

    private function _generateUserFields()
    {
        $xmlParams = new SimpleXMLElement('<UserUpdateData></UserUpdateData>');
        if (RequestWrapper::post('id')) $xmlParams->addChild('Id', @htmlspecialchars(RequestWrapper::post('id')));
        if (RequestWrapper::post('Email')) $xmlParams->addChild('Email', RequestWrapper::post('Email'));
        if (RequestWrapper::post('Login')) $xmlParams->addChild('Login', RequestWrapper::post('Login'));
        if (RequestWrapper::post('Password')) $xmlParams->addChild('Password', trim(RequestWrapper::post('Password')));

        if (RequestWrapper::post('IsActive')) $xmlParams->addChild('IsActive', 'true');
        else $xmlParams->addChild('IsActive', 'false');

        if (RequestWrapper::post('FirstName')) $xmlParams->addChild('FirstName', RequestWrapper::post('FirstName'));
        if (RequestWrapper::post('LastName')) $xmlParams->addChild('LastName', RequestWrapper::post('LastName'));
        if (RequestWrapper::post('MiddleName')) $xmlParams->addChild('MiddleName', RequestWrapper::post('MiddleName'));
        if (RequestWrapper::post('Sex')) $xmlParams->addChild('Sex', RequestWrapper::post('Sex'));

        if (RequestWrapper::post('Country')) $xmlParams->addChild('Country', htmlspecialchars(RequestWrapper::post('Country')));
        if (RequestWrapper::post('DeliveryCountryCode')) $xmlParams->addChild('DeliveryCountryCode', htmlspecialchars(RequestWrapper::post('DeliveryCountryCode')));
        if (RequestWrapper::post('DeliveryCountryCode')) $xmlParams->addChild('CountryCode', htmlspecialchars(RequestWrapper::post('DeliveryCountryCode')));
        if (RequestWrapper::post('City')) $xmlParams->addChild('City', htmlspecialchars(RequestWrapper::post('City')));
        if (RequestWrapper::post('Address')) $xmlParams->addChild('Address', htmlspecialchars(RequestWrapper::post('Address')));
        if (RequestWrapper::post('Phone')) $xmlParams->addChild('Phone', RequestWrapper::post('Phone'));
        if (RequestWrapper::post('PostalCode')) $xmlParams->addChild('PostalCode', RequestWrapper::post('PostalCode'));
        if (RequestWrapper::post('Region')) $xmlParams->addChild('Region', RequestWrapper::post('Region'));
        if (RequestWrapper::post('Skype')) $xmlParams->addChild('Skype', RequestWrapper::post('Skype'));

        if (RequestWrapper::post('RecipientFirstName')) $xmlParams->addChild('RecipientFirstName', RequestWrapper::post('RecipientFirstName'));
        if (RequestWrapper::post('RecipientLastName')) $xmlParams->addChild('RecipientLastName', RequestWrapper::post('RecipientLastName'));
        if (RequestWrapper::post('RecipientMiddleName')) $xmlParams->addChild('RecipientMiddleName', RequestWrapper::post('RecipientMiddleName'));

        return str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());
    }
	
	
	private function _generateUserDeliveryFields()
    {
        $xmlParams = new SimpleXMLElement('<UserProfileCreateData></UserProfileCreateData>');     		
        if (RequestWrapper::post('new_recipientFirstName')) $xmlParams->addChild('FirstName', RequestWrapper::post('new_recipientFirstName')); else return false; 
        if (RequestWrapper::post('new_recipientLastName')) $xmlParams->addChild('LastName', RequestWrapper::post('new_recipientLastName'));
        if (RequestWrapper::post('new_recipientMiddleName')) $xmlParams->addChild('MiddleName', RequestWrapper::post('new_recipientMiddleName'));        
        if (RequestWrapper::post('new_recipientCountry')) $xmlParams->addChild('CountryCode', htmlspecialchars(RequestWrapper::post('new_recipientCountry')));		
        if (RequestWrapper::post('new_recipientCity')) $xmlParams->addChild('City', htmlspecialchars(RequestWrapper::post('new_recipientCity')));
        if (RequestWrapper::post('new_recipientAddress')) $xmlParams->addChild('Address', htmlspecialchars(RequestWrapper::post('new_recipientAddress')));
        if (RequestWrapper::post('new_recipientPhone')) $xmlParams->addChild('Phone', RequestWrapper::post('new_recipientPhone'));
        if (RequestWrapper::post('new_recipientPostalCode')) $xmlParams->addChild('PostalCode', RequestWrapper::post('new_recipientPostalCode'));
        if (RequestWrapper::post('new_recipientRegion')) $xmlParams->addChild('Region', RequestWrapper::post('new_recipientRegion'));
        return str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());
    }


    private function assignSiteConfig(){
        $this->siteConfigRepository->SetActiveLang(Session::get('active_lang_siteconfiguration'));
        $this->tpl->assign('Config', $this->siteConfigRepository);
    }
}
