<?php
class Catalog extends GeneralUtil
{
    protected $_template = 'catalog';
    protected $_template_path = 'catalog/';

    public function __construct()
    {
        parent::__construct();
    }

    public function defaultAction($request)
    {
        if (CMS::IsFeatureEnabled('FleaMarket')) {
            $this->redirect('index.php?cmd=pristroy');
        } elseif (CMS::IsFeatureEnabled('Warehouse')) {
            $this->redirect('index.php?cmd=warehouse');
        } else {
            print $this->fetchTemplate();
        }
    }
}
