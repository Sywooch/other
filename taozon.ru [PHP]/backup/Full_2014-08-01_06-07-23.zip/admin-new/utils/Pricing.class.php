<?php
class Pricing extends GeneralUtil 
{
    protected $_template = 'general';
    protected $_template_path = 'pricing/';
    /**
     * @var SiteConfigurationRepository
     */
    protected $siteConfigRepository;
    /**
     * @var PricingProvider
     */
    protected $pricingProvider;


    public function __construct()
    {
        parent::__construct();
        $this->cms->checkTable('site_config');
        $this->cms->checkTable('site_langs');
        $this->siteConfigRepository = new SiteConfigurationRepository($this->cms);
        $this->pricingProvider = new PricingProvider();
    }

    public function defaultAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        try {
            $this->tpl->assign('CurrencyList', $this->pricingProvider->GetCurrencyList());
            $this->tpl->assign('CurrenciesSettings', $this->pricingProvider->GetCurrenciesSettings());
            $this->tpl->assign('PriceFormationSettings', $this->pricingProvider->GetPriceFormationSettings());            
            $this->tpl->assign('SyncMode', $this->pricingProvider->GetCurrencySynchronizationModeList());
        }
        catch (ServiceException $e) {
            $this->errorHandler->CheckSessionExpired($e, $request);
        }
        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    public function costAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        $this->_template = 'cost';
        try {
            $this->tpl->assign('Settings', $this->pricingProvider->GetShowCase());
            $this->tpl->assign('RoundSettings', $this->pricingProvider->GetPriceFormationSettings());            
        }
        catch (ServiceException $e) {
            $this->errorHandler->CheckSessionExpired($e, $request);
        }

        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    public function bankerAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        $this->_template = 'banker';
        $this->assignSiteConfig();
        print $this->fetchTemplate();
    }

    public function addCurrencyAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        $this->pricingProvider->addCurrency($request);
        $request->RedirectToReferrer();
    }


    public function saveSettingsCBAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        try {
            $this->pricingProvider->saveSettingsCB($request);
        }
        catch (Exception $e) {
            $this->throwAjaxError($e);
        }
        $this->sendAjaxResponse();
    }

    public function saveCostAction($request)
    {
        $this->authenticationListener->CheckAuthentication($request);
        try {
            if ($request->getValue('name') == 'round_settings') {
                $this->pricingProvider->saveSettingsRound($request);
            } else {
                $this->pricingProvider->saveSettingsCost($request);
            }  
            Cacher::rRmDir(CFG_APP_ROOT . '/cache/multi_search');
            Cacher::rRmDir(CFG_APP_ROOT . '/cache/ItemsWithReviews');
            Cacher::rRmDir(CFG_APP_ROOT . '/cache/GetBrandRatingList');
            Cacher::rRmDir(CFG_APP_ROOT . '/cache/GetItemRatingList');
        }
        catch (Exception $e) {
            $this->throwAjaxError($e);
        }
        $this->sendAjaxResponse();
    }

    public function saveCurrencyAction($request)
    {
        try {
            $this->authenticationListener->CheckAuthentication($request);
            $this->pricingProvider->UpdateInstanceCurrenciesSettings($request);            
        }
        catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $answer = array('message' => LangAdmin::get('Rate_set_succes'));
        $this->sendAjaxResponse($answer);
    }

    public function RemoveRateAction($request)
    {
        try {
            $this->pricingProvider->RemoveCurrencyRate($request);
        }
        catch (Exception $e) {
            $this->respondAjaxError($e->getMessage());
        }
        $this->sendAjaxResponse();
    }

    public function getConfigInJSAction()
    {
        $this->_template_path = 'site_config/';
        $this->_template = 'config_js';
        $this->assignSiteConfig();
        print $this->fetchTemplateWithoutHeaderAndFooter();
    }

    private function assignSiteConfig()
    {
        $this->siteConfigRepository->SetActiveLang(Session::get('active_lang_siteconfiguration'));
        $this->tpl->assign('Config', $this->siteConfigRepository);
    }

}