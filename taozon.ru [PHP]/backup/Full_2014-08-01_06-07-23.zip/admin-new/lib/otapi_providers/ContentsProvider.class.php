<?php

class ContentsProvider extends Repository
{
    /**
     * @var OTAPIlib
     */
    private $otapilib;

    public function __construct($cms)
    {
        parent::__construct($cms);
        $this->otapilib = new OTAPIlib();
        $this->otapilib->setErrorsAsExceptionsOn();
    }
    
    public function getPages($language = false )
    {
        $pagesList = $this->cms->GetPages();
        $allPages = array();
        $pages = array();
        
        foreach ($pagesList as $page) {
            if ($language && $page['lang_code'] != $language) {
                continue;
            }
            $allPages[] = $page;
        }

        foreach ($allPages as &$ppage) {
            if ($language && $ppage['lang_code'] != $language) {
                continue;
            }
            $ppage['menu'] = $this->getPageMenu($ppage);
        }
        
        foreach ($allPages as $page) {
            $parent = $this->getPageParentId($page['id']);
            if (!$parent) {
                $pages[$page['id']] = $page;
                $pages[$page['id']]['children'] = array();
            }
        }
        
        foreach ($allPages as $page) {
            $parent = $this->getPageParentId($page['id']);
            if ($parent && array_key_exists($parent, $pages) ) {
                $pages[$parent]['children'][] = $page;
            }
        }

        return $pages;
    }
    
    public function getPageMenu($page)
    {
        $pageLang = $page['lang_code'];
        $top_menu_json = $this->cms->getBlock('top_menu_' . $pageLang);
        $top_menu = $top_menu_json ? json_decode($top_menu_json) : array();
        
        $left_menu_json = $this->cms->getBlock('left_menu_' . $pageLang);
        $left_menu = $left_menu_json ? json_decode($left_menu_json) : array();
        
        $bottom_menu_json = $this->cms->getBlock('bottom_menu_' . $pageLang);
        $bottom_menu = $bottom_menu_json ? json_decode($bottom_menu_json) : array();
        
        if (in_array($page['id'], $top_menu)) {
            return 'top_menu';
        } elseif (in_array($page['id'], $bottom_menu)) {
            return 'bottom_menu';
        } elseif (in_array($page['id'], $left_menu)) {
            return 'left_menu';
        }
        return '';
    }
    
    public function GetLanguageInfoList($predefinedData = "")
    {
        return $this->otapilib->GetLanguageInfoList($predefinedData);
    }

    public function updatePage($pageId, $alias, $title, $isService)
    {
        mysql_query('UPDATE `pages` SET `alias` = "' . mysql_real_escape_string($alias) . '", `title`= "' . mysql_real_escape_string($title) . '", `is_service` = "' . $isService . '" WHERE `id` = "' . $pageId . '"');
    }
    
    public function addPage($alias, $title, $isService) 
    {
        $sql = 'INSERT INTO `pages` (`alias`, `title`, `is_service` ) VALUES ( "' . mysql_real_escape_string($alias) . '", "' . mysql_real_escape_string($title) . '", "' . $isService . '")';
        $res = mysql_query($sql);
        return mysql_insert_id();
    }

    public function setPageLang($pageId, $pageLanguage) 
    {
        $langId = $this->cms->_getLangCodeId($pageLanguage);
        $r = mysql_query('DELETE FROM `site_pages_langs` WHERE `page_id` = "' . $pageId . '"');
        $sql = 'INSERT INTO `site_pages_langs` (`lang_id`, `page_id` ) VALUES ( "' . $langId . '", "' . $pageId . '" )';
        mysql_query($sql);
        return $langId;
    }

    public function setPageContent($pageId, $pageContent) 
    {
        $r = mysql_query('DELETE FROM `blocks` WHERE `page_id` = "' . $pageId . '"');
        mysql_query("INSERT INTO `blocks` (`page_id`, `text` ) VALUES ('" . $pageId . "', '" . $pageContent . "');");
    }
    
    public function setPageData($langId, $alias, $pageTitle, $pageKeywords, $pageDescription) 
    {
        $r = mysql_query('DELETE FROM `site_pages_langs_data` WHERE `lang_id` = "' . $langId . '" and `p`="' . $alias .'"');
        $sql = 'INSERT INTO `site_pages_langs_data` (`lang_id`, `p`, `pagetitle`, `seo_keywords`, `seo_description`, `type` ) VALUES ( "' . $langId . '", "' . mysql_real_escape_string($alias) . '", "' . mysql_real_escape_string($pageTitle) . '", "' . mysql_real_escape_string($pageKeywords) . '", "' . mysql_real_escape_string($pageDescription) . '", "content" )';
        mysql_query($sql);
    }

    public function setPageParent($pageId, $parentId)
    {
        $this->clearPageParent($pageId);
        mysql_query('INSERT INTO `site_pages_parents` SET `page_id` = "' . $pageId . '", ' . ' `parent_id` = "' . $parentId . '"');
        return mysql_insert_id();
    }
    
    public function clearPageParent($pageId)
    {
        mysql_query('DELETE FROM `site_pages_parents` WHERE `page_id`= "' . $pageId . '"');
        return mysql_affected_rows();
    }
    
    public function getPageParentId($pageId)
    {
        $sql = 'SELECT `parent_id` FROM `site_pages_parents` WHERE `page_id` = "' . $pageId . '"';
        $query = mysql_query($sql);
        if (mysql_num_rows($query)) {
            return mysql_result($query, 0);
        }
        return false;
    }
    
    public function deletePageFromMenu($pageId) 
    {
        $sql = 'SELECT id, properties FROM `site_blocks`;';
        $menus = array();
        $query = mysql_query($sql);
        while ($row = mysql_fetch_assoc($query)) {
            $menus[] = $row;
        }
        
        foreach ($menus as $menu) {
            $id = $menu['id'];
            $props = $menu['properties'];
            $ids = json_decode($props);
            $newIds = array();
            foreach ($ids as $id) {
                if ($id != $pageId) {
                    $newIds[] = $id;
                }
            }
            $props = json_encode($newIds);
            mysql_query('UPDATE `site_blocks` SET `properties`="'.  mysql_real_escape_string($props).'" WHERE `id`="'.$id.'"');
        }
    }
    
    public function addPageToMenu($pageId, $menuType)
    {
        $query = mysql_query('SELECT id, properties FROM `site_blocks` WHERE `type`="'.$menuType.'"');
        if ($row = mysql_fetch_assoc($query)) {
            $menu = $row;
            $id = $menu['id'];
            $props = $menu['properties'];
            $ids = json_decode($props);
            if (in_array($pageId, $ids)) {
                return false;
            }
            $ids[] = $pageId;
            $props = json_encode($ids);
            mysql_query('UPDATE `site_blocks` SET `properties`="' . mysql_real_escape_string($props) . '" WHERE `id`="' . $id . '"');
        } else {
            $ids = array($pageId);
            $props = json_encode($ids);
            mysql_query('INSERT INTO `site_blocks` SET `properties`="' . mysql_real_escape_string($props) . '", `type`="' . $menuType . '"');
        }
        
        return true;
    }
    
    public function deletePage($pageId)
    {
        $this->cms->DeletePageByID($pageId);
    }
    
    public function getPageInfo($pageId) 
    {
         return $this->cms->GetPageByID($pageId);           
    }
        
    public function getMenu($menu) 
    {
        $menu_json = $this->cms->getBlock($menu);
        $menu = $menu_json ? json_decode($menu_json) : array();
        return $menu;
    } 
    
    public function getPageContent($pageId)
    {
        $block = $this->cms->GetBlocksByPageID($pageId);
        return $block[0]['text'];
    }
    
    public function getPagesByLang($lang)
    {
        $digestClass = new DigestRepository($this->cms);
        $allPages = $digestClass->GetPagesByLang($lang);
        $allDocs = array();
        foreach($allPages as $page){
            $parent = $this->getPageParentId($page['id']);
            $page['children'] = array();
            if(!$parent) {
                $allDocs[$page['id']] = $page;
            }
        }
        $allDocs['calculator'] = array('id' => 'calculator', 'title' => LangAdmin::get('contents::Calculator'), 'alias' => 'calculator');
        
        if(CMS::IsFeatureEnabled('ProductComments'))
            $allDocs['reviews'] = array('id' => 'reviews', 'title' => LangAdmin::get('contents::Reviews'), 'alias' => 'reviews');
        if(CMS::IsFeatureEnabled('Digest'))
            $allDocs['digest'] = array('id' => 'digest', 'title' => LangAdmin::get('contents::Digest'), 'alias' => 'digest');
        if (CMS::IsFeatureEnabled('FleaMarket'))
            $allDocs['pristroy'] = array('id' => 'pristroy', 'title' => LangAdmin::get('contents::Pristroy'), 'alias' => 'pristroy');
        if (CMS::IsFeatureEnabled('ShopComments'))
            $allDocs['shopreviews'] = array('id' => 'shopreviews', 'title' => LangAdmin::get('contents::Shop_reviews'), 'alias' => 'shopreviews');

        return $allDocs;
    }

    public function saveMenu($menuType, $ids)
    {
        $menu = array();
        foreach ($ids as $id) {
            if( !in_array($id, $menu) ){
                $menu[] = $id;
            }
        }
        $menuItems = json_encode(CMS::removeNotAvailableMenuItems($menu));
        $q = mysql_query('SELECT COUNT(*) FROM `site_blocks` WHERE `type`="'.$menuType.'"');
        if(mysql_result($q, 0)){
            mysql_query('UPDATE `site_blocks` SET `properties`="'.  mysql_real_escape_string($menuItems).'" WHERE `type`="'.$menuType.'"');
        }
        else{
            mysql_query('INSERT INTO `site_blocks` SET `properties`="'.  mysql_real_escape_string($menuItems).'", `type`="'.$menuType.'"');
        }
    }
    
        
    public function getPageIdByAlias($alias, $language) 
    {
        $sql = 'SELECT `p`.`id` FROM `pages` `p`
                LEFT JOIN `site_pages_langs` `pl`
                ON `p`.`id`=`pl`.`page_id`
                LEFT JOIN `site_langs` `l`
                ON `pl`.`lang_id` = `l`.`id`
                WHERE `p`.`alias` = "' . mysql_real_escape_string($alias) . '" AND (`l`.`lang_code`="' . mysql_real_escape_string($language) . '"  OR `l`.`lang_code` IS NULL)
                ORDER BY `l`.`lang_code` DESC
                ';
        $result = mysql_query($sql);
        
        if (mysql_num_rows($result)) {
            return mysql_result($result, 0);
        }
        return false;
    }
    
}
