<?php

class TabsGenerator
{
    /**
     * @param string $tabsXMLPath
     * @param AdminUrlWrapper $pageUrl
     * @return string
     */
    public static function GetTabs($tabsXMLPath, $pageUrl)
    {
        if (! file_exists($tabsXMLPath)) {
            return "File $tabsXMLPath does not exist";
        }

        $tabs = simplexml_load_file($tabsXMLPath);

        $menu = new SimpleXMLElement('<div></div>');
        $menu['class'] = 'ot_sub_nav';
        $ul = $menu->addChild('ul');
        $ul['class'] = 'nav nav-tabs';

        foreach ($tabs->tab as $tab) {
            if (isset($tab['feature']) && !CMS::IsFeatureEnabled((string) $tab['feature']))
                continue;

            $isActive = $tab->xpath('page[@data-action="' . $pageUrl->GetAction() . '" and @data-cmd="' . strtolower($pageUrl->GetCmd()) . '"]');
            if (!$isActive)
                $isActive = $tab->xpath('page[@data-action="*" and @data-cmd="' . strtolower($pageUrl->GetCmd()) . '"]');

            $li = $ul->addChild('li');
            if ($isActive) {
                $li['class'] = 'active';
            }

            if ($tab['feature'] && ! CMS::IsFeatureEnabled($tab['feature'])) {
                $tab['disabled'] = true;
            }
            $a = $li->addChild('a', LangAdmin::get((string)$tab['title']));
            if (empty($tab['disabled'])) {
                $a['href'] = $pageUrl->AssignCmdAndDo((string)$tab['cmd'], (string)$tab['action']);
            } else {
                $li['class'] = !empty($li['class']) ? $li['class'] . ' disabled' : 'disabled';
            }
        }

        return $menu->asXML();
    }

    /**
     * @param $tabsXMLPath
     * @param AdminUrlWrapper $pageUrl
     * @return mixed|string
     */
    public static function GetSubTabs($tabsXMLPath, $pageUrl)
    {
        if (! file_exists($tabsXMLPath)) {
            return "File $tabsXMLPath does not exist";
        }

        $tabs = simplexml_load_file($tabsXMLPath);

        $menu = new SimpleXMLElement('<div></div>');
        $menu['class'] = 'tabbable ot_sub_sub_nav';
        $ul = $menu->addChild('ul');
        $ul['class'] = 'nav nav-pills';

        foreach ($tabs->tab as $tab) {
            $isActive = $tab->xpath('page[@data-action="' . $pageUrl->GetAction() . '" and @data-cmd="' . strtolower($pageUrl->GetCmd()) . '"]');

            $li = $ul->addChild('li');
            if ($isActive) {
                $li['class'] = 'active';
            }

            $a = $li->addChild('a', LangAdmin::get((string)$tab['title']));
            if (empty($tab['disabled'])) {
                $a['href'] = $pageUrl->AssignCmdAndDo((string)$tab['cmd'], (string)$tab['action']);
            } else {
                $li['class'] = !empty($li['class']) ? $li['class'] . ' disabled' : 'disabled';
            }
        }

        return $menu->asXML();
    }
}
