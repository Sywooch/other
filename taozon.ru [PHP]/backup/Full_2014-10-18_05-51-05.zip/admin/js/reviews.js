$(document).ready(function() {
    $("#pages").change(function() {
        $("#perPager").submit();
    });
});