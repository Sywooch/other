<script>
    SiteConfig = {
        hide_work_shedule: '<?=$Config->Get('hide_work_shedule')?>',
        hide_operator: '<?=$Config->Get('hide_operator')?>',
        online_chat_code: '<?=$Config->Get('online_chat_code')?>',
        left_menu: '<?=$Config->Get('left_menu')?>',
        rtl: '<?=$Config->Get('rtl')?>',
        display_as_carousel: '<?=$Config->Get('display_as_carousel')?>',
        product_tabs: '<?=$Config->Get('product_tabs')?>',
        default_perpage: '<?=$Config->Get('default_perpage')?>',
        pager_count_print: '<?=$Config->Get('pager_count_print')?>',
        search_category_mode: '<?=$Config->Get('search_category_mode')?>',
        origin_package: '<?=$Config->Get('origin_package')?>',
        payment_in_cash: '<?=$Config->Get('payment_in_cash')?>'
    }

    SiteConfigGeneralHideSelects = {
        hide_taobao_responses: '<?=$Config->Get('hide_taobao_responses')?>',
        hide_item_info_status: '<?=$Config->Get('hide_item_info_status')?>',
        hide_item_info_weight: '<?=$Config->Get('hide_item_info_weight')?>',
        hide_taobao_link: '<?=$Config->Get('hide_taobao_link')?>',
        hide_item_info_price1: '<?=$Config->Get('hide_item_info_price1')?>',
        hide_item_info_price_local_delivery: '<?=$Config->Get('hide_item_info_price_local_delivery')?>',
        show_user_history_views: '<?=$Config->Get('show_user_history_views')?>',
        hide_item_info_features: '<?=$Config->Get('hide_item_info_features')?>',
        hide_item_property_price_range: '<?=$Config->Get('hide_item_property_price_range')?>',
        hide_item_site_responses: '<?=$Config->Get('hide_item_site_responses')?>',
        hide_item_info_in_existence: '<?=$Config->Get('hide_item_info_in_existence')?>',
        hide_item_info_sales_last30day: '<?=$Config->Get('hide_item_info_sales_last30day')?>'
    }
</script>
