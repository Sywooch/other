// JavaScript Document
  function ShowEmptyCars() {	
     if (document.getElementById('ULEmpty').style.height == '0px') {
        document.getElementById('ULEmpty').style.height = 'auto';   
     } else {
		document.getElementById('ULEmpty').style.height = '0px'; 
	 }
  }