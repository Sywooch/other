CREATE TABLE IF NOT EXISTS `site_taobao_out_sids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trade_id` varchar(50) DEFAULT NULL,
  `out_sid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
