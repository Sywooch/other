ALTER IGNORE table `site_categories` ADD UNIQUE KEY `category_id`(`category_id`);
ALTER IGNORE table `site_categories` ADD UNIQUE KEY `alias`(`alias`);