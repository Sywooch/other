$.fn.editable.defaults.mode = 'inline'; //turn to inline mode
$(document).ready( function () {

    var XEditableFieldView = Backbone.View.extend({
        prepareXEditablePossibleValues: function(){
            var values = [];
            try{
                for(var i in this.model.get('valuesList')){
                    var key = this.model.get('name')+'_value:'+this.model.get('valuesList')[i];
                    var text = '';
                    if(trans.get(key) == key)
                        text = trans.get(this.model.get('name')+'_value:*');
                    else
                        text = trans.get(key);

                    values.push({
                        value: this.model.get('valuesList')[i],
                        text: text
                    });
                }
            }
            catch(e){
            }
            return values;
        },
        prepareXEditableInitParameters: function(){
            var model = this.model;
            var parameters = this.model.attributes;
            parameters.source = this.prepareXEditablePossibleValues();

            if (parameters.value === '' && parameters.type == 'select') {
                parameters.value = 0;
            }
            if (parameters.value === 'checked') {
                parameters.value = 1;
            }

            parameters.success = function(response, value)
            {
                var dependsElement = $('.ot_show_depends[data-depends="'+model.get('name')+'"]');
                if(dependsElement.length){
                    var showIf = dependsElement.attr('data-show-cond');
                    if(showIf == value)
                        dependsElement.show();
                    else
                        dependsElement.hide();
                }
            }
            if(parameters.processSubmit == true){
            	parameters.url = function(scope, params){
            		if(window[parameters.submitHandler])
            			window[parameters.submitHandler](scope,params);
            	};
            }

            return parameters;
        },
        render: function()
        {
            var self = this;

            var preparedParameters = this.prepareXEditableInitParameters();

            $('[data-field="'+this.model.get('name')+'"]:first').replaceWith(
                renderInlineEditableElement(this.model.get('type'), preparedParameters)
            );

            $('.ot_inline_editable[data-name="'+this.model.get('name')+'"]').editable(
                preparedParameters
            ).on('shown', function() {
                var editable = $(this).data('editable');
                editable.input.$input.closest('form').parents('div:first').on('save', function(e, params){
                    if (params.newValue !== '') {
                        var key = self.model.get('displayVlaue');
                        if (key) {
                            editable.$element.text(trans.get(key));
                        }
                    }
                });
            });
            $('.ot_inline_editable[data-name="'+self.model.get('name')+'"]').data('editable').setValue(preparedParameters.value);

            return this;
        }
    });

    _.each(InlineFields.models, function(field){
        var view = new XEditableFieldView({
            model: field
        });
        view.render();
    });

} );
