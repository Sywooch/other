var OrdersPage = Backbone.View.extend({
    "el": ".orders-common-wrapper",
    "events": {
        "click .checkAll"       : "toggleCheckAll",
        "click #restoreOrders"  : "bulkRestoreOrdersAction",
        "click #cancelOrders"   : "bulkCancelOrdersAction",

        "click #showAllFilters" : "showAllFilters",
        "change #periodFilter"  : "setPeriodFilter",

        "click .exportOrder"    : "exportOrderAction",
        "click .restoreOrder"   : "restoreOrderAction",
        "click .cancelOrder"    : "cancelOrderAction",

        "click .deleteItemFromOrder"    : "deleteItemFromOrderAction",
        "click .splitItemQuantity"      : "splitItemQuantityAction",
        "click .changeItemStatus A"     : "changeItemStatusAction",

        "click .itemRow span[data-target*=more-info]" : "toggleItemInfo",

        "change input[type=checkbox]" : "updateSelectedRows",
    },
    render: function()
    {
        return this;
    },
    initialize: function(){
        this.render();
    },
    toggleItemInfo: function(ev){
        var targetDiv = $($(ev.currentTarget).data('target'));
        if (targetDiv.find('> div.well').hasClass('item-details-loaded')) {
            return;
        }
        var itemRow = $(ev.target).closest('tr');
        var item = OrdersItems.get(itemRow.attr('id'));
        var order = Orders.get(item.get('orderid'));
        order.set('numericId', itemRow.data('order-numeric-id'));
        item.set('imagePreview', itemRow.data('image-preview'));
        var itemPrice = parseFloat(item.get('newpricecust')) ? item.get('newpricecust') : item.get('pricecust');
        item.set('NewAmountCust', parseFloat(itemPrice * item.get('qty')));
        var config = item.get('configtext').split(';');
        var originalConfig = item.get('configexternaltextorig').split(';');
        item.set('config', _.filter(config.concat(originalConfig), function (configItem) {
            return configItem.length;
        }));

        $.get('templates/orders/item.html?' + Math.random(), function (tpl) {
            var itemDetailsHtml = _.template(tpl, {'item': item, 'order': order});
            targetDiv.html(itemDetailsHtml);

            // Вывести цену товара
            $.get('templates/inline_elements/text.html?' + Math.random(), function (tpl) {
                var itemPriceHtml = _.template(tpl, {
                    'name': 'newPrice',
                    'value': itemPrice,
                    'saveUrl': 'index.php?cmd=orders&do=changeItemPrice',
                    'parameters': {
                        'useLabel': false,
                        'useWrapper': false,
                        'pk': item.get('id') + '_' + item.get('orderid'),
                    }
                });
                targetDiv.find('.editablePrice').html(itemPriceHtml)
                if (item.get('statusid') != 2) { // 2 - Оплачен
                    targetDiv.find('.editablePrice').find('a').editable({
                        inputclass: 'input-custom-mini',
                        clear: false,
                        success: function(data){
                            if (data && 'undefined' !== typeof data.amountcust) {
                                targetDiv.find('.amountcust span').html(
                                    parseFloat(data.amountcust) + '&nbsp;' + order.get('currencysign')
                                );
                                var newStatusCode = 3; // Подтверждение цены
                                var newStatusName = itemRow.find('.changeItemStatus a[data-status=' + newStatusCode + ']').text();
                                itemRow.find('.statusName').text($.trim(newStatusName));
                                item.set('statusname', $.trim(newStatusName));
                                item.set('statusid', newStatusCode);
                                item.set('statuscode', newStatusCode);
                            }
                        }
                    });
                }
            });
        });
    },
    bulkRestoreOrdersAction: function(ev){
        ev.preventDefault();
        showError('bulkRestoreOrdersAction: Not implemented yet');
        return false;
    },
    bulkCancelOrdersAction: function(ev){
        ev.preventDefault();
        showError('bulkCancelOrdersAction: Not implemented yet');
        return false;
    },
    restoreOrderAction: function(ev){
        ev.preventDefault();
        modalDialog(trans.get('Confirm'), trans.get('Really_restore_this_order'), function(dialog){
            var target = this.$(ev.target);
            var button = target.parents('ul:first').prev();
            button.addClass('disabled').find('i').attr('class', 'ot-preloader-micro');
            button.parent().removeClass('open');
            $.post(
                target.data('action'),
                {'id': target.parents('tr').attr('id')},
                function (data) {
                    button.removeClass('disabled').find('i').attr('class', 'icon-cog');
                    if (! data.error) {
                        showMessage(data.message ? data.message : trans.get('Notify_success'));
                        target.parents('tr').next().andSelf().remove();
                    } else {
                        showError(data);
                    }
                }, 'json'
            );
        });
        return false;
    },
    cancelOrderAction: function(ev){
        ev.preventDefault();
        modalDialog(trans.get('Confirm'), trans.get('Really_cancel_this_order'), function(dialog){
            var target = this.$(ev.target);
            var button = target.parents('ul:first').prev();
            button.addClass('disabled').find('i').attr('class', 'ot-preloader-micro');
            button.parent().removeClass('open');
            $.post(
                target.data('action'),
                {'id': target.parents('tr').attr('id')},
                function (data) {
                    button.removeClass('disabled').find('i').attr('class', 'icon-cog');
                    if (! data.error) {
                        showMessage(data.message ? data.message : trans.get('Notify_success'));
                        target.parents('tr').next().andSelf().remove();
                    } else {
                        showError(data);
                    }
                }, 'json'
            );
        });
        return false;
    },
    deleteItemFromOrderAction: function(ev){
        ev.preventDefault();
        modalDialog(trans.get('Confirm'), trans.get('Really_delete_this_item_from_order'), function(dialog){
            var target = this.$(ev.target);
            var button = target.parents('ul:first').prev();
            button.addClass('disabled').find('i').attr('class', 'ot-preloader-micro');
            button.parent().removeClass('open');
            $.post(
                target.data('action'),
                {'itemid': target.parents('tr').attr('id'), 'orderid': target.parents('tr').data('order-id')},
                function (data) {
                    button.removeClass('disabled').find('i').attr('class', 'icon-cog');
                    if (! data.error) {
                        showMessage(data.message ? data.message : trans.get('Notify_success'));
                        target.parents('tr').next().andSelf().remove();
                    } else {
                        showError(data);
                    }
                }, 'json'
            );
        }, {
           'confirm' : trans.get('Delete'),
        });
        return false;
    },
    changeItemStatusAction: function(ev){
        ev.preventDefault();
        var target = this.$(ev.target);
        var button = target.parents('.btn-group:first').find('button');
        button.addClass('disabled').find('i').attr('class', 'ot-preloader-micro');
        button.parent().removeClass('open');
        var itemRow = $(ev.target).closest('tr');
        var item = OrdersItems.get(itemRow.attr('id'));
        $.post(
            'index.php?cmd=orders&do=changeItemStatus',
            {
                'itemId'    : item.get('id'),
                'orderId'   : item.get('orderid'),
                'status'    : target.data('status'),
                'comment'   : item.get('operatorcomment'),
                'quantity'  : item.get('qty')
            },
            function (data) {
                button.removeClass('disabled').find('i').attr('class', 'icon-star-empty');
                if (! data.error) {
                    showMessage(data.message ? data.message : trans.get('Notify_success'));
                    itemRow.find('.statusName').text($.trim(target.text()));
                    item.set('statusname', $.trim(target.text()));
                    item.set('statusid', target.data('status'));
                    item.set('statuscode', target.data('status'));
                } else {
                    showError(data);
                }
            }, 'json'
        );
        return false;
    },
    splitItemQuantityAction: function(ev){
        ev.preventDefault();
        var itemRow = $(ev.target).closest('tr');
        var item = OrdersItems.get(itemRow.attr('id'));
        if (item.get('qty') <= 1) {
            return false;
        }
        modalDialog(
            trans.get('Split_item_suggestion'),
            '<input type="text" name="splitQuantity" value="1" />',
            function (dialog) {
                var splitQuantity = parseInt(dialog.find('input[name=splitQuantity]').val());
                if (splitQuantity < 1 || splitQuantity >= item.get('qty')) {
                    showError(trans.get('Incorrect_quantity'));
                    return false;
                }
                var target = this.$(ev.target);
                var button = target.parents('ul:first').prev();
                button.addClass('disabled').find('i').attr('class', 'ot-preloader-micro');
                button.parent().removeClass('open');
                $.post(
                    target.data('action'),
                    {
                        'itemId': item.get('id'),
                        'orderId': item.get('orderid'),
                        'splitQuantity': splitQuantity
                    },
                    function (data) {
                        button.removeClass('disabled').find('i').attr('class', 'icon-cog');
                        if (! data.error) {
                            showMessage(data.message ? data.message : trans.get('Notify_success'));
                            window.location.reload();
                        } else {
                            showError(data);
                        }
                    }, 'json'
                );
            }, {
               'confirm' : trans.get('Split'),
            }
        );
        return false;
    },
    showAllFilters: function(ev){
        ev.preventDefault();
        this.$('#filtersShort').fadeOut(100);
        this.$('#filtersAll').fadeIn(100);
        return false;
    },
    setPeriodFilter: function(ev){
        ev.preventDefault();
        var period = $(ev.target).val();
        if ('undefined' !== typeof periodsFilters[period]) {
            $('#date-start').datepicker('update', new Date(periodsFilters[period].start));
            $('#date-start-display').val($('#date-start').data('date'));
            $('#date-end').datepicker('update', new Date(periodsFilters[period].end));
            $('#date-end-display').val($('#date-end').data('date'));
        }
        return false;
    },
    toggleCheckAll: function(ev){
        var self = this.$(ev.target);
        self.parents('thead').next().find('input[type=checkbox]')
            .prop('checked', self.is(':checked'))
            .trigger('change');
    },
    updateSelectedRows: function(ev){
        var checkbox = $(ev.target);
        if (checkbox.hasClass('checkAll')) {
            return;
        }
        if (checkbox.is(':checked')) {
            checkbox.closest('tr').addClass('selected_item').next('tr').addClass('selected_item');
        } else {
            checkbox.closest('tr').removeClass('selected_item').next('tr').removeClass('selected_item');
        }
    }
});

$(function(){
    var O = new OrdersPage();
});
