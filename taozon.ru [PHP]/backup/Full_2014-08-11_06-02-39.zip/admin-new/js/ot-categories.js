var Categories = new Backbone.Collection();
var CategoriesPage = Backbone.View.extend({
    "el": ".categories-wrapper",
    "events": {
    	"submit #import-upload-form": "checkFileSelection",

    },
    "rootCategory": 'Root_category',
    "lastLoadedNode": null,
    checkFileSelection: function(){
    	var file = $("#import-upload-form input[type=file]").val();
    	if( file == '') {
			showError(trans.get('Please_select_file_before_upload'));
        	$('#import-upload-form .ot-preloader-micro').hide();
        	$('#import-upload-form .btn-primary').removeAttr('disabled');

    		return false;
    	}
    	return true;
    },
    render: function()
    {
        return this;
    },
    initialize: function() 
    {
        var self = this;
        this.render();
        $("#jstree")
            .bind("before.jstree", function(e, data) {
            })
            .bind("open_node.jstree", function(e, data) {
                console.log(data, 'open_node.jstree');
                data.inst.select_node("#phtml_2", true);
            })
            .jstree({
                // ���������� �������
                "plugins" : ["themes","json_data","ui","crrm","dnd","search","types","sort"], 
                "themes" : {
                    "theme" : "classic",
                    "dots" : true,
                    "icons" : true
                },
                "sort": function (a, b) {
                    return parseInt($(a).attr('i')) > parseInt($(b).attr('i')) ? 1 : -1; 
                },
                "json_data" : {
                    "data" : self.getPreparedCategories(CategoriesCategories.models), // 1
                    'correct_state': true,
                    'progressive_render': true,
                    'progressive_unload': true,
                    "ajax" : {
                        "url" : 'index.php?cmd=Categories&do=getCategories',
                        // the `data` function is executed in the instance's scope
                        // the parameter is the node being loaded
                        // (may be -1, 0, or undefined when loading the root nodes)
                        "data" : function (node) {
                            // the result is fed to the AJAX request `data` option
                            return {
                                "parentId" : node.attr ? node.attr("id") : 0
                            };
                        },
                        "success" : function (data) {
                            if (data.categories) {
                                if (data.categories.length) {
                                    return self.getPreparedCategories(data.categories);
                                } else if (self.lastLoadedNode) {
                                    self.lastLoadedNode.removeClass('jstree-open').addClass('jstree-leaf');
                                }
                            } else {
                                showError(data.message ? data.message : trans.get('Notify_error'));
                            }
                        }
                    }
                }
            })
            .bind("create.jstree", function (e, node) {
                var parentId = 0;
                var categoryId = $(node.rslt.obj).attr('externalid');
                var alias = $(node.rslt.obj).attr('alias');
                var approxWeight = $(node.rslt.obj).attr('approxweight');
                var meta_pagetitle = $(node.rslt.obj).attr('seo_pagetitle');
                var meta_title = $(node.rslt.obj).attr('seo_title');
                var meta_keywords = $(node.rslt.obj).attr('seo_keywords');
                var meta_description = $(node.rslt.obj).attr('seo_description');
                var seoText = $(node.rslt.obj).attr('seoText');
                var parentId = $(node.rslt.obj).attr('parentId');
                
                $.post(
                    "index.php?cmd=Categories&do=createCategory",
                    {
                        "parentId" : parentId < 0 ? 0 : parentId,
                        "categoryId": categoryId,
                        "position" : node.rslt.position,
                        "name" : node.rslt.name,
                        "approxweight": approxWeight,
                        "alias": alias,
                        "meta_pagetitle": meta_pagetitle,
                        "meta_title": meta_title,
                        "meta_keywords": meta_keywords,
                        "meta_description": meta_description,
                        "seoText": seoText,
                    },
                    function (data) {
                        if (data.newId) {
                            var li = $(node.rslt.obj);
                            $(li).attr("id", data.newId);
                            self.addJSTreeItemTaskBar(li);
                            
                            var ul =$(li).closest('ul'); 
                            
                            $("#jstree").jstree("sort",ul);
                            
                        } else {
                            $.jstree.rollback(node.rlbk);
                            showError(data.message ? data.message : trans.get('Notify_error'));
                        }
                    }, 'json'
                );
            })
            .bind("remove.jstree", function (e, node) {
                    $.post(
                        "index.php?cmd=Categories&do=removeCategory",
                        {"id" : node.rslt.obj.attr("id")},
                        function (data) {
                            if (data.error) {
                                node.inst.refresh();
                                showError(data.message ? data.message : trans.get('Notify_error'));
                            }
                        }, 'json'
                    );
                return false;
            })
            .bind("rename.jstree", function (e, node) {
                if (node.rslt.new_name == node.rslt.old_name) {
                    return;
                }
                $.post(
                    "index.php?cmd=Categories&do=renameCategory",
                    {"id" : node.rslt.obj.attr("id"), "newName" : node.rslt.new_name},
                    function (data) {
                        if (data.error) {
                            $.jstree.rollback(node.rlbk);
                            showError(data.message ? data.message : trans.get('Notify_error'));
                        }
                    }, 'json'
                );
            })
            .bind("move_node.jstree", function (e, node) {
                node.rslt.o.each(function (i) {
                    $.ajax({
                        async : true,
                        type: 'POST',
                        dataType: 'json',
                        url: "index.php?cmd=Categories&do=moveCategory",
                        data : {
                            "id" : node.rslt.o.attr('id'),
                            "parentId" : node.rslt.op.attr("id"),
                            "newParentId" : node.rslt.cr === -1 ? 0 : node.rslt.np.attr("id")
                        },
                        success : function (data) {
                            if (data.error) {
                                $.jstree.rollback(node.rlbk);
                                showError(data.message ? data.message : trans.get('Notify_error'));
                            } else {
                                $(node.rslt.oc).attr("id", data.id);
                                if (node.rslt.cy && $(node.rslt.oc).children("UL").length) {
                                    node.inst.refresh(node.inst._get_parent(node.rslt.oc));
                                }
                            }
                        }
                    });
                });
            })
            .one("reopen.jstree", function (event, data) {
            })
            // 3) but if you are using the cookie plugin or the UI `initially_select` option:
            .one("reselect.jstree", function (event, data) {
            })
            .bind("loaded.jstree", function(e, data) {
                $('.categories-wrapper #jstree li').each(function() {
                    self.addJSTreeItemTaskBar(this);
                });
                
                $('.ot_show_crud_cat_item_window').click(function() {
                	$('.ot_crud_cat_item_window .modal-body #categoryName').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #categoryId').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #alias').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #approxweight').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #meta_title').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #meta_title_prefix').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #meta_title_suffix').attr('value', '');
                    $('.ot_crud_cat_item_window .modal-body #meta_keywords').html('');
                    $('.ot_crud_cat_item_window .modal-body #meta_description').html('');
                    $('.ot_crud_cat_item_window .modal-body #seoText').html('');
                    $('.ot_crud_cat_item_window #ot_cat_filters_head').hide();
                    $('.ot_crud_cat_item_window .modal-body #parentCategory').attr('value','');
                    $('.ot_crud_cat_item_window .modal-body #parentCategoryId').attr('value',0);
                    
                    var content = $('.ot_crud_cat_item_window .modal-body').html();
                    content = content.replace(new RegExp("ot_cat_data", 'g'), "ot_cat_data1");
                    content = content.replace(new RegExp("ot_cat_meta", 'g'), "ot_cat_meta1");
                    content = content.replace(new RegExp("ot_cat_content", 'g'), "ot_cat_content1");
                    content = content.replace(new RegExp("ot_cat_filters", 'g'), "ot_cat_filters1");
                    content = content.replace(new RegExp("seoText", 'g'), "seoText1");
                    content = content.replace(new RegExp('<div class="editableform-loading"></div>', 'g'), "");
                    if (tinyMCE.editors.length > 0) {
                        tinyMCE.remove(tinyMCE.editors[0]);
                    }
                    modalDialog(trans.get('Add_category'), content, function(body) {
                        var categoryName = $('#categoryName', body).val();
                        var categoryId = $('#categoryId', body).val();
                        var alias = $('#alias', body).val();
                        var approxWeight = $('#approxweight', body).val();
                        var meta_pagetitle = $('#meta_title', body).val();
                        var meta_title = $('#meta_title_prefix', body).val() + '||' + $('#meta_title_suffix', body).val();
                        var meta_keywords = $('#meta_keywords', body).val();
                        var meta_description = $('#meta_description', body).val();
                        var seoText = tinyMCE.editors[0].getContent();
                        var parentId = $('#parentCategoryId', body).val();
                        
                        if (! categoryName.length) {
                            showError(trans.get('Enter_category_name_promt'));
                            return false;
                        }                        
                        
                        var aliasPattern = /^[a-z]+([-_]?[a-z0-9]+){0,2}$/i;                
                        if (! aliasPattern.test(alias)) {
                            showError(trans.get('Category_alias_is_invalid'));
                            return false;
                        }
                        
                        
                        var parentLi = 0;
                        if (parentId && parentId != '0') {
                        	parentLi = $('#jstree li[id="'+parentId+'"]');
                        }
                        
                        $("#jstree").jstree("create", parentLi, 'last', categoryName, function(node) {
                            $(node).attr('externalid', categoryId);
                            $(node).attr('alias', alias);
                            $(node).attr('approxweight', approxWeight);
                            $(node).attr('seo_pagetitle', meta_pagetitle);
                            $(node).attr('seo_title', meta_title);
                            $(node).attr('seo_keywords', meta_keywords);
                            $(node).attr('seo_description', meta_description);
                            $(node).attr('seoText', seoText);
                            $(node).attr('parentId', parentId);
                        }, true);
                        return true;
                      }, {confirm: trans.get('Save'), cancel: trans.get('Cancel') });
                });
            })
            .bind("select_node.jstree", function (event, data) {
            })
            .bind("create_node.jstree", function (event, data) {
            })
            
            .bind("load_node.jstree", function (event, data) {
                if (undefined !== data) {
                    var item = data.args[0][0];
                    if (undefined != item) {
                        $('li',item).each(function() {
                            self.addJSTreeItemTaskBar(this);
                        });
                        self.lastLoadedNode = data.rslt.obj;
                    }
                }
            });
        
        
        $('.confirmDialog').on('shown',function() {
            var width = jQuery(window).width();
            var left = (width-690) / 2; 
            $('.confirmDialog').css('width', '690px');
            $('.confirmDialog').css('left', left+'px');
            $('.confirmDialog').css('margin-left', '0px');
            $('.confirmDialog').off('hidden.restoreDefaults');
            if (tinyMCE.editors.length==0) {
                tinyMCE.init({
                    mode : "exact",
                    elements : "seoText1",
                    theme : "advanced",
                    height: 230,
                    plugins : "table,heading,advhr,advimage,advlink,paste,fullscreen,noneditable,contextmenu,inlinepopups,emotions,media,insertdatetime,nonbreaking",
                    theme_advanced_buttons1_add_before : "newdocument,separator",
                    theme_advanced_buttons1_add_before : "fontselect,fontsizeselect,h1,h2,h3,h4,h5,h6,separator",
                    theme_advanced_buttons2_add : "separator,forecolor,backcolor,liststyle,separator,insertdate,inserttime",
                    theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator",
                    theme_advanced_buttons3_add_before : "tablecontrols,separator",
                    theme_advanced_buttons3_add : "flash,advhr,emotions,media,nonbreaking,separator,fullscreen",
                    theme_advanced_toolbar_location : "top",
                    theme_advanced_toolbar_align : "left",
                    extended_valid_elements : "hr[class|width|size|noshade],ul[class=listUL],ol[class=listOL]",
                    file_browser_callback : "ajaxfilemanager",
                    paste_use_dialog : false,
                    theme_advanced_resizing : true,
                    theme_advanced_resize_horizontal : true,
                    apply_source_formatting : true,
                    force_br_newlines : true,
                    forced_root_block : "div",
                    force_p_newlines : false,
                    relative_urls : true,
                    heading_clear_tag : "p",
                    content_css : "../css/style.css"
                });
                if (tinyMCE.editors.length > 0) {
                	tinyMCE.editors[0].setContent($('.confirmDialog .modal-body #seoText1').html());
                }
                
            }
            // parent category typeahead
            $('.confirmDialog #parentCategory').typeahead({
            	source: function (query, process) 
            	{
            		return $.get('index.php?cmd=categories&do=getHint&name='+query, {}, function (response) {
            			var data = new Array();
            			$.each(response, function(i, item)
            			{
            				data.push(item.id+'|'+item.label);
                        });	
            			return process(data);
            		}, 'json');
            	},
            	//output in list
            	highlighter: function(item) 
            	{
            		var parts = item.split('|');
            		return parts[1];
            	},
                //select in list
            	updater: function(item) 
            	{
            		var parts = item.split('|');
                    $('.confirmDialog #parentCategoryId').val(parts[0]);
                    return parts[1];
            	},           	
            });
            
            $('.confirmDialog .mceEditor').show();
        });

        $('#import-upload-form').submit(function(){
        	$('#import-upload-form .ot-preloader-micro').show();
        	$('#import-upload-form .btn-primary').attr('disabled','disabled');
        	return true;
        });

    },
    getPreparedCategories: function (categories, addRootCategory) 
    {
        var preparedCategories = [];
        _.each(categories, function (item) {
            var category = item.attributes ? item.attributes : item;
            var prepared = {
                "data" : {
                    "title" : category.Name,
                    "metadata" : '<div class="actions"></div>',
                },
                "attr" : category
            };
            if (category.IsParent == 'true') {
                prepared.icon = 'folder';
                prepared.children = [];
            } else {
                prepared.icon = 'folder';
            }
            if (category.DeleteStatusUI == 'true') {
                prepared.data.icon = 'folderr';
            } 
            
            preparedCategories.push(prepared);
        });
        if ('undefined' !== typeof addRootCategory) {
            preparedCategories = [{
                'data' : {
                    'title' : trans.get('Root_category')
                },
                'attr' : {
                    'id'    : 0,
                    'class' : self.rootCategory
                },
                'state' : 'open',
                'children' : [preparedCategories]
            }];
        }
        
        return preparedCategories;
    },
    assignItemHandlers: function(item) {
        $('.ot_cat_actions .add_category_button',item).click(function() {
            var li = $(this).closest('li');
            $('.ot_crud_cat_item_window .modal-body #categoryName').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #categoryId').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #alias').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #approxweight').attr('value', '');
            
            $('.ot_crud_cat_item_window .modal-body #meta_title').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_title_prefix').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_title_suffix').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_keywords').html('');
            $('.ot_crud_cat_item_window .modal-body #meta_description').html('');
            $('.ot_crud_cat_item_window .modal-body #seoText').html('');
            $('.ot_crud_cat_item_window .modal-body #parentCategory').attr('value',$('a:first',li).text().trim());
            $('.ot_crud_cat_item_window .modal-body #parentCategoryId').attr('value',$(li).attr('id'));

            $('#ot_cat_data').tab('show');
            
            $('.ot_crud_cat_item_window #ot_cat_filters_head').hide();
            
            var content = $('.ot_crud_cat_item_window .modal-body').html();
            content = content.replace(new RegExp("ot_cat_data",'g'),"ot_cat_data1");
            content = content.replace(new RegExp("ot_cat_meta",'g'),"ot_cat_meta1");
            content = content.replace(new RegExp("ot_cat_content",'g'),"ot_cat_content1");
            content = content.replace(new RegExp("ot_cat_filters",'g'),"ot_cat_filters1");
            content = content.replace(new RegExp("seoText",'g'),"seoText1");
            content = content.replace(new RegExp('<div class="editableform-loading"></div>', 'g'), "");

            if (tinyMCE.editors.length > 0) {
                tinyMCE.remove(tinyMCE.editors[0]);
            }
            modalDialog(trans.get('Add_category'), content, function(body) {
                var categoryName = $('#categoryName', body).val();
                var categoryId = $('#categoryId', body).val();
                var alias = $('#alias', body).val();
                var approxWeight = $('#approxweight', body).val();
                var meta_pagetitle = $('#meta_title', body).val();
                var meta_title = $('#meta_title_prefix', body).val() + '||' + $('#meta_title_suffix', body).val();
                var meta_keywords = $('#meta_keywords', body).val();
                var meta_description = $('#meta_description', body).val();
                var seoText = tinyMCE.editors[0].getContent();
                var parentId = $('#parentCategoryId', body).val();
                
                var aliasPattern = /^[a-z]+([-_]?[a-z0-9]+){0,2}$/i;                
                if (! aliasPattern.test(alias)) {
                	showError(trans.get('Category_alias_is_invalid'));
                    return false;
                }
                
                if (! categoryName.length) {
                    showError(trans.get('Enter_category_name_promt'));
                    return false;
                }
                
                var parentLi = li;
                if (parentId && parentId != '0') {
                	parentLi = $('#jstree li[id="'+parentId+'"]');
                	if (!parentLi) {
                		parentLi = 0;
                	}
                }
                
                $("#jstree").jstree("create", parentLi, 'last', categoryName, function(node) {
                    $(node).attr('externalid', categoryId);
                    $(node).attr('alias', alias);
                    $(node).attr('approxweight', approxWeight);
                    $(node).attr('seo_pagetitle', meta_pagetitle);
                    $(node).attr('seo_title', meta_title);
                    $(node).attr('seo_keywords', meta_keywords);
                    $(node).attr('seo_description', meta_description);
                    $(node).attr('seoText', seoText);
                    $(node).attr('parentId',parentId);
                }, true);
                return true;
              }, {confirm: trans.get('Save'), cancel: trans.get('Cancel') });
        }); 
        $('.ot_cat_actions .rename_category_button', item).click(function() {
            var li = $(this).closest('li');
            var categoryId = $(li).attr('id');
            var parent = li.parent().closest('li');
            var parentId = parent.attr('id');
            var oldCategoryName = $('a:first',li).text();
            var externalId = $(li).attr('externalid');
            var oldAlias = $(li).attr('alias');
            oldCategoryName = oldCategoryName.trim();
            var oldApproxWeight = $(li).attr('approxweight');
            $('.ot_crud_cat_item_window .modal-body #categoryName').attr('value', oldCategoryName);
            $('.ot_crud_cat_item_window .modal-body #categoryId').attr('value', externalId);
            $('.ot_crud_cat_item_window .modal-body #alias').attr('value', oldAlias);
            $('.ot_crud_cat_item_window .modal-body #approxweight').attr('value', oldApproxWeight);
            
            $('.ot_crud_cat_item_window .modal-body #meta_title').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_title_prefix').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_title_suffix').attr('value', '');
            $('.ot_crud_cat_item_window .modal-body #meta_keywords').html('');
            $('.ot_crud_cat_item_window .modal-body #meta_description').html('');
            $('.ot_crud_cat_item_window .modal-body #seoText').html('');
            
            $('.ot_crud_cat_item_window .modal-body #parentCategory').attr('value',$('a:first',parent).text().trim());
            $('.ot_crud_cat_item_window .modal-body #parentCategoryId').attr('value',parentId);
            
            $('.ot_crud_cat_item_window .modal-body #meta_title').attr('value', $(li).attr('seo_pagetitle'));
            var prefixSuffix = $(li).attr('seo_title');
            if (prefixSuffix) {
                var ps = prefixSuffix.split('||');
                if (ps.length>0) {
                    $('.ot_crud_cat_item_window .modal-body #meta_title_prefix').attr('value', ps[0]);
                }
                if (ps.length>1) {
                    $('.ot_crud_cat_item_window .modal-body #meta_title_suffix').attr('value', ps[1]);
                }
            } else {
                $('.ot_crud_cat_item_window .modal-body #meta_title_prefix').attr('value', '');
                $('.ot_crud_cat_item_window .modal-body #meta_title_suffix').attr('value', '');
                
            }
            
            $('.ot_crud_cat_item_window .modal-body #meta_keywords').html($(li).attr('seo_keywords'));
            $('.ot_crud_cat_item_window .modal-body #meta_description').html($(li).attr('seo_description'));

            $('.ot_crud_cat_item_window #ot_cat_filters_head').show();
            
            var content = $('.ot_crud_cat_item_window .modal-body').html();
            content = content.replace(new RegExp("ot_cat_data", 'g'), "ot_cat_data1");
            content = content.replace(new RegExp("ot_cat_meta", 'g'), "ot_cat_meta1");
            content = content.replace(new RegExp("ot_cat_content", 'g'), "ot_cat_content1");
            content = content.replace(new RegExp("ot_cat_filters", 'g'), "ot_cat_filters1");
            content = content.replace(new RegExp("seoText", 'g'), "seoText1");            
            
            if (tinyMCE.editors.length > 0) {
                tinyMCE.remove(tinyMCE.editors[0]);
            }
            
            modalDialog(trans.get('Edit_category'), content, function(body) {
                var categoryName = $('#categoryName', body).val();
                var alias = $('#alias', body).val();
                var approxWeight = $('#approxweight', body).val();
                var meta_pagetitle = $('#meta_title', body).val();
                var meta_title = $('#meta_title_prefix', body).val() + '||' + $('#meta_title_suffix', body).val();
                var meta_keywords = $('#meta_keywords', body).val();
                var meta_description = $('#meta_description', body).val();
                var seoText = tinyMCE.editors[0].getContent();
                var externalId = $('#categoryId', body).val();
                var newParentId = $('#parentCategoryId', body).val();
                
                if ( !newParentId ) {
                	newParentId = parentId;
                }
                
                var aliasPattern = /^[a-z]+([-_]?[a-z0-9]+){0,2}$/i;                
                if (! aliasPattern.test(alias)) {
                	showError(trans.get('Category_alias_is_invalid'));
                    return false;
                }
                
                if (! categoryName.length) {
                    showError(trans.get('Enter_category_name_promt'));
                    return false;
                }
                
                if (categoryId.length) {
                    $.post(
                        "index.php?cmd=Categories&do=updateCategory",
                        {
							"id" : li.attr("id"), 
							"newName" : categoryName,
							"categoryId": categoryId,
							"parentId": newParentId,
							"externalId": externalId,
							"approxweight": approxWeight,
							"alias": alias,
							"meta_pagetitle": meta_pagetitle,
							"meta_title": meta_title,
							"meta_keywords": meta_keywords,
							"meta_description": meta_description,
							"seoText": seoText
                        },    
                        function (data) {
                            if (data.error) {
								showError(data.message ? data.message : trans.get('Notify_error'));
                            }
                            else {
								$(li).attr('alias', alias);
                                $(li).attr('approxweight', approxWeight);
                                $(li).attr('seo_pagetitle', meta_pagetitle);
                                $(li).attr('seo_title', meta_title);
                                $(li).attr('seo_keywords', meta_keywords);
                                $(li).attr('seo_description', meta_description);
                                $(li).attr('externalid', externalId);
                                $(li).attr('parentId', parentId);
                                       
                                $("#jstree").jstree("rename_node", li, categoryName);
                                if(newParentId != parentId){
                                    var parentLi = parent;
                                    if (parentId && parentId!=='0') {
                                    	parentLi = $('#jstree li[id="'+newParentId+'"]');
                                    	if (!parentLi) {
                                    		parentLi = 0;
                                    	}
                                    }
                                    $('#jstree').jstree('move_node',li, parentLi);
                                }
                            }
                        }, 'json'
                       );
                    return true;
                } else {
                    showError(trans.get('Enter_category_name_promt'));
                    return false;
                }
                return false;
                
            }, {confirm: trans.get('Save'), cancel: trans.get('Cancel') });
            
            $.ajax({
                async : true,
                type: 'POST',
                dataType: 'json',
                url: "index.php?cmd=Categories&do=getCategoryData",
                data : {
                    "categoryId" : categoryId,
                },
                success : function (data) {
                    if (data.error) {
                        showError(data.message ? data.message : trans.get('Notify_error'));
                    } else {
                        $('.confirmDialog .modal-body .editableform-loading').remove();
                        $('.confirmDialog .modal-body #seoText1').html(data.seoText);
                        if (tinyMCE.editors.length > 0) {
                            tinyMCE.editors[0].setContent(data.seoText);
                        }

                        $('.confirmDialog .modal-body #search_filters').html(data.filters);
                        $('.confirmDialog .modal-body #search_filters .ot_inline_editable').editable().on('shown', function() {
                            var a = $(this).closest('a');
                            var form = ('.editableform',a);
                            var submitFunction = function(event) {
                                form.submit();
                                event.stopPropagation();
                            };
                            $('.btn-primary',form).unbind('click').unbind('submit');
                            $('.btn-primary',form).click(submitFunction);
                        });
                    }
                }
            });            
        });
        $('.ot_cat_actions .delete_category_button', item).click(function() {
            var li = $(this).closest('li');
            modalDialog('',trans.get('Really_delete_this_category'),function() {
                $("#jstree").jstree("remove", li);
            });
        });
        $('.ot_cat_actions .move_category_button', item).mousedown(function(e) {
            var li = $(this).closest('li');
            var a = $('a',li);
            $("#jstree").jstree("start_drag", a, e);
            return false;
        });
        $('.ot_cat_actions .show_category_button', item).mousedown(function(e) {
            var li = $(this).closest('li');
            $(this).hide();            
            $('.ot_cat_actions .procces_category_button', item).show();
            $.post(
                "index.php?cmd=Categories&do=visibleCategory",
                {
                    "categoryId": li.attr('id'),
                    "visible" : 'true'
                },
                function (data) {
                      li.attr('ishidden', 'false');
                      li.attr('IsHiddenUI', 'false');
                       $('.ot_cat_actions .procces_category_button', item).hide();
                       $('.ot_cat_actions .hide_category_button', item).show();
                       $('a:first', item).css('color','');
                }, 'json'
            );
            
            return false;
        });
        $('.ot_cat_actions .hide_category_button', item).mousedown(function(e) {
            var li = $(this).closest('li');
            $(this).hide();            
            $('.ot_cat_actions .procces_category_button', item).show();
            $.post(
                "index.php?cmd=Categories&do=visibleCategory",
                {
                    "categoryId": li.attr('id'),
                    "visible" : 'false'
                },
                function (data) {
                    li.attr('IsHiddenUI', 'true');
                    li.attr('ishidden', 'true');
                    $('a:first', item).css('color', 'gray');
                    $('.ot_cat_actions .procces_category_button', item).hide();
                    $('.ot_cat_actions .show_category_button', item).show();
                }, 'json'
            );
            return false;
        });
        $('.ot_cat_actions .open_category_button', item).mousedown(function(e) {
            var li = $(this).closest('li');
            var id = $(li).attr('id');
            var url = '/index.php?p=subcategory&cid=' + id + '&virt';
            window.open('http://' + window.location.host + url);
            return false;
        });
        $('.ot_cat_actions .move_down_button', item).click(function() {
            var li = $(this).closest('li');
            var nextLi = $(li).next();
            var categoryId = li.attr('id');
            var ul = li.parent();
            var i = 1;
            $('li', ul).each(function() {
                var id = $(this).attr('id');
                if (id == categoryId) {
                    return false;
                }
                i++;
            });
            if (i == $('li', ul).length) {
                return;
            }
            $.post(
                "index.php?cmd=Categories&do=orderCategory",
                {
                    "categoryId": li.attr('id'),
                    "i" : i+1
                },
                function (data) {
                    nextLi.insertBefore(li);
                }, 'json'
            );
        });
        $('.ot_cat_actions .move_up_button', item).click(function() {
            var li = $(this).closest('li');
            var prevLi = $(li).prev();
            var categoryId = li.attr('id');
            var ul = li.parent();
            var i = 1;
            $('li', ul).each(function() {
                var id = $(this).attr('id');
                if (id == categoryId) {
                    return false;
                }
                i++;
            });
            if (i == 0) {
                return;
            }
            $.post(
                "index.php?cmd=Categories&do=orderCategory",
                {
                    "categoryId": li.attr('id'),
                    "i" : i - 1
                },
                function (data) {
                    prevLi.insertAfter(li);
                }, 'json'
            );
        });

        
        $('.ot_cat_actions .copy_button', item).click(function() {
            var li = $(this).closest('li');
            var categoryName = $('a:first', li).text();
            var externalId = $(li).attr('externalid');
            var categoryId = li.attr('id');
            $('.categories-wrapper #clipboard_category_external_id').val(externalId);
            $('.categories-wrapper #clipboard_category_id').val(categoryId);
            $('.categories-wrapper #clipboard_category_name').val(categoryName);
            $('.categories-wrapper #clipboard_op').val('copy');
        });

        $('.ot_cat_actions .cut_button', item).click(function() {
            var li = $(this).closest('li');
            var categoryName = $('a:first', li).text();
            var externalId = $(li).attr('externalid');
            var categoryId = li.attr('id');
            $('.categories-wrapper #clipboard_category_external_id').val(externalId);
            $('.categories-wrapper #clipboard_category_id').val(categoryId);
            $('.categories-wrapper #clipboard_category_name').val(categoryName);
            $('.categories-wrapper #clipboard_op').val('cut');
        });
        
        $('.ot_cat_actions .paste_button', item).click(function() {
            var li = $(this).closest('li');
            
            var srcExternalId = $('.categories-wrapper #clipboard_category_external_id').val();
            var srcCategoryId = $('.categories-wrapper #clipboard_category_id').val();
            var srcCategoryName = $('.categories-wrapper #clipboard_category_name').val();
            var op = $('.categories-wrapper #clipboard_op').val();
            
            if (undefined != op && 'cut' == op && undefined != srcCategoryId ) {
            	$('.ot_cat_actions .paste_button .icon-paste:first',item).hide();
            	$('.ot_cat_actions .paste_button .ot-preloader-micro:first',item).show();
            	var srcLi = $('#jstree li[id="' + srcCategoryId + '"]');
            	$('#jstree').jstree('move_node',srcLi, li);
                $('.ot_cat_actions .paste_button .icon-paste:first',item).show(); 
                $('.ot_cat_actions .paste_button .ot-preloader-micro:first',item).hide();

            } else if (undefined != op && 'copy' == op  && undefined != srcCategoryId ) {
            	// need copy
            	$('.ot_cat_actions .paste_button .icon-paste:first',item).hide();
            	$('.ot_cat_actions .paste_button .ot-preloader-micro:first',item).show();
                $.ajax({
                    async : true,
                    type: 'POST',
                    dataType: 'json',
                    url: "index.php?cmd=Categories&do=copyPaste",
                    data : {
                        "copiedId" : srcCategoryId,
                        "targetId" : $(li).attr('id'),
                        "copiedName" : srcCategoryName,
                        "copiedExternalId" : srcExternalId
                    },
                    success : function (data) {
                        if (data.error) {
                            showError(data.message ? data.message : trans.get('Notify_error'));
                        } else {
                        	//ok 
                        	$('#jstree').jstree('close_node',li);
                        	setTimeout(function(){
                        		$('#jstree').jstree('open_node',li);
                        	}, 500);
                        }
                        $('.ot_cat_actions .paste_button .icon-paste:first',item).show(); 
                        $('.ot_cat_actions .paste_button .ot-preloader-micro:first',item).hide();
                    }
                });
            	
            	
/*                $("#jstree").jstree("create", li, 'last', srcCategoryName, function(node) {
                    $(node).attr('externalid', srcExternalId);
                }, true);
                
                if (undefined != srcCategoryId && '' != srcCategoryId) {
                    var copiedLi = $('#'+srcCategoryId);
                    if (copiedLi.length>0) {
                        $("#jstree").jstree("remove", copiedLi);
                    }
                }*/
            }
            $('.categories-wrapper #clipboard_category_internal_id').val('');
            $('.categories-wrapper #clipboard_category_id').val('');
            $('.categories-wrapper #clipboard_category_name').val('');
        });
        
    },
    addJSTreeItemTaskBar: function(item) {
        var html = '<span class="ot_cat_actions">'+
        '<button class="btn btn-tiny offset-right1 move_category_button" title="' + trans.get("Move_category") + '"><i class="icon-move"></i></button>'+
        '<span class="btn-group">'+
        '    <button class="btn btn-tiny rename_category_button" title="' + trans.get("Edit_category") + '"><i class="icon-pencil"></i></button>' +
        '    <button class="btn btn-tiny ot_show_add_cat_item_window add_category_button" title="' + trans.get("Add_category") + '"><i class="icon-plus"></i></button>' ;
        if ( $(item).attr('IsHiddenUI')=='true') {
            $('a:first',item).css('color','gray');
            html += '    <button class="btn btn-tiny show_category_button" title="' + trans.get("Show_category") + '"><i class="icon-eye-open"></i></button>' +
            '    <button class="btn btn-tiny hide_category_button hide" title="' + trans.get("Hide_category") + '"><i class="icon-eye-close"></i></button>'; 
        }
        else {
            html += '    <button class="btn btn-tiny show_category_button hide" title="' + trans.get("Show_category") + '"><i class="icon-eye-open"></i></button>' +
            '    <button class="btn btn-tiny hide_category_button" title="' + trans.get("Hide_category") + '"><i class="icon-eye-close"></i></button>'; 
        }
        
        html += '    <button class="btn btn-tiny procces_category_button hide" title="' + trans.get("Show_category") + '"><i class="ot-preloader-micro"></i></button>' +
        '    <button class="btn btn-tiny open_category_button" title="' + trans.get("Open_category") + '"><i class="icon-search"></i></button>' +
        '    <button class="btn btn-tiny ot_show_deletion_dialog_modal delete_category_button" title="'+trans.get("Delete_category")+'"><i class="icon-remove"></i></button>' +
        '</span>' +
        '<span class="offset-left1"><span class="btn-group">' +
        '    <button class="btn btn-tiny move_up_button" title="' + trans.get("Move_up_category") + '"><i class="icon-level-up"></i></button>' +
        '    <button class="btn btn-tiny move_down_button" title="' + trans.get("Move_down_category") + '"><i class="icon-level-down"></i></button>' +
        '    <button class="btn btn-tiny copy_button" title="' + trans.get("Copy") + '"><i class="icon-copy"></i></button>' +
        '    <button class="btn btn-tiny cut_button" title="' + trans.get("Cut") + '"><i class="icon-cut"></i></button>' + 
        '     <button class="btn btn-tiny paste_button" title="' + trans.get("Paste") + '"><i class="icon-paste"></i><i class="ot-preloader-micro" style="display: none;"></i></button>' +
        '</span></span>'+
        '</span>';
        
        if ($('span.ot_cat_actions', item).length == 0) {
            var id = $(item).attr('id');
            if (id != 0) {
                $(item).append(html);
                
                this.assignItemHandlers(item);
                
                $('a',item).hover(function() {
                    $('.ot_cat_actions').hide();
                    $(this).parent('li').mouseenter();
                    return false;
                });
                
                $(item).hover(function() {
                    $('.ot_cat_actions').hide();
                    $('.ot_cat_actions:first', this).show();
                    return false;
                },function() {
                    $('.ot_cat_actions').hide();
                    return false;
                });
            }
            
        }
    }
});

$(function() {
    var U = new CategoriesPage();
});

function categories_filter_changed(scope, params)
{
    $('form#filter #' + scope.name + '_value').val(scope.value);
    $('form#filter').submit();
} 	

// Disable dialog key process
$(document).ready(function(){
    $(document).unbind('keyup');
});