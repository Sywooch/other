<?php

OTBase::import('system.lib.service.UserRecord');

class UsersProvider
{
    /**
     * @var OTAPIlib
     */
    private $otapilib;

    public function __construct($otapilib = null)
    {
        $this->otapilib = is_null($otapilib) ? new OTAPIlib() : $otapilib;
        $this->otapilib->setErrorsAsExceptionsOn();
    }

    public function FindBaseUserInfoListFrame($sessionId, $userFilter, $framePosition = 0, $frameSize = 18)
    {
        return $this->otapilib->FindBaseUserInfoListFrame($sessionId, $userFilter, $framePosition, $frameSize);
    }

    public function GetUserInfoForOperator($sessionId, $userId)
    {
        return $this->otapilib->GetUserInfoForOperator($sessionId, $userId);
    }

    public function GetAccountInfoForOperator($sessionId, $userId)
    {
        return $this->otapilib->GetAccountInfoForOperator($sessionId, $userId);
    }

    public function GetStatementForOperator($sessionId, $customerId, $fromDate = '', $toDate = '')
    {
        return $this->otapilib->GetStatementForOperator($sessionId, $customerId, $fromDate, $toDate);
    }

    public function SearchOrders($sessionId, $userId, $framePosition = 0, $frameSize = 18)
    {
        $xml = '<OrderSearchParameters><UserIdDelimitedList>' . (int)$userId . '</UserIdDelimitedList></OrderSearchParameters>';

        return $this->otapilib->SearchOrders($sessionId, $xml, $framePosition, $frameSize);
    }

    public function EditUser($sessionId, $userParameters)
    {
        return $this->otapilib->EditUser($sessionId, $userParameters);
    }
	
	public function CreateUserProfileForOperator($sessionId, $userId, $userParameters)
    {
        return $this->otapilib->CreateUserProfileForOperator($sessionId, $userId, $userParameters);
    }

    public function AddUser($sessionId, $userParameters)
    {
        return $this->otapilib->AddUser($sessionId, $userParameters);
    }

    public function SetUserBan($sessionId, $userId, $isBanned)
    {
        return $this->otapilib->SetUserBan($sessionId, $userId, $isBanned);
    }

    public function DeleteUser($sessionId, $userId)
    {
        return $this->otapilib->DeleteUser($sessionId, $userId);
    }

    public function AuthenticateAsUser($sessionId, $userLogin)
    {
        return $this->otapilib->AuthenticateAsUser($sessionId, $userLogin);
    }

    public function getError()
    {
        return $this->otapilib->error_message;
    }

    public function getUsersIdsByPhone($phone, $from, $perpage)
    {
        $xmlParams = new SimpleXMLElement('<UserFilterParameters></UserFilterParameters>');
        $xmlParams->addChild('Phone', htmlspecialchars($phone));
        $filters = str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());

        $users = $this->otapilib->FindBaseUserInfoListFrame(Session::get('sid'), $filters, $from, $perpage);

        $uids = array();
        if (is_array($users) && !empty($users['content'])) {
            foreach ($users['content'] as $user) {
                $uids[] = (string)$user['id'];
            }
        }
        return $uids;
    }

    public function getUsersByIds($userIds)
    {
        $userIds = is_array($userIds) ? $userIds : array($userIds);
        $xmlParams = new SimpleXMLElement('<UserFilterParameters></UserFilterParameters>');
        $xmlParams->addChild('IdList', implode(';', $userIds));
        $filters = str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());

        $raw = $this->otapilib->FindBaseUserInfoListFrame(Session::get('sid'), $filters, 0, count($userIds) + 1);

        $users = array();
        if (is_array($raw) && !empty($raw['content'])) {
            foreach ($raw['content'] as $user) {
                $users[$user['id']] = new UserRecord($user);
            }
        }
        return $users;
    }

    public function getUsersByFilters($filter, $from, $perpage)
    {
        $xmlParams = new SimpleXMLElement('<UserFilterParameters></UserFilterParameters>');
        if (! empty($filter['phone'])) {
            $xmlParams->addChild('Phone', htmlspecialchars($filter['phone']));
        }
        if (! empty($filter['email'])) {
            $xmlParams->addChild('Email', htmlspecialchars($filter['email']));
        }
        $filter = str_replace('<?xml version="1.0"?>', '', $xmlParams->asXML());
        $users = $this->FindBaseUserInfoListFrame(Session::get('sid'), $filter, $from, $perpage);

        $uids = array();
        if (is_array($users) && !empty($users['content'])) {
            foreach ($users['content'] as $user) {
                $uids[] = (string)$user['id'];
            }
        }
        return $uids;
    }
}