<?=TabsGenerator::GetTabs('templates/promo/navigation/tabs.xml', $PageUrl)?>
