<!-- confirm deleting modal window -->
<div class="modal hide fade ot_deletion_dialog_modal">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <div class="modal-body">
        <p>Вы уверены что хотите удалить <strong id="item_for_delete"></strong>?</p>
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0)" class="btn btn-primary pull-left" id="confirm">Удалить</a>
        <a href="javascript:void(0)" class="btn pull-right" data-dismiss="modal"><?=LangAdmin::get('Cancel')?></a>
    </div>
</div>


<div class="modal hide fade confirmDialog">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h3></h3>
    </div>
    <div class="modal-body"></div>
    <div class="modal-footer">
        <a href="javascript:void(0)" class="btn btn-primary pull-left"
            id="confirm"><?=LangAdmin::get('Yes')?></a>
        <a href="javascript:void(0)" class="btn pull-right" data-dismiss="modal"
            id="cancelBtn"><?=LangAdmin::get('Cancel')?></a>
    </div>
</div>


<div class="modal hide fade choose_region">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <div class="modal-body">
        <ul id="regions"></ul>
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0)" class="btn pull-right" data-dismiss="modal"><?=LangAdmin::get('Cancel')?></a>
    </div>
</div>

<div class="modal hide fade splitItemQuantity">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <div class="modal-body">
        <?=LangAdmin::get('Split_item_suggestion')?><br/>
        <input type="text" name="split" value="1" />
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0)" class="btn btn-primary pull-left" id="confirm"><?=LangAdmin::get('Split')?></a>
        <a href="javascript:void(0)" class="btn pull-right" data-dismiss="modal"><?=LangAdmin::get('Cancel')?></a>
    </div>
</div>


<!-- feedback-support form modal window -->
<div class="modal hide fade ot_modal_dialog_window">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h3>Форма для обращения в службу поддержки</h3>
    </div>
    <div class="modal-body">
        <p>Здесь добавить форму обратной связи</p>
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0)" class="btn btn-primary pull-left">Отправить</a>
        <a href="javascript:void(0)" class="btn pull-right" data-dismiss="modal">Закрыть</a>
    </div>
</div>

        <div id="infoMessageModal" class="modal hide fade">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3><?=LangAdmin::get('InfoMessage')?></h3>
            </div>
            <div class="modal-body">
                <p id="infoMessageBody"></p>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" class="btn" data-dismiss="modal" aria-hidden="true"><?=LangAdmin::get('Close')?></a>
            </div>
        </div>

        <div id="errorMessageModal" class="modal hide fade">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3><?=LangAdmin::get('Error')?></h3>
            </div>
            <div class="modal-body">
                <p id="errorMessageBody"></p>
            </div>
            <div class="modal-footer">
                <a href="#" class="btn" data-dismiss="modal" aria-hidden="true"><?=LangAdmin::get('Close')?></a>
            </div>
        </div>