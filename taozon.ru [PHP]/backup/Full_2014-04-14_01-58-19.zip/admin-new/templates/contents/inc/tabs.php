<?=TabsGenerator::GetTabs('templates/contents/navigation/tabs.xml', $PageUrl)?>
