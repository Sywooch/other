<!-- site language -->
<div class="btn-group pull-right">
    <a class="btn dropdown-toggle offset-top05" data-toggle="dropdown" href="#" title="<?=LangAdmin::get('Language_select_for_edit')?>">

        <? $activeLang = false; ?>
        <? if($AvailableLanguages) foreach($AvailableLanguages as $lang){ ?>
            <? if((string)$lang['Name'] == Session::get('active_lang_siteconfiguration')){ ?>
                <? $activeLang = (string)$lang['Name']; ?>
                <?=(string)$lang['Description']?>
            <? } ?>
        <? } ?>
        <? if(!$activeLang){ ?>
            <?=LangAdmin::get('All_languages_versions')?>
        <? } ?>

        <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
        <li>
            <a data-value="" href="<?=$PageUrl->SetPageLangUrl('')?>">
                <?=LangAdmin::get('All_languages_versions')?>
            </a>
        </li>
        <? if($AvailableLanguages) foreach($AvailableLanguages as $lang){ ?>
            <li>
                <a data-value="<?=(string)$lang['Name']?>" href="<?=$PageUrl->SetPageLangUrl((string)$lang['Name'])?>">
                    <?=(string)$lang['Description']?>
                </a>
            </li>
        <? } ?>
    </ul>
</div>

<script>
    $(function(){
        //showError('Test Error', 'TestError');
    });
</script>
<!-- /site language -->
