
<div class="row-fluid offset-top3">

    <div class="box box-closed corner-all">

        <div class="box-header corner-top">
            <div class="header-control">
                <a data-box="collapse"><i class="icon-caret-down"></i></a>
            </div>
            <span><?=LangAdmin::get('System_events_log')?></span>
        </div>

        <div class="box-body" style="padding: 0">
            <pre style="margin: 0; color: #d14;"><?=$debugLog?></pre>
        </div><!-- /.box-body -->
    </div><!-- /.box -->

</div><!--/.row-fluid -->
