<?php
/**
 * User: dima
 * Date: 08.12.12
 * Time: 9:42
 * Новый блок подборок товаров, продавцов, брендов и категорий
 */
class Set2 extends GeneralUtil{

    protected $_cache = false; //- кэшируем или нет.
    protected $_life_time = 3600; //- время на которое будем кешировать
    protected $_template = 'index'; //- шаблон, на основе которого будем собирать блок
    protected $_template_path = 'set2/'; //- путь к шаблону
    protected $tpl;

    public function __construct(){
        global $otapilib;
        $otapilib->setErrorsAsExceptionsOn();

        parent::__construct();
        @define('NO_DEBUG', 1);
    }

    /**
     * Вывод главной страницы подборок
     * Сейчас на ней вывод избранных товаров
     * @param RequestWrapper|bool $request
     */
    public function defaultAction($request = false){
		$this->checkAuth();
        print $this->fetchTemplate();
    }

    /**
     * Вывод подборок товаров
     * @param RequestWrapper|bool $request
     */
    public function showItemSetAction($request){
		$this->checkAuth();
        $this->_template = $request->getValue('contentType');
        $itemSet = $this->getItemsSet($request->getValue('type'), $request->getValue('contentType'),
            $request->getValue('categoryId'));

        $method = 'prepare' . $request->getValue('contentType') . 'Items';
        if (method_exists($this, $method)) {
            $itemSet = $this->$method($itemSet);
        }

        $this->tpl->assign('items', $itemSet);
        $this->tpl->assign('itemRatingTypeId', $request->getValue('type'));


        //Получение катеогрий - можно отказаться так как все катеогрии и так в БД, но если нам надо знать сколько элементов в категории то получаем
        $categories = $this->getSetCategories('Item', $request->getValue('type'));
        $this->tpl->assign('categories', $categories);

        $hierarchy = Plugins::invokeEvent('onGetHierarchyCats', array('tpe' => $request->getValue('type'),'cats' => $categories));
        $this->tpl->assign('hierarchy', $hierarchy);

        //Получаем SEO категории
        $Cats_Seo = Plugins::invokeEvent('HierarchyGetSeoTexts', array('CType' => "Item",'RatingTypeId' => "Best", 'catId' => $request->getValue('categoryId')));
        $this->tpl->assign('Cats_Seo', $Cats_Seo);


        $this->tpl->assign('activeCategory', $request->getValue('categoryId'));
        print $this->fetchTemplate();
    }





    /**
     * Удаление элемента из подборки
     * @param RequestWrapper|bool $request
     */
    public function deleteFromRatingListAction($request){
		$this->checkAuth();
        $AntiSpecSymbName = str_replace("-and-", "&", $request->getValue('categoryId'));
        Plugins::invokeEvent('onDelHierarchyCat', array('fields' => $request));


        $this->deleteFromItemSet(
            $request->getValue('itemRatingTypeId'),
            $request->getValue('contentType'),
            $AntiSpecSymbName,
            $request->getValue('itemList')
        );

        $C = new Control();
        $C->clearCacheAction();
    }

    /**
     * Добавление элемента в подборку
     * @param RequestWrapper|bool $request
     */
    public function addToRatingListAction($request)
    {
		$this->checkAuth();
        $itemList = $request->getValue('ItemList');
        $VendorName = $request->getValue('VendorName');
        $itemListArray = explode(';', $itemList);
        $method = "prepare".$request->getValue('contentType')."Ids";
        $this->$method($itemListArray);
        $itemListArray = array_filter($itemListArray);

        Plugins::invokeEvent('onAddHierarchyCat', array('fields' => $request));

        $this->addToItemSet(
            'Best',
            $request->getValue('contentType'),
			$request->getValue('categoryId') == '' ? $request->getValue('currentCategory') : $request->getValue('categoryId'),            
            implode(';', $itemListArray),
            $VendorName
        );

        $method = "afterAdd".$request->getValue('contentType');
        if (method_exists($this, $method)) {
            $this->$method($request, $itemListArray);
        }

        $C = new Control();
        $C->clearCacheAction();
    }

    /**
     * @param RequestWrapper|bool $request
     * @return bool
     */
    public function getItemInfoAction($request){
		$this->checkAuth();
        global $otapilib;
        try{
            $item = array();

            $itemInfo = $otapilib->GetItemFullInfo($request->get('id'));
            $item['Title'] = $itemInfo['Title'];

            $itemDescription = $otapilib->GetItemDescription($request->get('id'));
            $item['Description'] = (string)$itemDescription;

            print json_encode( $item );
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }

        return false;
    }

    /**
     * @param RequestWrapper|bool $request
     * @throws DBException
     * @return bool
     */
    public function getVendorInfoAction($request){
		$this->checkAuth();
        try{
            $item = array();

            $this->cms->Check();
            $q = $this->cms->query('SELECT * FROM `site_vendors_images`
                WHERE `vendor_id`="'.mysql_real_escape_string($request->get('id')).'"');

            $row = mysql_fetch_assoc($q);
            $item['Id'] = $row['vendor_id'];
            $item['VendorName'] = $row['vendor_name'];
			$item['PictureUrl'] = empty($row['image_path']) ? '/i/logo.png' : $row['image_path'];

            print json_encode( $item );
        }
        catch(DBException $e){
            $this->throwAjaxError($e);
        }

        return false;
    }

    /**
     * @param RequestWrapper|bool $request
     */
    public function saveItemInfoAction($request){
		$this->checkAuth();
        global $otapilib;

        try{
            $sid = Session::get('sid');

            $key = "taobao:Item:Title";
            $otapilib->EditTranslateByKey($sid, $request->post('ItemTitle'), $key, $request->post('ItemId'), 'ru');

            $key = "taobao:Item:Description";
            $otapilib->EditTranslateByKey($sid, $request->post('ItemDescription'), $key, $request->post('ItemId'), 'ru');

            $C = new Control();
            $C->clearCacheAction();
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }
    }

    /**
     * Получает подборку товаров
     * @param string $type Best|Popular|Last
     * @param $contentType
     * @param int $category
     * @return array
     */
    public function getItemsSet($type, $contentType, $category = 0){
        global $otapilib;
        try{
            $method = "Get{$contentType}RatingList";
            return $otapilib->$method($type, 2000, $category);
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }

        return false;
    }

    /**
     * Получение списка категорий для требуемой подборки
     * @param string $contentType       Item|Brand|Vendor|Category
     * @param string $itemRatingTypeId  Best|Popular|Last
     * @return array
     */
    public function getSetCategories($contentType, $itemRatingTypeId){
        global $otapilib;
        try{
            $resultCategories = array();
            $sets = $otapilib->GetRatingCollectionsByContent($contentType);
            foreach($sets as $itemSet){
                if($itemSet['ItemRatingTypeName'] == $itemRatingTypeId && $itemSet['ContentTypeName'] == $contentType) {
                    $CatName = $itemSet['CategoryId'];
                    $resultCategories[$CatName] = $itemSet['Count'];
                }
            }

            return $resultCategories;
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }
        return array();
    }

    /**
     * Удаляет элементы из подборки и в случае с продавцами удаляет записи из локальной базы
     * @param string $itemRatingTypeId  Best|Popular|Last
     * @param string $contentType       Item|Vendor|Category|Brand
     * @param string $categoryId
     * @param string $itemList          Список id товаров, разделенных ;
     */
    public function deleteFromItemSet($itemRatingTypeId, $contentType, $categoryId, $itemList){
        global $otapilib;

            try{
                $sid = Session::get('sid');
                $otapilib->RemoveElementsSetRatingList($sid, $itemRatingTypeId, $contentType, $categoryId, $itemList);
                if($contentType == 'Item' && $itemRatingTypeId != 'Best'){
                    $otapilib->AddBlackListContents($sid, $this->addItemToBlackListXML($itemList));
                }
            }
            catch(ServiceException $e){
                $this->throwAjaxError($e);
            }

        $vendorId = $this->cms->escape($itemList);
        $repository = new VendorRepository($this->cms);
        $repository->deleteVendorImage($vendorId);


    }

    public function addToItemSet($itemRatingTypeId, $contentType, $categoryId, $itemList){
        global $otapilib;
        try{
            $sid = Session::get('sid');
            $otapilib->AddElementsSetToRatingList($sid, $itemRatingTypeId, $contentType, $categoryId, $itemList);
            if(!$this->checkAddToRatingListSuccess($itemRatingTypeId, $contentType, $categoryId, $itemList))
                throw new ServiceException('', '', 'Item was not added', 'InternalError');
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }
    }

    /**
     * Формирует xml для добаления удаленных товаров их подборок Popular, Last в черный список
     * @param $itemList     Список id товаров, разделенных ;
     * @return string       XML
     */
    private function addItemToBlackListXML($itemList){
        $xml = new SimpleXMLElement('<ArrayOfContentList></ArrayOfContentList>');
        $contentList = $xml->addChild('ContentList');
        $contentList->addAttribute('ContentType', 'Item');

        $itemList = explode(';', $itemList);
        foreach($itemList as $itemId){
            $contentList->addChild('Content', htmlspecialchars($itemId));
        }

        return $xml->asXML();
    }

    /**
     * Переводит ссылки на товары в id
     * @param array $itemListArray
     */
    private function prepareItemIds(&$itemListArray){
        foreach($itemListArray as &$data){
            if(preg_match( '/(http)/i', $data )) {
                $urlComponents = parse_url($data);
                parse_str($urlComponents['query'], $queryArray);
                $data = isset($queryArray['id']) && preg_match('/^\d+$/', $queryArray['id']) ? $queryArray['id']:false;
            }
            else{
                $data = (string)$data;
            }
        }
    }

    /**
     * Переводит ссылки на продавцов в id
     * @param array $itemListArray
     */
    private function prepareVendorIds(&$itemListArray)
    {
        foreach ($itemListArray as &$data) {
            if (strpos(trim($data), 'http://') === 0) {
                $urlComponents = parse_url(trim($data));
                parse_str($urlComponents['query'], $queryArray);
                $data = isset($queryArray['id']) ? $queryArray['id'] : false;
            } else {
                $data = $data;
            }
        }
    }

    /**
     * Подготавливает данные для вывода продавцов и копирует данные из удаленной базы в локальную
     * @param array $vendors
     */
    private function prepareVendorItems($vendors)
    {
        $repository = new VendorRepository($this->cms);
        $vendorIds = $repository->getVendorId ();
        foreach ($vendors as &$vendor) {

            $dbInfo = $repository->GetVendorInfo($vendor['id']);

            if (!empty($dbInfo) && isset($vendor['id']) && in_array($vendor['id'], $vendorIds, true)){
            $dbInfo = reset($dbInfo);
            }
            elseif ((empty($dbInfo) && isset($vendor['id'])) || (!empty($dbInfo) && isset($vendor['id']) && !in_array($vendor['id'], $vendorIds, true))){
            $dbAddInfo = $repository->addVendorImage($vendor['id'], $vendor['PictureUrl'], $vendor['id']);
            $dbInfo = $repository->GetVendorInfo($vendor['id']);
            $dbInfo = reset($dbInfo);
            }
            else {
            $dbInfo = array();
            }

            $vendor['PictureUrl'] = !empty($dbInfo['image_path']) ? $dbInfo['image_path'] : $vendor['PictureUrl'];
            $vendor['pictureurl'] = $vendor['PictureUrl'];
            $vendor['VendorName'] = !empty($dbInfo['vendor_name']) ? $dbInfo['vendor_name'] : $vendor['Name'];
        }
        return $vendors;
    }

    /**
     * Добавляет запись о продавце в локальную базу
     * @param RequestWrapper $request
     */
    private function afterAddVendor($request, array $vendorIds)
    {
        if ( ( $request->getValue('PictureUrl') || $request->getValue('VendorName') ) && !empty($vendorIds)) {
            $repository = new VendorRepository($this->cms);
            $repository->addVendorImage(reset($vendorIds), $request->getValue('PictureUrl'),$request->getValue('VendorName'));
        }
    }

    /**
     * Редактирует записи о продавцах в локальной базе
     * @param RequestWrapper|bool $request
     */
    public function saveVendorInfoAction($request){
        global $otapilib;

        $VendorName = $request->post('VendorName');
        $PictureUrl = $request->post('PictureUrl');

        $repository = new VendorRepository($this->cms);
        $repository->editVendorImage($request->post('Id'), $request->post('VendorName'), $request->post('PictureUrl'));

    }

    /**
     * Переводит ссылки на бренды в id
     * @param array $itemListArray
     */
    private function prepareBrandIds(&$itemListArray){
        foreach($itemListArray as &$data){
            if(preg_match( '/(http)/i', $data )) {
                $urlComponents = parse_url($data);
                parse_str($urlComponents['query'], $queryArray);
                $data = isset($queryArray['brand']) ? $queryArray['brand']:false;
            }
            else{
                $data = $data;
            }
        }
    }

    /**
     * Проверяет наличие всех добавляемых элементов из $itemList в подборку
     * @param $itemRatingTypeId
     * @param $contentType
     * @param $categoryId
     * @param $itemList
     * @return bool успех
     */
    private function checkAddToRatingListSuccess($itemRatingTypeId, $contentType, $categoryId, $itemList){
        global $otapilib;
        $method = "Get{$contentType}RatingList";
        $elements = $otapilib->$method($itemRatingTypeId, 2000, $categoryId);
        $itemListIds = explode(';', $itemList);
        foreach($elements as $e){
            $key = array_search((string)$e['Id'], $itemListIds);
            if($key !== false) unset($itemListIds[$key]);
        }

        return !count($itemListIds);
    }

    public function EditCatAction(){
		$this->checkAuth();
        //Пишем это деол в отапи
        global $otapilib;
        try{
            $sid = Session::get('sid');
            $otapilib->UpdateItemRatingCategoryId($sid, $_POST['RatingTypeId'], $_POST['contentType'], $_POST['catId'], $_POST['name']);
            Plugins::invokeEvent('HierarchySetSeoTexts', array('input' => $_POST));
        }
        catch(ServiceException $e){
            $this->throwAjaxError($e);
        }
        header('Location: index.php?cmd=Set2');
    }


    public function addFileToRatingListAction(){
		$this->checkAuth();
        //А Если грузить через файл
        if (is_uploaded_file($_FILES['filedata']['tmp_name'])) {
            
            $file_type = pathinfo($_FILES['filedata']['name'], PATHINFO_EXTENSION);
            if (strtolower($file_type) != 'txt') {
                Session::setError(LangAdmin::get('failed_load_file_only_txt'));
                header('Location: index.php?cmd=Set2');
                die;
            }

            $fp = fopen($_FILES['filedata']['tmp_name'], 'r');
            $itemList = fread($fp,filesize($_FILES['filedata']['tmp_name']));
            fclose($fp);
            $itemList = str_replace("\r\n",';',$itemList);
            $itemList = str_replace("\n",';',$itemList);

            $itemListArray = explode(';', $itemList);


            $method = "prepare".$_POST['contentType']."Ids";
            $this->$method($itemListArray);
            $itemListArray = array_filter($itemListArray);
            //print_r($itemListArray);

            $this->addToItemSet(
                'Best',
                $_POST['contentType'],
                $_POST['currentCategory'],
                implode(';', $itemListArray)
            );


            $C = new Control();
            $C->clearCacheAction();
            header('Location: index.php?cmd=Set2');

        }

    }


}