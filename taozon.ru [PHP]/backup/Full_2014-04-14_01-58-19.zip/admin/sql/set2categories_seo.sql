CREATE TABLE IF NOT EXISTS `set2categories_seo` (
  `id` text NOT NULL,
  `title` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `txt` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;