CREATE TABLE IF NOT EXISTS `shop_reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `text` text,
  `answer` text NOT NULL,
  `accepted` tinyint(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rating` int(11),
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;