CREATE TABLE IF NOT EXISTS `site_payed_orders` (
  `id` text NOT NULL,
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;