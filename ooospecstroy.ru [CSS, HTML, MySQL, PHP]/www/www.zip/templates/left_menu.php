<div align="left" class="block23">
<div class="block24">






<ul style="margin-left:0; padding-left:0; margin:0; padding:0">
<li style="list-style-type: none; padding:1px;height:23px; margin:0; border-bottom:0px #396c7b solid;   float:left">
<div style="height:20px">
<img src="images/marker.png" alt="стоительные работы"  style="margin-right:0px;margin-top:0px"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="furniture.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Мебель</strong></a></h1>
</div>

<div style="height:3px">
<img src="images/line_menu2.png" alt="кирпичная кладка"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div>
</li>




<li style="list-style-type: none; padding:1px;height:23px; margin:0; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="бетонные работы"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="design.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Дизайн</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="облицовочные работы"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div>
</li>



<li style="list-style-type: none; padding:1px;height:23px; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="штукатурные работы"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="certificates.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Сертификаты</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="малярные работы"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>



<li style="list-style-type: none; padding:1px;height:23px; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="гипсокартон"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="restoration.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Реставрация памятников</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="штукатурка стен"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>

<li style="list-style-type: none; padding:1px;height:23px; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="обойные работы"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="building.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Реконструкция/Строительство</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="компания спецстрой благовещенск"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>


<li style="list-style-type: none; padding:1px;height:23px; border-bottom:0px #396c7b solid;float:left">
<div style="height:20px">
<img src="images/marker.png" alt="ремонтно-отделочные работы"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="repair.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Ремонт/Отделка</strong></a></h1>
</div style="height:3px">
<div>
<img src="images/line_menu2.png" alt="новые технологии"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>


<li style="list-style-type: none; padding:1px; height:23px;border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="ремонт помещений"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="price_list.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Прайс-лист</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="ремонт любой сложности"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>

<li style="list-style-type: none; padding:1px;height:23px; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="текстурное покрытие"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="department.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Ведение бухучёта</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="отделка поверхностей"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>


<li style="list-style-type: none; padding:1px; height:23px; border-bottom:0px #396c7b solid;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt=""  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="purchase.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Закупка товаров КНР/Москва</strong></a></h1>
</div>
<div style="height:3px">
<img src="images/line_menu2.png" alt="терракоат замша"  style="margin-right:0px;border:0; padding:0" class="style456"/>
</div></li>


<li style="list-style-type: none; padding:1px; height:20px;  float:left">
<div style="height:20px">
<img src="images/marker.png" alt="террако"  style="margin-right:0px;margin-top:0px;"/>
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal; margin:0; display:inline">
<a href="mirrors.php" class="myriad_pro12 menu_left_a2" style="color:#735f50"><strong>Стёкла/Зеркала</strong></a></h1>
</div>


</ul>






<!--
<table style="border:0; padding:0; margin:0" cellpadding="0" cellspacing="0" >
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="furniture.php" class="myriad_pro12 menu_left_a2">Мебель</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="design.php" class="myriad_pro12 menu_left_a2">Дизайн</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="certificates.php" class="myriad_pro12 menu_left_a2">Сертификаты</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="restoration.php" class="myriad_pro12 menu_left_a2">Реставрация памятников</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="building.php" class="myriad_pro12 menu_left_a2">Реконструкция/Строительство</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="repair.php" class="myriad_pro12 menu_left_a2">Ремонт/Отделка</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="price_list.php" class="myriad_pro12 menu_left_a2">Прайс-лист</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="department.php" class="myriad_pro12 menu_left_a2">Ведение бухучёта</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="purchase.php" class="myriad_pro12 menu_left_a2">Закупка товаров КНР/Москва</a>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/line_menu2.png" alt="" style="margin-top:0px;border:0"/>
</td>
</tr>
<tr>
<td style="border:0; padding:0; margin:0">
<img src="images/marker.png" alt=""  style="margin-right:10px;float:left;margin-top:0px;"/>
<a href="mirrors.php" class="myriad_pro12 menu_left_a2">Стёкла/Зеркала</a>
</td>
</tr>


</table>
-->






</div>
</div>
