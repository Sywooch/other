<div class="new_license_information_1" ><!--лицензия-->
<div class="new_license_information_2"><span class="arial8 menu_left_a1">Свидетельство СРО "ОС Приамурья" №: 0031.05-2010-2801084077-C-116</span></div>
<div class="new_license_information_3"><span class="arial8 menu_left_a1">Лицензия МКРФ №:  00321</span></div>
<div class="new_license_information_3">
<span class="arial8 menu_left_a1">Свидетельство по мебели №: 235 Б</span></div>


</div><!--лицензия-->
