
<div align="left" class="new_news_1"  style="color:#735f50 !important"><!--новости-->
<div class="new_news_2">

<div align="center" style="height:25px; width:234px; text-align:center; float:left">
<span class="myriad_pro12">Новости</span>
</div>
<!--<hr size="1">-->

<div style="height:180px; width:234px; float:left">
<div style="width:234px;  float:left; margin-top:0px; padding-top:10px; padding-bottom:10px">


<span class="myriad_pro10">
<!--[if IE]><span class="myriad_pro9"><![endif]-->
Закончились работы по реставрации
торгового дома "Братья Малаховы"(ул.Пионерская, 32-"Бенетон") </span>

</div>
<!--<hr size="1">-->
<div style=" width:234px; float:left; margin-top:0px; border-top:1px #dbd3be solid; 
padding-top:10px; padding-bottom:10px; border-bottom:1px #dbd3be solid">

<span class="myriad_pro10">
<!--[if IE]><span class="myriad_pro9"><![endif]-->
Компания приняла участие в 
реставрации бывшей почтово-телеграфной конторы (ул.Ленина, 142-"Россельхозбанк")</span>
</div>

</div>
<!--<hr size="1">-->
<div align="right"  style="height:20px; width:234px;padding:0; margin-top:3px; float:left">
<span align="right" class="myriad_pro12_italic"><a href="news.php" alt="" style="text-decoration:none; color:#735f50" 
class="myriad_pro12_italic">все новости...</a></span>
</div>

</div>



</div><!--новости-->
