<a href="index.php" alt=""/><div align="center" class="new_logo_2" style="cursor:pounter; border:0"><!--логотип-->
<img src="images/logo.png" alt="акриловое текстурное покрытие" style="cursor:pounter; border:0"/>
</div><!--логотип-->
</a>
