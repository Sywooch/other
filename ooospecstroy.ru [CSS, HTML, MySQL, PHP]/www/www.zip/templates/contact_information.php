
<script type="text/javascript">

  function DisBlock(){
   $('div#rightcol').fadeIn(1500);
   					}
  function close_block(){
   $('div#rightcol').fadeOut(1500);
  	}


</script>


<div class="new_contact_information_1 arial8"  ><!--адрес-->
<div class="new_contact_information_2" style="margin-left:130px">
<div class="new_contact_information_3"><span class="arial8 menu_left_a1"><strong>Телефон:</strong> +7 (4162) 53-72-72, +79145570072</span></div>
<div class="new_contact_information_4"><span class="arial8 menu_left_a1"><strong>Факс:</strong> +7 (4162) 53-72-72</span></div>
<div class="new_contact_information_5"><span class="arial8 menu_left_a1"><strong>Адрес:</strong> Благовещенск,</br> ул.Артиллерийская 31</span></div>
</div> 

<div class="new_map"><!--карта-->
<a href="map.php" alt=""><img src="images/map.png" alt="интерьер" style="margin-top:50px;cursor:pointer; border:0" onclick="DisBlock()" 
title="Кликните, чтобы посмотреть карту"/></a>
</div><!--карта-->

</div><!--адрес-->

