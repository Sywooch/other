<script type="text/javascript">
function h(f){
f.inputtext_id.value="";


}
</script>



<div align="left" class="new_menu_1"><!--меню-->
<div align="center" class="new_menu_2">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="index.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Главная</a></h1></div>

<div align="center" class="new_menu_3">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="news.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Новости</a></h1></div>

<div align="center" class="new_menu_4">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="about.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">О компании</a></h1></div>

<div align="center" class="new_menu_5">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="partners.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Партнёры</a></h1></div>

<div align="center" class="new_menu_6">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="documentation.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Документация</a></h1></div>

<div align="center" class="new_menu_7">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="responses.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Отзывы</a></h1></div>

<div align="center" class="new_menu_8">
<h1 style="margin-top:0px; margin-bottom:0px;font-weight: normal;">
<a href="contacts.php" class="myriad_pro12 menu_left_a1" style="font-weight: normal; ">Контакты</a></h1></div>




<div style="width:203px;height:36px; margin-left:0px; float:left">
<div style="width:200px; height:26px; margin-top:10px; float:right; background-image:url('images/search.png'); 
background-repeat:no-repeat">
<form id="searchForm" action="search.php" enctype="multipart/form-data" method="post" accept-charset="utf-8" style="padding:0; border:0">
	<!--поле для ввода фразы-->
	<input type="text" maxlength="100" name="inputtext_id" id="inputtext_id"  
	style="float:left; margin-top:3px; margin-left:13px; width:130px; border:0; color:white; background-color:#48240d" placeholder="поиск..." value="поиск..."
	onclick="h(this.form);"/>
<!--поле для ввода фразы-->

        <input type="submit" value="" style="margin-left:24px;margin-top:4px; cursor: pointer" >

  </form> 
</div>

</div>
</div><!--меню-->


