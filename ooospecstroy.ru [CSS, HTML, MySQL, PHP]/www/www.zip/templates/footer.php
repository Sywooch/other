<div align="center" class="new_footer_1">

<div class="new_footer_2">
<div class="new_footer_3">

</div>
<div class="new_footer_4">
<div align="left" class="new_footer_5">
<span class="block33 arial9">© 2013 "Спецстрой"
</br>Амурская область, г. Благовещенск</span>
</div>


<div align="left" class="new_footer_6">
<div class="block32"><a href="http://www.retina-studio.ru" alt=""/><img src="images/logo_mini_footer.png" alt="дизайн корпусной мебели" style="border:0"/></a></div>
<!--<div class="block33 myriad_pro10">designed by retina</div>-->
</div>


</div>

</div>

</div>

