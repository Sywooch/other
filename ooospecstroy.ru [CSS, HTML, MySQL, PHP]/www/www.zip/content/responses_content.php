
<script type="text/javascript">

  function DisBlock(){
   $('div#rightcol').fadeIn(1500);
   					}
  function close_block(){
   $('div#rightcol').fadeOut(1500);
  	}

  function DisBlock2(){
   $('div#rightcol2').fadeIn(1500);
   					}
  function close_block2(){
   $('div#rightcol2').fadeOut(1500);
  	}

  function DisBlock3(){
   $('div#rightcol3').fadeIn(1500);
   					}
  function close_block3(){
   $('div#rightcol3').fadeOut(1500);
  	}

  function DisBlock4(){
   $('div#rightcol4').fadeIn(1500);
   					}
  function close_block4(){
   $('div#rightcol4').fadeOut(1500);
  	}

  function DisBlock5(){
   $('div#rightcol5').fadeIn(1500);
   					}
  function close_block5(){
   $('div#rightcol5').fadeOut(1500);
  	}	
	
	function DisBlock6(){
   $('div#rightcol6').fadeIn(1500);
   					}
  function close_block6(){
   $('div#rightcol6').fadeOut(1500);
  	}
	
	function DisBlock7(){
   $('div#rightcol7').fadeIn(1500);
   					}
  function close_block7(){
   $('div#rightcol7').fadeOut(1500);
  	}
	
	function DisBlock8(){
   $('div#rightcol8').fadeIn(1500);
   					}
  function close_block8(){
   $('div#rightcol8').fadeOut(1500);
  	}
	
	function DisBlock9(){
   $('div#rightcol9').fadeIn(1500);
   					}
  function close_block9(){
   $('div#rightcol9').fadeOut(1500);
  	}
	
	function DisBlock10(){
   $('div#rightcol10').fadeIn(1500);
   					}
  function close_block10(){
   $('div#rightcol10').fadeOut(1500);
  	}
	
	function DisBlock11(){
   $('div#rightcol11').fadeIn(1500);
   					}
  function close_block11(){
   $('div#rightcol11').fadeOut(1500);
  	}
	
	function DisBlock12(){
   $('div#rightcol12').fadeIn(1500);
   					}
  function close_block12(){
   $('div#rightcol12').fadeOut(1500);
  	}
	
	function DisBlock13(){
   $('div#rightcol13').fadeIn(1500);
   					}
  function close_block13(){
   $('div#rightcol13').fadeOut(1500);
  	}
	
	function DisBlock14(){
   $('div#rightcol14').fadeIn(1500);
   					}
  function close_block14(){
   $('div#rightcol14').fadeOut(1500);
  	}
	
	
</script>

	
	<!--всплывающие блоки-->

	
	
<div align="center" class="rightcol_style" id="rightcol" name="rightcol" onclick="close_block()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="высокий профессионализм" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px">
<img src="content/images/documentation_content/documentation1_big.jpg" 
class="hidden_div" alt="высокий профессионализм"/>
</div>
</div>
<!----->

<div align="center" class="rightcol_style" id="rightcol2" name="rightcol2" onclick="close_block2()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="лучшая компания в сфере реставрации" 
style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation2_big.jpg" 
class="hidden_div" alt="лучшая компания в сфере реставрации"/></div>
</div>



<div align="center" class="rightcol_style" id="rightcol3" name="rightcol3" onclick="close_block3()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="компания спецстрой благовещенск" 
style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation3_big.jpg" 
class="hidden_div" alt="компания спецстрой благовещенск"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol4" name="rightcol4" onclick="close_block4()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="реконструкция зданий" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%;margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation4_big.jpg" 
class="hidden_div" alt="реконструкция зданий"/></div>
</div>

