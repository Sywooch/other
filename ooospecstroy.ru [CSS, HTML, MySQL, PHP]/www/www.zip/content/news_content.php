<h1 class="myriad_pro14">ФУРНИТУРА</h1>
<h1 class="myriad_pro14">TIP-ON для TANDEMBOX, MOVENTO и TANDEM</h1>
<span class="myriad_pro12" style="text-align:left">

<!--<img src="content/images/news_content/image1.jpg" alt="" style="float:left;padding-right:15px;padding-bottom:10px;padding-top:3px;
 margin-right:0px"/>-->

Стандартные и высокие ящики без ручек легко
и без заминок открываются благодаря механической 

системе открывания TIP-ON для TANDEMBOX,
MOVENTO и TANDEM. Вам нужно лишь слегка нажать на
фасад в любом месте.</br>
Благодаря предлагаемому 
в качестве опции синхронизатору TIP-ON
работает даже с широкими ящиками.
Мебель с TIP-ON закрывается легким нажатием на фасад.
</span>
<img src="content/images/news_content/image2.jpg" alt="текстурное покрытие" style="float:right;padding-left:10px; padding-top:10px; margin-top:5px;
padding-bottom:15px; margin-right:0px"/>





<p align="left" class="myriad_pro12">AVENTOS HF – решение для верхних шкафов большого и среднего размера со складными фасадами для жилых помещений и кухонь.
</br> 
</br> 
<span style="list-style-type: disc; margin-left:0px" class="myriad_pro12">&bull;&nbsp;Высота корпуса от 480 до 1040 мм</br></br> </span>
<span style="list-style-type: disc; margin-left:0px" class="myriad_pro12">&bull;&nbsp;Ширина корпуса до 1800 мм</br></br> </span>
<span style="list-style-type: disc; margin-left:0px" class="myriad_pro12">&bull;&nbsp;Всего 3 типа силовых механизмов 
и 4 типа телескопических рычага для любых конструкций</br></br> </span>
<span style="list-style-type: disc; margin-left:0px" class="myriad_pro12">&bull;&nbsp;Силовые механизмы и крепления фасада можно
использовать с обеих сторон корпуса</br></br> </span>
<span style="list-style-type: disc; margin-left:0px" class="myriad_pro12">&bull;&nbsp;Для деревянных фасадов и фасадов с алюминиевой рамкой</br></br> </span>

<img src="content/images/news_content/image3.jpg" alt="отделка поверхностей" style="float:none; padding-left:0px; padding-top:0px; padding-right:10px;
margin-top:5px; padding-bottom:15px; margin-right:0px"/>
<!--<img align="bottom" src="content/images/news_content/image4.jpg" alt="" style="float:none; padding-left:0px; padding-top:5px; padding-right:0px;
margin-top:3px; padding-bottom:3px; margin-right:0px"/>-->

</p>




<h1 class="myriad_pro14">TANDEMBOX plus: ящик с круглым релингом и другие варианты оформления</h1>
<span class="myriad_pro12">
<img src="content/images/news_content/image5.jpg" alt="отделка поверхностей" style="float:left;padding-right:10px;padding-bottom:3px;padding-top:3px;
 margin-right:0px"/>
TANDEMBOX plus впечатляет своим разнообразным ассортиментом. Круглый релинг и различные высоты задней стенки и царги создают 
основу для различных вариантов дизайна мебели. Открытый или закрытый ящик, одинарный или двойной релинг – TANDEMBOX plus способен 
удовлетворить любые пожелания клиентов.
</span>
</br>
</br>
</br>
</br>

<h1 class="myriad_pro14">Многофункциональная проволочная корзина</h1>
<p class="myriad_pro12">Описание KRM01/900-1000/L</p>
<p class="myriad_pro12">

<a href="http://www.boyard.biz/catalog/kitchen/baskets/krm01-900-1000-l.html#leaf" alt="Перейти на сайт boyard.biz" 
title="Перейти на сайт boyard.biz">
<img src="content/images/news_content/image6.jpg" 
alt="терракоат замша" style="float:left;padding-right:10px;padding-bottom:10px;padding-top:3px; margin-right:0px; border:0"/></a></p>

<p class="myriad_pro12">Многофункциональная проволочная корзина решает проблему так называемого «мертвого» пространства – 
удаленных или труднодоступных зон. Эта сетчатая система отлично подходит для использования в угловых кухонных модулях, 
внутреннее пространство которых, как правило, частично закрыто от пользователя. С установкой такой корзины становится 
легко достижимым самый дальний уголок модуля. Принцип действия поворотно-выкатного механизма предполагает одновременное 
выдвижение корзин: наружу выдвигаются ближайшие корзины и занимают пространство в стороне от «входа» в шкаф, а их место 
внутри шкафа – легкодоступное, у самого «входа» – занимают корзины дальнего ряда. Всё, что размещено на передних или на 
задних корзинах, – удобно доставать и складывать на место. 
Двухуровневая конструкция состоит из четырех съемных корзин: две корзины переднего ряда и две – дальнего. Корзины легко 
снимаются и водружаются обратно. В зависимости от зоны расположения, корзина может стать вместительным хранилищем продуктов,
посуды, кастрюль, сковородок и прочей кухонной утвари, моющих принадлежностей и бытовой химии.   
Цвет корзины – полированный хром, с которым великолепно сочетается серый цвет механизма выдвижения. 
 </p>
</br>
<!-------------------------------------------------------------------------------------------------------->
<h1 class="myriad_pro14">ЗЕРКАЛА</h1>
<p class="myriad_pro12">Зеркала и стекла стали необходимыми элементами в нашей жизни, которые украшают любое пространство, они нас окружают 
 повсюду: в окнах, <a href="http://www.steklo-zerkalo.com/mebel-na-zakaz-2/" alt="" style="text-decoration:underline; color:#735f50"
 title="Перейти на сайт www.steklo-zerkalo.com">мебели</a>, 
 интерьере. Использование различных видов зеркал и стекла позволяет добиться индивидуального 
 дизайна в любом помещении.</p>
 

<div style="width:540px; height:300px">
<div align="center" style="width:180px; height:300px; float:left; ">
<h1 class="myriad_pro12">Стиль бронза</h1>
<img src="content/images/news_content/image7.jpg" alt="террако" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
<div align="center" style="width:180px; height:300px; float:left">
<h1 class="myriad_pro12">Изморозь зеркальная</h1>                                  
<img src="content/images/news_content/image8.jpg" alt="акриловое текстурное покрытие" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
<div align="center" style="width:180px; height:300px; float:left">
<h1 class="myriad_pro12">Старый город</h1>
<img src="content/images/news_content/image9.jpg" alt="терракоат сахара" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
</div>

<div style="width:540px; height:300px">
<div align="center" style="width:270px; height:300px; float:left">
<h1 class="myriad_pro12">Ностальгия</h1>
<img src="content/images/news_content/image10.jpg" alt="терракоат гранул" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
<div align="center" style="width:270px; height:300px; float:left">
<h1 class="myriad_pro12">Изморозь бронза</h1>                                  
<img src="content/images/news_content/image11.jpg" alt="компания спецстрой благовещенск" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
</div>

<div style="width:540px; height:300px">
<div align="center" style="width:270px; height:300px; float:left">
<h1 class="myriad_pro12">Деревья зеркальные</h1>
<img src="content/images/news_content/image12.jpg" alt="работы по реставрации" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
<div align="center" style="width:270px; height:300px; float:left">
<h1 class="myriad_pro12">Стиль белый</h1>
<img src="content/images/news_content/image13.jpg" alt="реставрационные работы" style="padding-right:0px;padding-bottom:0px;padding-top:0px; margin-right:0px"/>  
</div>
</div>



