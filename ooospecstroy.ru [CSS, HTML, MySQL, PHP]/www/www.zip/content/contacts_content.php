<script type="text/javascript">

  function DisBlock(){
   $('div#rightcol').fadeIn(1500);
   					}
  function close_block(){
   $('div#rightcol').fadeOut(1500);
  	}

  function DisBlock2(){
   $('div#rightcol2').fadeIn(1500);
   					}
  function close_block2(){
   $('div#rightcol2').fadeOut(1500);
  	}

  function DisBlock3(){
   $('div#rightcol3').fadeIn(1500);
   					}
  function close_block3(){
   $('div#rightcol3').fadeOut(1500);
  	}

  function DisBlock4(){
   $('div#rightcol4').fadeIn(1500);
   					}
  function close_block4(){
   $('div#rightcol4').fadeOut(1500);
  	}

  function DisBlock5(){
   $('div#rightcol5').fadeIn(1500);
   					}
  function close_block5(){
   $('div#rightcol5').fadeOut(1500);
  	}	
	
	function DisBlock6(){
   $('div#rightcol6').fadeIn(1500);
   					}
  function close_block6(){
   $('div#rightcol6').fadeOut(1500);
  	}
	
	function DisBlock7(){
   $('div#rightcol7').fadeIn(1500);
   					}
  function close_block7(){
   $('div#rightcol7').fadeOut(1500);
  	}
	
	function DisBlock8(){
   $('div#rightcol8').fadeIn(1500);
   					}
  function close_block8(){
   $('div#rightcol8').fadeOut(1500);
  	}
	
	function DisBlock9(){
   $('div#rightcol9').fadeIn(1500);
   					}
  function close_block9(){
   $('div#rightcol9').fadeOut(1500);
  	}
	
	function DisBlock10(){
   $('div#rightcol10').fadeIn(1500);
   					}
  function close_block10(){
   $('div#rightcol10').fadeOut(1500);
  	}
	
	function DisBlock11(){
   $('div#rightcol11').fadeIn(1500);
   					}
  function close_block11(){
   $('div#rightcol11').fadeOut(1500);
  	}
	
	function DisBlock12(){
   $('div#rightcol12').fadeIn(1500);
   					}
  function close_block12(){
   $('div#rightcol12').fadeOut(1500);
  	}
	
	function DisBlock13(){
   $('div#rightcol13').fadeIn(1500);
   					}
  function close_block13(){
   $('div#rightcol13').fadeOut(1500);
  	}
	
	function DisBlock14(){
   $('div#rightcol14').fadeIn(1500);
   					}
  function close_block14(){
   $('div#rightcol14').fadeOut(1500);
  	}
	
	
</script>

<h1 class="myriad_pro14">Контакты</h1>

<h1 class="myriad_pro12">Козлов Игорь Анатольевич.</br>
Должность - директор.</br>
Тел. 38-03-68</h1>
<div align="center" style="width:550px; height:745px; padding-bottom:20px">

<img src="content/images/contacts_content/0920.jpg" alt="шлифовка стекла" style="margin-left:0px; border:0"/>

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Еропкин Александр Николаевич.</br>
Должность - заместитель директора.</br>
Тел. 58-07-37</h1>
<div align="center" style="width:550px; height:333px; padding-bottom:20px">

<img src="content/images/contacts_content/4903.jpg" alt="компания спецстрой благовещенск" style="margin-left:0px; border:0" />

</div>



<hr size="1"/>
<h1 class="myriad_pro12">Румянцев Виктор Николаевич.</br>
Должность - менеджер по закупу.</br>
Тел. 58-08-78</h1>
<div align="center" style="width:550px; height:333px; padding-bottom:20px">

<img src="content/images/contacts_content/4900.jpg" alt="мебель на заказ" style="margin-left:0px; border:0" />

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Китова Нина Григорьевна.</br>
Должность - офис-менеджер.</br>
Тел. 53-72-72, 57-00-72</h1>
<div align="center" style="width:550px; height:333px; padding-bottom:20px">

<img src="content/images/contacts_content/4906.jpg" alt="прихожие" style="margin-left:0px;  border:0"/>

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Водяник Алексей Андреевич.</br>
Должность - мастер.</br>
Тел. 58-08-72</h1>
<div align="center" style="width:550px; height:397px; padding-bottom:20px">

<img src="content/images/contacts_content/9235.jpg" alt="шкафы" style="margin-left:0px; border:0" />

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Ланкина Светлана Александровна.</br>
Должность - дизайнер.</br>
Тел. 53-72-72, 57-00-72</h1>
<div align="center" style="width:550px; height:745px; padding-bottom:20px">

<img src="content/images/contacts_content/0384.jpg" alt="мягкая и детская мебель" style="margin-left:0px; border:0" />

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Ряднова Людмила Анатольевна.</br>
Должность - инженер по технадзору.</br>
Тел. 8-924-440-62-70</h1>
<div align="center" style="width:550px; height:486px; padding-bottom:20px">

<img src="content/images/contacts_content/9264.jpg" alt="ресепшен" style="margin-left:0px; border:0" />

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Савонов Олег Витальевич.</br>
Должность - мастер-строитель.</br>
Тел. 8-909-895-82-92</h1>
<div align="center" style="width:550px; height:752px; padding-bottom:20px">

<img src="content/images/contacts_content/6598.jpg" alt="барные стойки" style="margin-left:0px; border:0"/>

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Балановская Оксана Владимировна.</br>
Должность - продавец-консультант.</br>
Тел. 51-72-72, 58-70-75</h1>
<div align="center" style="width:550px; height:379px; padding-bottom:20px">

<img src="content/images/contacts_content/9254.jpg" alt="витрины" style="margin-left:0px; border:0" />

</div>

<hr size="1"/>
<h1 class="myriad_pro12">Карелов Николай Потапович.</br>
Должность - прораб.</br>
Тел. 8-914-381-56-39</h1>
<div align="center" style="width:550px; height:415px; padding-bottom:20px">

<img src="content/images/contacts_content/9258.jpg" alt="торговое оборудование" style="margin-left:0px; border:0" />

</div>
<hr size="1"/>
	
	

<h1 class="myriad_pro12">Добрынина Татьяна Юрьевна.</br>
Должность - главный бухгалтер.</br>
Тел. 53-72-72, 57-00-72</h1>
<div align="center" style="width:550px; height:333px; padding-bottom:20px">

<img src="content/images/contacts_content/4910.jpg" alt="выбор мебели" style="margin-left:0px; border:0" />
</a>
</div>	
<hr size="1"/>