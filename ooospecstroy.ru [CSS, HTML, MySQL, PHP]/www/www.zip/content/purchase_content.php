<h1 class="myriad_pro14">Закупка товаров КНР/Москва</h1>

<p class="myriad_pro12">
Экономика Китая предоставляет массу возможностей для производителей товаров, оптовиков, бизнесменов 
из разных стран. Маркировку “made in China” сегодня можно увидеть как на товарах народного 
потребления, так и на оборудовании, стройматериалах, автомобильных запчастях, 
на бытовой электронике – повсеместно.  
</p>

<p class="myriad_pro12">
Компания «Спецстрой» сотрудничает с некоторыми фирмали и заводами в КНР (Гуанджоу, Сяошань, Ханчжоу, 
Циндао, Хуанши), а также г. Москвы. И предлагаем  свои услуги по закупу и поставке  товаров.
</p>

<div  style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=1"/><img src="content/images/purchase_content/1.jpg" alt="компания спецстрой благовещенск" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=2"/><img src="content/images/purchase_content/2.jpg" alt="ремонтно-строительная компания" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=3"/><img src="content/images/purchase_content/3.jpg" alt="услуги по реставрации" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=4"/><img src="content/images/purchase_content/4.jpg" alt="реконструкция" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=5"/><img src="content/images/purchase_content/5.jpg" alt="ремонт" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=6"/><img src="content/images/purchase_content/6.jpg" alt="изготовление корпусной мебели" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div  style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=7"/><img src="content/images/purchase_content/7.jpg" alt="реставрация объектов культурного наследия" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=8"/><img src="content/images/purchase_content/8.jpg" alt="компания спецстрой благовещенск" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=9"/><img src="content/images/purchase_content/9.jpg" alt="стёкла и зеркала" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=10"/><img src="content/images/purchase_content/10.jpg" alt="обработка стекла" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=11"/><img src="content/images/purchase_content/11.jpg" alt="резка стекла и зеркал" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=12"/><img src="content/images/purchase_content/12.jpg" alt="фигурная резка" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=13"/><img src="content/images/purchase_content/13.jpg" alt="резка по шаблонам" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=14"/><img src="content/images/purchase_content/14.jpg" alt="шлифовка стекла" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=15"/><img src="content/images/purchase_content/15.jpg" alt="компания спецстрой благовещенск" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=16"/><img src="content/images/purchase_content/16.jpg" alt="мебель на заказ" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=17"/><img src="content/images/purchase_content/17.jpg" alt="прихожие" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=18"/><img src="content/images/purchase_content/18.jpg" alt="шкафы" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=19"/><img src="content/images/purchase_content/19.jpg" alt="мягкая и детская мебель" 
title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=20"/><img src="content/images/purchase_content/20.jpg" alt="ресепшен" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div  style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=21"/><img src="content/images/purchase_content/21.jpg" alt="барные стойки" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=22"/><img src="content/images/purchase_content/22.jpg" alt="витрины" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a></div>

<div  style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=23"/><img src="content/images/purchase_content/23.jpg" alt="торговое оборудование" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=24"/><img src="content/images/purchase_content/24.jpg" alt="выбор мебели" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>

<div  style="width:550px; height:300px; padding-bottom:10px">
<a href="purchase_foto.php?foto=25"/><img src="content/images/purchase_content/25.jpg" alt="эксклюзивная мебель" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:50px; border:0"/></a>
<a href="purchase_foto.php?foto=26"/><img src="content/images/purchase_content/26.jpg" alt="компания спецстрой благовещенск" title="Кликните, чтобы посмотреть увеличенную копию" 
style="float:left; cursor:pointer; margin-left:20px; border:0"/></a>
</div>
