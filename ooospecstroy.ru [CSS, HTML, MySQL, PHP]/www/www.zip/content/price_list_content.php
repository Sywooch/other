<h1 class="myriad_pro14">МЕБЕЛЬ</h1>
<h1 class="myriad_pro14">Расценки с 01.01.2013 по 31.12.2013 г.</h1>
<table style="width:550px; border-color:#735f50" border="1px" cellpadding="0" cellspacing="0" class="myriad_pro12">
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >№ п/п</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Наименование работ</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >Ед. изм.</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >Стоимость</td>
</tr>
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >1</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Шкаф-купе</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 10000</td>
</tr>
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >2</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Кухонный гарнитур</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 15000</td>
</tr>
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >3</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Прихожая открытая</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 7000</td>
</tr>
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >4</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Стол рабочий</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 7000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >5</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Стол рабочий угловой</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 11000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >6</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Кровать односпальная</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 8000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >7</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Кровать полутораспальная</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 15000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >8</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Горка</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 9000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >9</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Ресепшен</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 14000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >10</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Торговые стеллажи</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 6000</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >11</td>
<td style="width:250px; border-width:1px; border-color:#735f50; padding:5px" >Барная стойка</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >метр</td>
<td style="width:150px; border-width:1px; border-color:#735f50; padding:5px" >от 13000</td>
</tr>
</table>
</br>
</br>
<hr size="1">
<!------------------------------------------------------------------------------>
<h1 class="myriad_pro14">СТРОИТЕЛЬНЫЕ РАБОТЫ</h1>
<h1 class="myriad_pro14">Расценки с 01.01.2013 по 31.12.2013 г.</h1>
		<table style="width:550px; border-color:#735f50" border="1px" cellpadding="0" cellspacing="0" class="myriad_pro12">
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >№ п/п</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >Наименование работ</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >Ед. изм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >Стоимость</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">КИРПИЧНАЯ КЛАДКА</td>
</tr>
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >1</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж стен (перегородок) кирпичных толщ. до 250мм
</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >2</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж стен (перегородок) кирпичных толщ. до 120мм

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >3</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Кирпичная кладка стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000-7000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >4</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Кирпичная кладка перегородок

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >650-850
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >5</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка кирпичных стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200-300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >6</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Очистка кирпича от раствора

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1000шт</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >7</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Кладка стен с утеплением

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >700-1200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >8</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Закладка отверстий в стенах кирпичом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >9</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Закладка проёмов В1/2 кирпича

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400-450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >10</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка перемычек весом до 300 кг

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >2000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >11</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Приготовление раствора в ручную

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-1400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >12</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство декоративных ниш

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450-1000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >13</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Кладка стен стеклоблоками (с армированием)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >14</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство нишь под радиаторы

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >2000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >15</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Чистый скол бетона со стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >16</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Пробивка отверстий в кирпичных стенах

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >2400-4000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >17</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка железобетонных перегородок

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >18</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Кладка перегородок из сибита толщ. 100мм

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">БЕТОННЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >19</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство ленточного фундамента, Ж/Б оснований

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000-7000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >20</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство монолитных бетонных ступеней 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >4000-7500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >21</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Приготовление бетонной смеси вручную 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-1400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >22</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство монолитных участков

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3500-6000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >23</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка монолитных бетонных ступений

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >5000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >24</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Изготовление плоских каркасов (сеток)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900-1200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >25</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разбивка Ж/Б плиты компрессором

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >26</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Пробивка отверстий в Ж/Б перекрытиях

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >2000-3500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >27</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка железобетонных перегородок

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450-800
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ОБЛИЦОВОЧНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >28</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка глазированой плиткой откосов, подоконника

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >29</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка бассейнов, ван

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >30</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подготовка стен бассейнов, ванн жидким стеклом под облицовку

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >31</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подготовка стен под облицовку плиткой (насечки)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >170
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >32</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Удаление старой плитки со стен (со снятием раствора)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >33</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Обжиг старой краски со стен 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >34</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка плиткой ступеней и проступений 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >35</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка ступений в ванной и санузле

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >36</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Обрамление углов молдингом 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >37</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Наклейка плинтуса на ванну

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ШТУКАТУРНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >38</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Приготовление штукатурного раствора 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^3</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >39</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка по сетке-рабице

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400-530
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >40</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка по штробам

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150-250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >41</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Обшивка штукатурки с пов-ти колонн, пилястр, поясков

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350-450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >42</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">МАЛЯРНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >43</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Маслянная окраска окон 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >44</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Маслянная окраска дверей

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350-550
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >45</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Маслянная окраска пола

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >46</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Маслянная окраска труб и батарей

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >одна сек</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >47</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Улучшенная окраска со шпаклёвкой и шлифовкой окон

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-950
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >48</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Улучшенная окраска со шпаклёвкой и шлифовкой дверей

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500-650
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >49</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подготовка труб и батарей под покраску

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >одна сек</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >80
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >50</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старой краски с окон

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150-250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >51</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие лепнины

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >52</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Маслянная окраска окон витражного типа

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400-500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >53</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска поверхностей декоративными пленками

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >54</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Покраска лестничного марша

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >55</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Пропитка или лакировка вагонки, половой доски на 2 слоя

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >56</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Покраска колонн

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ОТКОСЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >57</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж из ГКЛ откосы

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >58</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Шпаклёвка откосов под покраску

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >220
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >59</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Выравнивание плоскостей откосов (сух. смеси)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >60</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка откосов

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >61</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство откосов из вагонки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >62</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Покраска откосов

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >190
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >63</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка обоями откосов, граней балок и колонн

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ГИПСОКАРТОН</td>
</tr>
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >64</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Обшивка стен Гипсокартоном

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >65</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство перегородок из ГКЛ с теплоизоляцией на металлическом каркасе 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >66</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Грунтовка поверзности стен из ГК

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >40
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >67</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Грунтовка поверхности потолка из ГК

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >60
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >68</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска поверхности стен из ГК

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >230
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >69</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска поверхности колонн и арок

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200-300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >70</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подшивка потолка ДВП

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300-400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >71</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подшивка потолка пенополистирольными плитами

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >72</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подшивка потолка пластиковыми панелями

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400-600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >73</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка потолочного плинтуса

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >74</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж перегородок из ГКЛ

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ПОЛЫ</td>
</tr>

<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >75</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка пола керамогранитом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >от 900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >76</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж плитки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >77</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство плитки на пол

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >78</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка пола высокой сложности

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900-1100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >79</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство цементной стяжки 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-330
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >80</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж цементно песчанной стяжки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >280
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >81</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка черепного бруска (лаги)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >82</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка ламината

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >83</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка паркетной доски

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450-550
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >84</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка массивной доски на фанеру

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600-700
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >85</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Частичное выравнивание слоем "VETONIT"

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >86</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Настил линолиума (холодная сварка)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >87</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство деревянного плинтуса

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >88</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка пластикового плинтуса

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >89</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старого линолеума

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >90</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка линолеума

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >91</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство метал. порогов

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >92</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство штучного паркетного пола (на фанеру)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >93</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство гидроизоляции мастикой 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >94</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство гидроизоляции полиэтиленом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >60
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >95</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка фанеры с креплением на шурупы и дюбеля

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >96</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Уладка паркета с разметкой

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >97</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка паркетного пола до основания

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >98</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство досчатых полов (ДВП,ДСП, половая рейка)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >99</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка лаг

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >100</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство пароизоляции

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >101</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка утеплителя

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >130
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >102</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство обрешетки из брусков

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >103</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство чистого пола из половой решетки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >170
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >104</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разборка деревянного пола

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >105</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Настил досчатого покрытия

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400-550
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >106</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство деревянного пола по лагам на балконах, лоджиях

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >107</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство пола из ламинированного паркета

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >108</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Высококачественная подготовка под линолиум(ламинат) слоем "VETONIT"

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >109</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Укладка подложки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >50
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >110</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство кирпичных столбиков под лаги

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >111</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Разбивка цементной стяжки компрессором

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >112</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж плинтуса кирамического

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">СТЕНЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >113</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >114</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка стен  по маякам в уровешь

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >115</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Выравнивание плоскостей стен (сухими смесями)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >116</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж ГКЛ на стены

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >117</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж перегородки из ГКЛ

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >650
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >118</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж плитки 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >119</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка стен плиткой

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900-1000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >120</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка стен плиткой и пола мозаикой

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >121</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка стен плиткой без шва

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >122</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка стен высокой сложности 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1000-1200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >123</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка кафелем 10х10

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >124</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж стеновых панелей

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >125</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж утеплителя на стены толщ. 50 мм

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >126</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Стены МДФ прямо, пластиковыми панелями

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >127</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Стены МДФ с рисунком

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >128</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Обшивка стен сайдингом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >550
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >129</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Шпаклевка стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >280
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >130</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство декоративной штукатурки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >от 500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >131</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Шпаклевка стен под обои

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >220
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >132</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Шпаклевка стен по маякам

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >133</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Грунтовка стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >50
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >134</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство лепнины из твердого полиуретана на стене

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >135</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска стен водными составами

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >220
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >136</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска стен декоративной краской KRASTONE

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >137</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска стен декоративной краской KRASTONE 2 цвета

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >138</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка стен стеклохолстом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >220
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >139</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старой краски

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150-200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >140</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старой штукатурки со стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250-350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >141</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка стен пробкой, плиткой ПВХ

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >от 400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >142</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство бордюра из плитки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >143</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж перф.угла

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >144</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Отделка вагонкой стен в помещениях до 15м2(ванна, балкон)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >550-650
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >145</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Отделка вагонкой стен в помещениях >25 м2

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >146</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Отверстие в кафеле 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ОБОЙНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >147</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Удаление старых обоев со стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >60
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >148</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Удаление старых обоев с потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >149</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Подготовка стен под обои (грунтовка)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >50
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >150</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка стен обоями 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >151</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка стен обоями с двух цветов или с рисунком

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >280
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >152</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Наклейка бордюра обойного 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >пм</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >153</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Отделка стен жидкими обоями

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >154</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка стен гладкими стеклообоями  

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ПОТОЛОК</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >155</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Штукатурка потолка 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350-450
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >156</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Грунтовка потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >70
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >157</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Шпаклёвка потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300-400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >158</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >159</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска потолка декоративной краской KRASTON 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >160</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Окраска потолка декоративной краской KRASTON 2 цвета

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >161</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство реечных подвестных потолков 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >162</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Оклейка потолка стеклохолстом

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >240
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >163</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Потолок "ARMSTRONG"

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450-550
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >164</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж потолка армстронг

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >165</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж плиток потолка армстронг с сохранением направляюших

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >166</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Потолок  "LUXALON"

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >550-650
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >167</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство потолка ГКЛ 1 уровень

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >168</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство потолка ГКЛ 2 уровня

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >169</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство потолка ГКЛ 3 уровня

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >170</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство разноуровнего потолка из ГКЛ сложных геометрических форм с 
криволинейными элементами с усиленной конструкцией

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1500-1900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >171</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старой штукатурки с потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300-400
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >172</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Снятие старой краски с  потока

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200-250
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >173</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Работы с ГКЛ (ГВЛ)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >450-600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >174</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж потолочного плинтуса полистирольного до 45мм

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >175</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж полиуретанового плинтуса высотой 45-8мм

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >350
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >176</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж полиуретанового плинтуса из гипса высотой свыше 80

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-900
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >177</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж колонн плоских полиуретановых

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >178</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Покраска потолочного плинтуса в единый с потолком цвет

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >70
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >179</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Покраска потолоч. плинтуса в цвет, отличный от потолка

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >180</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Выравнивание плоскостей потолков

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >181</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Отделка вагонкой потолков в помещениях

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >650
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ПЛОТНИЦКИЕ, СТОЛЯРНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >182</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка межкомнатных дверей

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >2000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >183</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена вентиляционной решетки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >100
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >184</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена дверного блока (1 полотно)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >185</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена дверного блока (2 полотна)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1800
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >186</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена дверного полотна с подгонкой

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1800
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >187</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена дверного полотна без подгонки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >188</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Замена оконного блока

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >189</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Заделка дверных блоков пенобетоном

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >п.м</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >150
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >190</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Заделка дверных и оконных блоков раствором

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >191</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка дверного замка 

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >192</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Врезка и установка фурнитуры

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >193</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка металлической двери

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >194</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Демонтаж старого дверного блока

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >195</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство подоконников

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >600
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px">
<td style="width:550px; border-width:1px; border-color:#735f50; padding:5px" colspan="4">ФАСАДНЫЕ РАБОТЫ</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >196</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Сайдинговые системы с утеплением (пластиковые)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1200-1500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >197</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Металлосайдинг с утеплением

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1200-1500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >198</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Сайдинг с профлиста  с утеплением

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1200-1500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >199</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Фиброцементная плита

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >1400 - 1800
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >200</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Блок "Хаус"(2,40м)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >шт.</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >300
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >201</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка фасада плиткой типа "кабанчик"

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >900-1200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >202</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Облицовка фасада мрамором

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >800-1200
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >203</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж алюкобонда (касетами)

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >4500-5500
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >204</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Монтаж алюкобонда по профилям

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >3000-4000
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >205</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Установка Инвентарных лесов

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >120
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >206</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Устройство навеса-заграждения из сетки

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >50
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >207</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Протравка нейтрализующим раствором стен

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >80
</td>
</tr>
<!---------------------------------------------------------->
<tr style="width:550px; text-align:left">
<td style="width:50px; border-width:1px; border-color:#735f50; padding:5px" >208</td>
<td style="width:300px; border-width:1px; border-color:#735f50; padding:5px" >
Расшивка трещин в стенах

</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >м^2</td>
<td style="width:100px; border-width:1px; border-color:#735f50; padding:5px" >140
</td>
</tr>

</table>

<h1 class="myriad_pro14">ЕВРО-РЕМОНТ 8000-10000</h1>
<h1 class="myriad_pro14">ЭКОНОМ 3500-5000</h1>
<h1 class="myriad_pro14">ОБЫЧНЫЙ 2000-4000</h1>
<h1 class="myriad_pro14">ДИЗАЙН 350</h1>
<h1 class="myriad_pro14">ВЫНОС МУСОРА  500 этаж</h1>