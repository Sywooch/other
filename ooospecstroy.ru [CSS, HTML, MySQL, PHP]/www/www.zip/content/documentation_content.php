
<script type="text/javascript">

  function DisBlock(){
   $('div#rightcol').fadeIn(1500);
   					}
  function close_block(){
   $('div#rightcol').fadeOut(1500);
  	}

  function DisBlock2(){
   $('div#rightcol2').fadeIn(1500);
   					}
  function close_block2(){
   $('div#rightcol2').fadeOut(1500);
  	}

  function DisBlock3(){
   $('div#rightcol3').fadeIn(1500);
   					}
  function close_block3(){
   $('div#rightcol3').fadeOut(1500);
  	}

  function DisBlock4(){
   $('div#rightcol4').fadeIn(1500);
   					}
  function close_block4(){
   $('div#rightcol4').fadeOut(1500);
  	}

  function DisBlock5(){
   $('div#rightcol5').fadeIn(1500);
   					}
  function close_block5(){
   $('div#rightcol5').fadeOut(1500);
  	}	
	
	function DisBlock6(){
   $('div#rightcol6').fadeIn(1500);
   					}
  function close_block6(){
   $('div#rightcol6').fadeOut(1500);
  	}
	
	function DisBlock7(){
   $('div#rightcol7').fadeIn(1500);
   					}
  function close_block7(){
   $('div#rightcol7').fadeOut(1500);
  	}
	
	function DisBlock8(){
   $('div#rightcol8').fadeIn(1500);
   					}
  function close_block8(){
   $('div#rightcol8').fadeOut(1500);
  	}
	
	function DisBlock9(){
   $('div#rightcol9').fadeIn(1500);
   					}
  function close_block9(){
   $('div#rightcol9').fadeOut(1500);
  	}
	
	function DisBlock10(){
   $('div#rightcol10').fadeIn(1500);
   					}
  function close_block10(){
   $('div#rightcol10').fadeOut(1500);
  	}
	
	function DisBlock11(){
   $('div#rightcol11').fadeIn(1500);
   					}
  function close_block11(){
   $('div#rightcol11').fadeOut(1500);
  	}
	
	function DisBlock12(){
   $('div#rightcol12').fadeIn(1500);
   					}
  function close_block12(){
   $('div#rightcol12').fadeOut(1500);
  	}
	
	function DisBlock13(){
   $('div#rightcol13').fadeIn(1500);
   					}
  function close_block13(){
   $('div#rightcol13').fadeOut(1500);
  	}
	
	function DisBlock14(){
   $('div#rightcol14').fadeIn(1500);
   					}
  function close_block14(){
   $('div#rightcol14').fadeOut(1500);
  	}
	
	
</script>


	<h1 class="myriad_pro14">Документация</h1>
	</br>
	<h1 class="myriad_pro12"><em>Лицензия</em> на осуществление деятельности по сохранению объёктов культурного наследия 
	Российской Федерации.</h1>
	<div align="center" style="width:540px; height:300px">
		<div style="width:440px;height:300px"><img src="content/images/documentation_content/documentation5_1.jpg" 
		alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="float:left; cursor:pointer" onclick="DisBlock5()"/>
	<img src="content/images/documentation_content/documentation5_2.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="float:left; margin-left:10px; cursor:pointer" onclick="DisBlock6()"/></div></div>
	
	<div align="center" style="width:540px; height:300px; margin-top:10px">
	<img src="content/images/documentation_content/documentation5_3.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию"  style="cursor:pointer" onclick="DisBlock7()"/>	</div>
	
	</br>
	<h1 class="myriad_pro12"><em>Свидетельство</em> на изготовлении мебели.</h1>
	<div align="center" style="width:540px; height:300px">
		<img src="content/images/documentation_content/documentation6.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock8()"/>
	</div>
	</br>
	<h1 class="myriad_pro12">Регистрационное <em>свидетельство</em>.</h1>
	<div align="center" style="width:540px; height:300px">
		<img src="content/images/documentation_content/documentation7.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock9()"/>
	</div>
	</br>
	<h1 class="myriad_pro12"><em>Свидетельство</em> о допуске к определённым видам работ.</h1>
	
	
	<div align="center" style="width:540px; height:300px">
	<div style="width:440px; height:300px">
		<img src="content/images/documentation_content/documentation8_1.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="float:left; cursor:pointer" onclick="DisBlock10()"/>
	<img src="content/images/documentation_content/documentation8_2.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="margin-left:10px; cursor:pointer" onclick="DisBlock11()"/>
	</div>
		</div>
		
		
		
		<div align="center" style="width:540px; height:300px; margin-top:10px">
		<div style="width:440px; height:300px">
	<img src="content/images/documentation_content/documentation8_3.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="float:left; cursor:pointer" onclick="DisBlock12()"/>
		<img src="content/images/documentation_content/documentation8_4.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="margin-left:10px; cursor:pointer" onclick="DisBlock13()"/>
	</div>
	</div>
	
	<div align="center" style="width:540px; height:300px; margin-top:10px">
	<img src="content/images/documentation_content/documentation8_5.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию"  style="cursor:pointer" onclick="DisBlock14()"/>
	</div>
	</br>
<!------------------------------------------------------------------------------------------------------------------------>


	<!--всплывающие блоки-->

	
	
<div align="center" class="rightcol_style" id="rightcol" name="rightcol" onclick="close_block()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="эксклюзивная мебель" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px">
<img src="content/images/documentation_content/documentation1_big.jpg" 
class="hidden_div" alt="компания спецстрой благовещенск"/>
</div>
</div>
<!----->

<div align="center" class="rightcol_style" id="rightcol2" name="rightcol2" onclick="close_block2()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="высокий профессионализм" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation2_big.jpg" 
class="hidden_div" alt="лучшая компания в сфере реставрации"/></div>
</div>



<div align="center" class="rightcol_style" id="rightcol3" name="rightcol3" onclick="close_block3()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="компания спецстрой благовещенск" 
style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation3_big.jpg" 
class="hidden_div" alt="реконструкция зданий"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol4" name="rightcol4" onclick="close_block4()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="реконструкция фасадов" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%;margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation4_big.jpg" 
class="hidden_div" alt="реконструкционные работы"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol5" name="rightcol5" onclick="close_block5()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="компания спецстрой благовещенск" 
style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%;margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation5_1_big.jpg" 
class="hidden_div" alt="бухгалтерское обслуживание организации"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol6" name="rightcol6" onclick="close_block6()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="восстановление бухучёта" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation5_2_big.jpg" 
class="hidden_div" alt="составление бухгалтерской и налоговой отчётности"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol7" name="rightcol7" onclick="close_block7()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="компания спецстрой благовещенск" 
style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation5_3_big.jpg" 
class="hidden_div" alt="дизайн мебели"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol8" name="rightcol8" onclick="close_block8()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="интерьер" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation6_big.jpg" 
class="hidden_div" alt="дизайн корпусной мебели"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol9" name="rightcol9" onclick="close_block9()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="компания спецстрой благовещенск" 
 style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 0px"><img src="content/images/documentation_content/documentation7_big.jpg" 
class="hidden_div" alt="шкаф-купе"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol10" name="rightcol10" onclick="close_block10()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="кухонный гарнитур" style="margin-left:35%; cursor:pointer"/></div>
<div  align="center" style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation8_1_big.jpg" 
class="hidden_div" alt="торговые стеллажи"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol11" name="rightcol11" onclick="close_block11()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="мебель" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation8_2_big.jpg" 
class="hidden_div" alt="стоительные работы"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol12" name="rightcol12" onclick="close_block12()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="кирпичная кладка" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation8_3_big.jpg" 
class="hidden_div" alt="бетонные работы"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol13" name="rightcol13" onclick="close_block13()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="облицовочные работы" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%;margin:-0px 0 0 -0px;"><img src="content/images/documentation_content/documentation8_4_big.jpg" 
class="hidden_div" alt="штукатурные работы"/></div>
</div>

<div align="center" class="rightcol_style" id="rightcol14" name="rightcol14" onclick="close_block14()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div  style="width:100%; margin-bottom:0px; position:fixed"><img src="images/close.png" alt="малярные работы" style="margin-left:35%; cursor:pointer"/></div>
<div align="center"  style="top:0%;left:0%; margin: 0px 0 0 -0px;"><img src="content/images/documentation_content/documentation8_5_big.jpg" 
class="hidden_div" alt="гипсокартон"/></div>
</div>

	
	