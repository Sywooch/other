
<script type="text/javascript">

  function DisBlock(){
   $('div#rightcol').fadeIn(1500);
   					}
  function close_block(){
   $('div#rightcol').fadeOut(1500);
  	}

  function DisBlock2(){
   $('div#rightcol2').fadeIn(1500);
   					}
  function close_block2(){
   $('div#rightcol2').fadeOut(1500);
  	}

  function DisBlock3(){
   $('div#rightcol3').fadeIn(1500);
   					}
  function close_block3(){
   $('div#rightcol3').fadeOut(1500);
  	}

  function DisBlock4(){
   $('div#rightcol4').fadeIn(1500);
   					}
  function close_block4(){
   $('div#rightcol4').fadeOut(1500);
  	}

  function DisBlock5(){
   $('div#rightcol5').fadeIn(1500);
   					}
  function close_block5(){
   $('div#rightcol5').fadeOut(1500);
  	}	
	
	function DisBlock6(){
   $('div#rightcol6').fadeIn(1500);
   					}
  function close_block6(){
   $('div#rightcol6').fadeOut(1500);
  	}
	
	function DisBlock7(){
   $('div#rightcol7').fadeIn(1500);
   					}
  function close_block7(){
   $('div#rightcol7').fadeOut(1500);
  	}
	
	function DisBlock8(){
   $('div#rightcol8').fadeIn(1500);
   					}
  function close_block8(){
   $('div#rightcol8').fadeOut(1500);
  	}
	
	function DisBlock9(){
   $('div#rightcol9').fadeIn(1500);
   					}
  function close_block9(){
   $('div#rightcol9').fadeOut(1500);
  	}
	
	function DisBlock10(){
   $('div#rightcol10').fadeIn(1500);
   					}
  function close_block10(){
   $('div#rightcol10').fadeOut(1500);
  	}
	
	function DisBlock11(){
   $('div#rightcol11').fadeIn(1500);
   					}
  function close_block11(){
   $('div#rightcol11').fadeOut(1500);
  	}
	
	function DisBlock12(){
   $('div#rightcol12').fadeIn(1500);
   					}
  function close_block12(){
   $('div#rightcol12').fadeOut(1500);
  	}
	
	function DisBlock13(){
   $('div#rightcol13').fadeIn(1500);
   					}
  function close_block13(){
   $('div#rightcol13').fadeOut(1500);
  	}
	
	function DisBlock14(){
   $('div#rightcol14').fadeIn(1500);
   					}
  function close_block14(){
   $('div#rightcol14').fadeOut(1500);
  	}
	
	
	
	function DisBlock15(){
   $('div#rightcol15').fadeIn(1500);
   					}
  function close_block15(){
   $('div#rightcol15').fadeOut(1500);
  	}
	
	
	
	function DisBlock16(){
   $('div#rightcol16').fadeIn(1500);
   					}
  function close_block16(){
   $('div#rightcol16').fadeOut(1500);
  	}
	
	
	function DisBlock17(){
   $('div#rightcol17').fadeIn(1500);
   					}
  function close_block17(){
   $('div#rightcol17').fadeOut(1500);
  	}
	
	
	function DisBlock18(){
   $('div#rightcol18').fadeIn(1500);
   					}
  function close_block18(){
   $('div#rightcol18').fadeOut(1500);
  	}
	
	
	function DisBlock19(){
   $('div#rightcol19').fadeIn(1500);
   					}
  function close_block19(){
   $('div#rightcol19').fadeOut(1500);
  	}
	
	
	
	function DisBlock20(){
   $('div#rightcol20').fadeIn(1500);
   					}
  function close_block20(){
   $('div#rightcol20').fadeOut(1500);
  	}
	
	
	
	function DisBlock21(){
   $('div#rightcol21').fadeIn(1500);
   					}
  function close_block21(){
   $('div#rightcol21').fadeOut(1500);
  	}
	
	
	
	function DisBlock22(){
   $('div#rightcol22').fadeIn(1500);
   					}
  function close_block22(){
   $('div#rightcol22').fadeOut(1500);
  	}
	
	

	
	
	
</script>


<h1 class="myriad_pro14">Сертификаты</h1>
	
	
</br>


<div align="left" style="width:540px; height:350px">
	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px ">
	<img src="content/images/certificates_content/1.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock()"/>
	</div>
	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/2.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock2()"/>
	</div>
	
</div>


		


	
<div align="left" style="width:540px; height:350px">
	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/3.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock3()"/>
	</div>
	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/4.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock4()"/>
	</div>

</div>	
	
	
	
<div align="left" style="width:540px; height:350px">
	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/5.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock5()"/>
	</div>

	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/6.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock6()"/>
	</div>
</div>
	
	
	
	
	
	<div align="left" style="width:540px; height:350px">

	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/7.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock7()"/>
	</div>


	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/8.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock8()"/>
	</div>
	</div>
	
	
	
	
	<div align="left" style="width:540px; height:350px">

	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/9.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock9()"/>
	</div>

	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/10.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock10()"/>
	</div>
	</div>
	

	
	
	
	
	<div align="left" style="width:540px; height:350px">
	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/12.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock12()"/>
	</div>

	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/13.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock13()"/>
	</div>
		</div>
	
	
	
	
	<div align="left" style="width:540px; height:350px">

	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/14.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock14()"/>
	</div>

	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/15.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock15()"/>
	</div>
	</div>
	
	
	
	
	
	<div align="left" style="width:540px; height:350px">

	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/16.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock16()"/>
	</div>
	
	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/17.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock17()"/>
	</div>
	</div>
	
	
	
	
	<div align="left" style="width:540px; height:350px">

	<div align="center" style="width:200px; height:350px; float:left; margin-left:65px">
	<img src="content/images/certificates_content/18.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock18()"/>
	</div>

	<div align="center" style="width:200px; height:350px; margin-left:20px; float:left">
	<img src="content/images/certificates_content/19.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock19()"/>
	</div>
	</div>
	
	
	
	
	
	
	
	
	

	<div align="center" style="width:540px; height:300px">
	<img src="content/images/certificates_content/20.jpg" alt="Кликните, чтобы увидеть увеличенную копию" 
	title="Кликните, чтобы увидеть увеличенную копию" style="cursor:pointer" onclick="DisBlock20()"/>
	</div>
	
	

	
	
<!------------------------------------------------------------------------------------------------------------------------>
	<!--всплывающие блоки-->
	<div class="rightcol_style" id="rightcol" name="rightcol" onclick="close_block()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -302px;"><img src="content/images/certificates_content/1_big.jpg" style="max-width:100%" 
alt="акриловое текстурное покрытие"/></div>
</div>

<div class="rightcol_style" id="rightcol2" name="rightcol2" onclick="close_block2()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/2_big.jpg" style="max-width:100%"
alt="терракоат сахара"/></div>
</div>

<div class="rightcol_style" id="rightcol3" name="rightcol3" onclick="close_block3()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -303px;"><img src="content/images/certificates_content/3_big.jpg" style="max-width:100%"
style="терракоат гранул"/></div>
</div>

<div class="rightcol_style" id="rightcol4" name="rightcol4" onclick="close_block4()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -302px;"><img src="content/images/certificates_content/4_big.jpg" style="max-width:100%"
alt="компания спецстрой благовещенск"/></div>
</div>

<div class="rightcol_style" id="rightcol5" name="rightcol5" onclick="close_block5()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -312px;"><img src="content/images/certificates_content/5_big.jpg" style="max-width:100%"
alt="работы по реставрации"/></div>
</div>

<div class="rightcol_style" id="rightcol6" name="rightcol6" onclick="close_block6()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку" >
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/6_big.jpg" style="max-width:100%"
alt="реставрационные работы"/></div>
</div>


<div class="rightcol_style" id="rightcol7" name="rightcol7" onclick="close_block7()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -290px"><img src="content/images/certificates_content/7_big.jpg" 
style="max-width:100%" alt="классические принципы реставрации"/></div>
</div>
<!----------------------------------------------------------------------->
<div class="rightcol_style" id="rightcol8" name="rightcol8" onclick="close_block8()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/8_big.jpg" style="max-width:100%"
alt="компания спецстрой благовещенск"/></div>
</div>

<div class="rightcol_style" id="rightcol9" name="rightcol9" onclick="close_block9()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/9_big.jpg" style="max-width:100%"
alt="ремонтно-строительная компания"/></div>
</div>

<div class="rightcol_style" id="rightcol10" name="rightcol10" onclick="close_block10()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/10_big.jpg" style="max-width:100%"
alt="услуги по реставрации"/></div>
</div>

<div class="rightcol_style" id="rightcol11" name="rightcol11" onclick="close_block11()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/11_big.jpg" style="max-width:100%"
alt="реконструкция"/></div>
</div>

<div class="rightcol_style" id="rightcol12" name="rightcol12" onclick="close_block12()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/12_big.jpg" style="max-width:100%"
alt="ремонт"/></div>
</div>

<div class="rightcol_style" id="rightcol13" name="rightcol13" onclick="close_block13()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/13_big.jpg" style="max-width:100%"
alt="изготовление корпусной мебели"/></div>
</div>

<div class="rightcol_style" id="rightcol14" name="rightcol14" onclick="close_block14()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/14_big.jpg" style="max-width:100%"
alt="реставрация объектов культурного наследия"/></div>
</div>

<div class="rightcol_style" id="rightcol15" name="rightcol15" onclick="close_block15()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/15_big.jpg" style="max-width:100%"
alt="компания спецстрой благовещенск"/></div>
</div>

<div class="rightcol_style" id="rightcol16" name="rightcol16" onclick="close_block16()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/16_big.jpg" style="max-width:100%"
alt="стёкла и зеркала"/></div>
</div>

<div class="rightcol_style" id="rightcol17" name="rightcol17" onclick="close_block17()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/17_big.jpg" style="max-width:100%"
alt="обработка стекла"/></div>
</div>

<div class="rightcol_style" id="rightcol18" name="rightcol18" onclick="close_block18()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/18_big.jpg" style="max-width:100%"
alt="резка стекла и зеркал"/></div>
</div>

<div class="rightcol_style" id="rightcol19" name="rightcol19" onclick="close_block19()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/19_big.jpg" style="max-width:100%"
alt="фигурная резка"/></div>
</div>

<div class="rightcol_style" id="rightcol20" name="rightcol20" onclick="close_block20()" style="width:100%;height:100%" 
title="Кликните, чтобы скрыть картинку">
<div style="top:0%;left:50%; position:absolute;margin:-0px 0 0 -300px;"><img src="content/images/certificates_content/20_big.jpg" style="max-width:100%"
alt="резка по шаблонам"/></div>
</div>

