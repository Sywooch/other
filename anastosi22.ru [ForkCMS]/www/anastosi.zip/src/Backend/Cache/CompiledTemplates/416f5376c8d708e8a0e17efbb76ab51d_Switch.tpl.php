<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<td id="fullwidthSwitch">
	<a href="#close">&nbsp;</a>
</td>