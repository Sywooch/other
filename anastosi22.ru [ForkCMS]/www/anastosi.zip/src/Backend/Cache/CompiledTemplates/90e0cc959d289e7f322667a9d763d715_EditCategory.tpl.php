<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<?php
					if(isset($this->forms['edit_category']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['edit_category']->getAction(); ?>" method="<?php echo $this->forms['edit_category']->getMethod(); ?>"<?php echo $this->forms['edit_category']->getParametersHTML(); ?>>
						<?php echo $this->forms['edit_category']->getField('form')->parse();
						if($this->forms['edit_category']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['edit_category']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['edit_category']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
    <div class="pageTitle">
        <h2><?php if(array_key_exists('lblCategory', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCategory']); } else { ?>{$lblCategory|ucfirst}<?php } ?>: <?php if(array_key_exists('title', (array) $this->variables)) { echo $this->variables['title']; } else { ?>{$title}<?php } ?></h2>
    </div>

    <div class="tabs">
        <ul>
            <li><a href="#tabContent"><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?></a></li>
            <li><a href="#tabSEO"><?php if(array_key_exists('lblSEO', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSEO']); } else { ?>{$lblSEO|ucfirst}<?php } ?></a></li>
        </ul>

        <div class="ui-tabs">
            <div class="ui-tabs-panel">

                <div id="tabContent">
                    <div class="options">
                        <p>
                            <label for="name"><?php if(array_key_exists('lblTitle', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTitle']); } else { ?>{$lblTitle|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
                            <?php if(array_key_exists('txtTitle', (array) $this->variables)) { echo $this->variables['txtTitle']; } else { ?>{$txtTitle}<?php } ?> <?php if(array_key_exists('txtTitleError', (array) $this->variables)) { echo $this->variables['txtTitleError']; } else { ?>{$txtTitleError}<?php } ?>
                        </p>
                    </div>
                </div>

                <div id="tabSEO">
                    <?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/seo.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/seo.tpl}<?php
				}
?>
                </div>
            </div>
        </div>
    </div>

    <div class="fullwidthOptions">
        <?php
					if(isset($this->variables['showDelete']) && count($this->variables['showDelete']) != 0 && $this->variables['showDelete'] != '' && $this->variables['showDelete'] !== false)
					{
						?>
            <a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'delete_category'); } else { ?>{$var|geturl:'delete_category'}<?php } ?>&amp;id=<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
                <span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
            </a>
            <div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
                <p>
                    <?php if(array_key_exists('msgConfirmDeleteCategory', (array) $this->variables) && array_key_exists('title', (array) $this->variables)) { echo sprintf($this->variables['msgConfirmDeleteCategory'], $this->variables['title']); } else { ?>{$msgConfirmDeleteCategory|sprintf:<?php if(array_key_exists('title', (array) $this->variables)) { echo $this->variables['title']; } else { ?>{$title}<?php } ?>}<?php } ?>
                </p>
            </div>
        <?php } ?>
        <div class="buttonHolderRight">
            <input id="editButton" class="inputButton button mainButton" type="submit" name="edit" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
        </div>
    </div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
