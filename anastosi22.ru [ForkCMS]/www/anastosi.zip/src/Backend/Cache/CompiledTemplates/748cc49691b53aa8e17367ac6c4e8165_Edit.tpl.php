<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<?php
					if(isset($this->forms['edit']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['edit']->getAction(); ?>" method="<?php echo $this->forms['edit']->getMethod(); ?>"<?php echo $this->forms['edit']->getParametersHTML(); ?>>
						<?php echo $this->forms['edit']->getField('form')->parse();
						if($this->forms['edit']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['edit']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['edit']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="pageTitle">
		<h2><?php if(array_key_exists('lblFormBuilder', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFormBuilder']); } else { ?>{$lblFormBuilder|ucfirst}<?php } ?>: <?php if(array_key_exists('lblEditForm', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['lblEditForm'], $this->variables['name']); } else { ?>{$lblEditForm|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></h2>
	</div>

	<script type="text/javascript">
		//<![CDATA[
			var defaultErrorMessages = {};

			<?php
					if(isset($this->variables['errors']) && count($this->variables['errors']) != 0 && $this->variables['errors'] != '' && $this->variables['errors'] !== false)
					{
						?>
				<?php
					if(!isset($this->variables['errors']))
					{
						?>{iteration:errors}<?php
						$this->variables['errors'] = array();
						$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['fail'] = true;
					}
				if(isset(${'errors'})) $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['old'] = ${'errors'};
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['iteration'] = $this->variables['errors'];
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['i'] = 1;
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['count'] = count($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['iteration'] as ${'errors'})
				{
					if(!isset(${'errors'}['first']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['i'] == 1) ${'errors'}['first'] = true;
					if(!isset(${'errors'}['last']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['i'] == $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['count']) ${'errors'}['last'] = true;
					if(isset(${'errors'}['formElements']) && is_array(${'errors'}['formElements']))
					{
						foreach(${'errors'}['formElements'] as $name => $object)
						{
							${'errors'}[$name] = $object->parse();
							${'errors'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
					defaultErrorMessages.<?php if(array_key_exists('type', (array) ${'errors'})) { echo ${'errors'}['type']; } else { ?>{$errors->type}<?php } ?> = '<?php if(array_key_exists('message', (array) ${'errors'})) { echo ${'errors'}['message']; } else { ?>{$errors->message}<?php } ?>';
				<?php
					$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['fail']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:errors}<?php
					}
				if(isset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['old'])) ${'errors'} = $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']['old'];
				else unset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_1']);
				?>
			<?php } ?>
		//]]>
	</script>

	<input type="hidden" name="id" id="formId" value="<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" />

	<div class="tabs">
		<ul>
			<li><a href="#tabGeneral"><?php if(array_key_exists('lblGeneral', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblGeneral']); } else { ?>{$lblGeneral|ucfirst}<?php } ?></a></li>
			<li><a href="#tabFields"><?php if(array_key_exists('lblFields', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFields']); } else { ?>{$lblFields|ucfirst}<?php } ?></a></li>
			<li><a href="#tabExtra"><?php if(array_key_exists('lblExtra', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExtra']); } else { ?>{$lblExtra|ucfirst}<?php } ?></a></li>
		</ul>

		<div id="tabGeneral" class="box">
			<div class="horizontal">
				<div class="options">
					<p>
						<label for="name"><?php if(array_key_exists('lblName', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblName']); } else { ?>{$lblName|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
						<?php if(array_key_exists('txtName', (array) $this->variables)) { echo $this->variables['txtName']; } else { ?>{$txtName}<?php } ?> <?php if(array_key_exists('txtNameError', (array) $this->variables)) { echo $this->variables['txtNameError']; } else { ?>{$txtNameError}<?php } ?>
					</p>
				</div>
				<div class="options">
					<p class="p0">
						<label for="method"><?php if(array_key_exists('lblMethod', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblMethod']); } else { ?>{$lblMethod|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
						<?php if(array_key_exists('ddmMethod', (array) $this->variables)) { echo $this->variables['ddmMethod']; } else { ?>{$ddmMethod}<?php } ?> <?php if(array_key_exists('ddmMethodError', (array) $this->variables)) { echo $this->variables['ddmMethodError']; } else { ?>{$ddmMethodError}<?php } ?>
					</p>
					<p id="emailWrapper" class="hidden">
						<label for="addValue-email"><?php if(array_key_exists('lblRecipient', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRecipient']); } else { ?>{$lblRecipient|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
						<?php if(array_key_exists('txtEmail', (array) $this->variables)) { echo $this->variables['txtEmail']; } else { ?>{$txtEmail}<?php } ?> <?php if(array_key_exists('txtEmailError', (array) $this->variables)) { echo $this->variables['txtEmailError']; } else { ?>{$txtEmailError}<?php } ?>
					</p>
				</div>
			</div>
			<div class="options">
				<div class="heading">
					<h3>
						<label for="successMessage"><?php if(array_key_exists('lblSuccessMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSuccessMessage']); } else { ?>{$lblSuccessMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
					</h3>
				</div>
				<div class="optionsRTE">
					<?php if(array_key_exists('txtSuccessMessage', (array) $this->variables)) { echo $this->variables['txtSuccessMessage']; } else { ?>{$txtSuccessMessage}<?php } ?> <?php if(array_key_exists('txtSuccessMessageError', (array) $this->variables)) { echo $this->variables['txtSuccessMessageError']; } else { ?>{$txtSuccessMessageError}<?php } ?>
				</div>
			</div>
		</div>

		<div id="tabFields">
			<div class="generalMessage infoMessage singleMessage content">
				<p class="lastChild"><?php if(array_key_exists('msgImportantImmediateUpdate', (array) $this->variables)) { echo $this->variables['msgImportantImmediateUpdate']; } else { ?>{$msgImportantImmediateUpdate}<?php } ?></p>
			</div>
			<div class="clearfix">
				<div id="leftColumn">
					<div class="box boxLevel2">
						<div class="heading">
							<h3><?php if(array_key_exists('lblPreview', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPreview']); } else { ?>{$lblPreview|ucfirst}<?php } ?></h3>
						</div>
						<div id="fieldsHolder" class="sequenceByDragAndDrop">
							<?php
					if(isset($this->variables['fields']) && count($this->variables['fields']) != 0 && $this->variables['fields'] != '' && $this->variables['fields'] !== false)
					{
						?>
								<?php
					if(!isset($this->variables['fields']))
					{
						?>{iteration:fields}<?php
						$this->variables['fields'] = array();
						$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['fail'] = true;
					}
				if(isset(${'fields'})) $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['old'] = ${'fields'};
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['iteration'] = $this->variables['fields'];
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['i'] = 1;
				$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['count'] = count($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['iteration']);
				foreach((array) $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['iteration'] as ${'fields'})
				{
					if(!isset(${'fields'}['first']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['i'] == 1) ${'fields'}['first'] = true;
					if(!isset(${'fields'}['last']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['i'] == $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['count']) ${'fields'}['last'] = true;
					if(isset(${'fields'}['formElements']) && is_array(${'fields'}['formElements']))
					{
						foreach(${'fields'}['formElements'] as $name => $object)
						{
							${'fields'}[$name] = $object->parse();
							${'fields'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
									<?php if(array_key_exists('field', (array) ${'fields'})) { echo ${'fields'}['field']; } else { ?>{$fields->field}<?php } ?>
								<?php
					$this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['i']++;
				}
					if(isset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['fail']) && $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['fail'] == true)
					{
						?>{/iteration:fields}<?php
					}
				if(isset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['old'])) ${'fields'} = $this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']['old'];
				else unset($this->iterations['748cc49691b53aa8e17367ac6c4e8165_Edit.tpl.php_2']);
				?>
							<?php } ?>

							
							<div id="noFields" class="options"<?php
					if(isset($this->variables['fields']) && count($this->variables['fields']) != 0 && $this->variables['fields'] != '' && $this->variables['fields'] !== false)
					{
						?> style="display: none;"<?php } ?>>
								<img src="/src/Backend/Modules/FormBuilder/Layout/images/placeholder_<?php if(array_key_exists('INTERFACE_LANGUAGE', (array) $this->variables)) { echo $this->variables['INTERFACE_LANGUAGE']; } else { ?>{$INTERFACE_LANGUAGE}<?php } ?>.png" alt="<?php if(array_key_exists('msgNoFields', (array) $this->variables)) { echo $this->variables['msgNoFields']; } else { ?>{$msgNoFields}<?php } ?>" />
							</div>

							
							<div class="options clearfix">
								<p class="floatLeft buttonHolder p0">
									<?php if(array_key_exists('btnSubmitField', (array) $this->variables)) { echo $this->variables['btnSubmitField']; } else { ?>{$btnSubmitField}<?php } ?>
								</p>
								<p class="floatRight buttonHolderRight p0">
									<a href="#edit-<?php if(array_key_exists('submitId', (array) $this->variables)) { echo $this->variables['submitId']; } else { ?>{$submitId}<?php } ?>" class="button iconOnly icon iconEdit editField floatRight" rel="<?php if(array_key_exists('submitId', (array) $this->variables)) { echo $this->variables['submitId']; } else { ?>{$submitId}<?php } ?>"><span><?php if(array_key_exists('lblEdit', (array) $this->variables)) { echo $this->variables['lblEdit']; } else { ?>{$lblEdit}<?php } ?></span></a>
								</p>
							</div>
						</div>
					</div>
				</div>
				<div id="rightColumn">
					<div class="box boxLevel2" id="formElements">
						<div class="heading">
							<h3><?php if(array_key_exists('lblAddFields', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddFields']); } else { ?>{$lblAddFields|ucfirst}<?php } ?></h3>
						</div>
						<div class="options">
							<h3><?php if(array_key_exists('lblFormElements', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFormElements']); } else { ?>{$lblFormElements|ucfirst}<?php } ?></h3>
							<ul>
								<li id="textboxSelector"><a href="#textbox" rel="textboxDialog" class="openFieldDialog"><?php if(array_key_exists('lblTextbox', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTextbox']); } else { ?>{$lblTextbox|ucfirst}<?php } ?></a></li>
								<li id="textareaSelector"><a href="#textarea" rel="textareaDialog" class="openFieldDialog"><?php if(array_key_exists('lblTextarea', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTextarea']); } else { ?>{$lblTextarea|ucfirst}<?php } ?></a></li>
								<li id="dropdownSelector"><a href="#dropdown" rel="dropdownDialog" class="openFieldDialog"><?php if(array_key_exists('lblDropdown', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDropdown']); } else { ?>{$lblDropdown|ucfirst}<?php } ?></a></li>
								<li id="checkboxSelector"><a href="#checkbox" rel="checkboxDialog" class="openFieldDialog"><?php if(array_key_exists('lblCheckbox', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCheckbox']); } else { ?>{$lblCheckbox|ucfirst}<?php } ?></a></li>
								<li id="radiobuttonSelector"><a href="#radiobutton" rel="radiobuttonDialog" class="openFieldDialog"><?php if(array_key_exists('lblRadiobutton', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRadiobutton']); } else { ?>{$lblRadiobutton|ucfirst}<?php } ?></a></li>
							</ul>
						</div>
						<div class="options">
							<h3><?php if(array_key_exists('lblTextElements', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTextElements']); } else { ?>{$lblTextElements|ucfirst}<?php } ?></h3>
							<ul>
								<li id="headingSelector"><a href="#heading" rel="headingDialog" class="openFieldDialog"><?php if(array_key_exists('lblHeading', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblHeading']); } else { ?>{$lblHeading|ucfirst}<?php } ?></a></li>
								<li id="paragraphSelector"><a href="#paragraph" rel="paragraphDialog" class="openFieldDialog"><?php if(array_key_exists('lblParagraph', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblParagraph']); } else { ?>{$lblParagraph|ucfirst}<?php } ?></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="tabExtra" class="box">
			<div class="horizontal">
				<div class="options">
					<p>
						<label for="identifier">
							<?php if(array_key_exists('lblIdentifier', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblIdentifier']); } else { ?>{$lblIdentifier|ucfirst}<?php } ?>
							<abbr class="help">(?)</abbr>
							<span class="tooltip" style="display: none;"><?php if(array_key_exists('msgHelpIdentifier', (array) $this->variables)) { echo $this->variables['msgHelpIdentifier']; } else { ?>{$msgHelpIdentifier}<?php } ?></span>
						</label>
						<?php if(array_key_exists('txtIdentifier', (array) $this->variables)) { echo $this->variables['txtIdentifier']; } else { ?>{$txtIdentifier}<?php } ?> <?php if(array_key_exists('txtIdentifierError', (array) $this->variables)) { echo $this->variables['txtIdentifierError']; } else { ?>{$txtIdentifierError}<?php } ?>
					</p>
				</div>
			</div>
		</div>
	</div>

	<div class="fullwidthOptions">
		<?php
					if(isset($this->variables['showFormBuilderDelete']) && count($this->variables['showFormBuilderDelete']) != 0 && $this->variables['showFormBuilderDelete'] != '' && $this->variables['showFormBuilderDelete'] !== false)
					{
						?>
		<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'delete'); } else { ?>{$var|geturl:'delete'}<?php } ?>&amp;id=<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
			<span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
		</a>
		<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
			<p><?php if(array_key_exists('msgConfirmDelete', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['msgConfirmDelete'], $this->variables['name']); } else { ?>{$msgConfirmDelete|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></p>
		</div>
		<?php } ?>

		<div class="buttonHolderRight">
			<input id="editButton" class="inputButton button mainButton" type="submit" name="edit" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
		</div>
	</div>

	
	<div id="textboxDialog" title="<?php if(array_key_exists('lblTextbox', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTextbox']); } else { ?>{$lblTextbox|ucfirst}<?php } ?>" class="dialog" style="display: none;">
		<input type="hidden" name="textbox_id" id="textboxId" value="" />

		<div class="tabs forkForms">
			<ul>
				<li><a href="#tabTextboxBasic"><?php if(array_key_exists('lblBasic', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBasic']); } else { ?>{$lblBasic|ucfirst}<?php } ?></a></li>
				<li><a href="#tabTextboxProperties"><?php if(array_key_exists('lblProperties', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblProperties']); } else { ?>{$lblProperties|ucfirst}<?php } ?></a></li>
			</ul>

			<div id="tabTextboxBasic" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="textboxLabel"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextboxLabel', (array) $this->variables)) { echo $this->variables['txtTextboxLabel']; } else { ?>{$txtTextboxLabel}<?php } ?>
							<span id="textboxLabelError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>
			<div id="tabTextboxProperties" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="textboxValue"><?php if(array_key_exists('lblDefaultValue', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefaultValue']); } else { ?>{$lblDefaultValue|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('txtTextboxValue', (array) $this->variables)) { echo $this->variables['txtTextboxValue']; } else { ?>{$txtTextboxValue}<?php } ?>
						</p>
					</div>
					<div class="options">
						<p class="p0">
							<label for="textboxReplyTo"><?php if(array_key_exists('lblReplyTo', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblReplyTo']); } else { ?>{$lblReplyTo|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkTextboxReplyTo', (array) $this->variables)) { echo $this->variables['chkTextboxReplyTo']; } else { ?>{$chkTextboxReplyTo}<?php } ?>
							<abbr class="help">(?)</abbr>
							<span class="tooltip" style="display: none;"><?php if(array_key_exists('msgHelpReplyTo', (array) $this->variables)) { echo $this->variables['msgHelpReplyTo']; } else { ?>{$msgHelpReplyTo}<?php } ?></span>
						</p>
					</div>
					<div class="validation options">
						<p class="p0">
							<label for="textboxRequired"><?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkTextboxRequired', (array) $this->variables)) { echo $this->variables['chkTextboxRequired']; } else { ?>{$chkTextboxRequired}<?php } ?>
						</p>
						<p class="validationRequiredErrorMessage hidden">
							<label for="textboxRequiredErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextboxRequiredErrorMessage', (array) $this->variables)) { echo $this->variables['txtTextboxRequiredErrorMessage']; } else { ?>{$txtTextboxRequiredErrorMessage}<?php } ?>
							<span id="textboxRequiredErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
					<div class="validation options">
						<p class="p0">
							<label for="textboxValidation"><?php if(array_key_exists('lblValidation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblValidation']); } else { ?>{$lblValidation|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('ddmTextboxValidation', (array) $this->variables)) { echo $this->variables['ddmTextboxValidation']; } else { ?>{$ddmTextboxValidation}<?php } ?>
						</p>
						<p class="validationParameter" style="display: none;">
							<label for="textboxValidationParameter"><?php if(array_key_exists('lblParameter', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblParameter']); } else { ?>{$lblParameter|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextboxValidationParameter', (array) $this->variables)) { echo $this->variables['txtTextboxValidationParameter']; } else { ?>{$txtTextboxValidationParameter}<?php } ?>
						</p>
						<p class="validationErrorMessage" style="display: none;">
							<label for="textboxErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextboxErrorMessage', (array) $this->variables)) { echo $this->variables['txtTextboxErrorMessage']; } else { ?>{$txtTextboxErrorMessage}<?php } ?>
							<span id="textboxErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>

			</div>
		</div>
	</div>

	
	<div id="textareaDialog" title="<?php if(array_key_exists('lblTextarea', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTextarea']); } else { ?>{$lblTextarea|ucfirst}<?php } ?>" class="dialog" style="display: none;">
		<input type="hidden" name="textarea_id" id="textareaId" value="" />

		<div class="tabs forkForms">
			<ul>
				<li><a href="#tabTextareaBasic"><?php if(array_key_exists('lblBasic', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBasic']); } else { ?>{$lblBasic|ucfirst}<?php } ?></a></li>
				<li><a href="#tabTextareaProperties"><?php if(array_key_exists('lblProperties', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblProperties']); } else { ?>{$lblProperties|ucfirst}<?php } ?></a></li>
			</ul>

			<div id="tabTextareaBasic" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="textareaLabel"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextareaLabel', (array) $this->variables)) { echo $this->variables['txtTextareaLabel']; } else { ?>{$txtTextareaLabel}<?php } ?>
							<span id="textareaLabelError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>

			<div id="tabTextareaProperties" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="textareaValue"><?php if(array_key_exists('lblDefaultValue', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefaultValue']); } else { ?>{$lblDefaultValue|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('txtTextareaValue', (array) $this->variables)) { echo $this->variables['txtTextareaValue']; } else { ?>{$txtTextareaValue}<?php } ?>
						</p>
					</div>
					<div class="validation options">
						<p class="p0">
							<label for="textareaRequired"><?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkTextareaRequired', (array) $this->variables)) { echo $this->variables['chkTextareaRequired']; } else { ?>{$chkTextareaRequired}<?php } ?>
						</p>
						<p class="validationRequiredErrorMessage hidden">
							<label for="textareaRequiredErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextareaRequiredErrorMessage', (array) $this->variables)) { echo $this->variables['txtTextareaRequiredErrorMessage']; } else { ?>{$txtTextareaRequiredErrorMessage}<?php } ?>
							<span id="textareaRequiredErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
					<div class="validation options" style="display: none;">
						<p class="p0">
							<label for="textareaValidation"><?php if(array_key_exists('lblValidation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblValidation']); } else { ?>{$lblValidation|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('ddmTextareaValidation', (array) $this->variables)) { echo $this->variables['ddmTextareaValidation']; } else { ?>{$ddmTextareaValidation}<?php } ?>
						</p>
						<p class="validationParameter" style="display: none;">
							<label for="textareaValidationParameter"><?php if(array_key_exists('lblParameter', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblParameter']); } else { ?>{$lblParameter|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextareaValidationParameter', (array) $this->variables)) { echo $this->variables['txtTextareaValidationParameter']; } else { ?>{$txtTextareaValidationParameter}<?php } ?>
						</p>
						<p class="validationErrorMessage" style="display: none;">
							<label for="textareaErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtTextareaErrorMessage', (array) $this->variables)) { echo $this->variables['txtTextareaErrorMessage']; } else { ?>{$txtTextareaErrorMessage}<?php } ?>
							<span id="textareaErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div id="dropdownDialog" title="<?php if(array_key_exists('lblDropdown', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDropdown']); } else { ?>{$lblDropdown|ucfirst}<?php } ?>" class="dialog" style="display: none;">
		<input type="hidden" name="dropdown_id" id="dropdownId" value="" />

		<div class="tabs forkForms">
			<ul>
				<li><a href="#tabDropdownBasic"><?php if(array_key_exists('lblBasic', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBasic']); } else { ?>{$lblBasic|ucfirst}<?php } ?></a></li>
				<li><a href="#tabDropdownProperties"><?php if(array_key_exists('lblProperties', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblProperties']); } else { ?>{$lblProperties|ucfirst}<?php } ?></a></li>
			</ul>

			<div id="tabDropdownBasic" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="dropdownLabel"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtDropdownLabel', (array) $this->variables)) { echo $this->variables['txtDropdownLabel']; } else { ?>{$txtDropdownLabel}<?php } ?>
							<span id="dropdownLabelError" class="formError" style="display: none;"></span>
						</p>
						<p>
							<label for="dropdownValues"><?php if(array_key_exists('lblValues', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblValues']); } else { ?>{$lblValues|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('txtDropdownValues', (array) $this->variables)) { echo $this->variables['txtDropdownValues']; } else { ?>{$txtDropdownValues}<?php } ?> <?php if(array_key_exists('txtDropdownValuesError', (array) $this->variables)) { echo $this->variables['txtDropdownValuesError']; } else { ?>{$txtDropdownValuesError}<?php } ?>
							<span id="dropdownValuesError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>

			<div id="tabDropdownProperties" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="dropdownDefaultValue"><?php if(array_key_exists('lblDefaultValue', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefaultValue']); } else { ?>{$lblDefaultValue|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('ddmDropdownDefaultValue', (array) $this->variables)) { echo $this->variables['ddmDropdownDefaultValue']; } else { ?>{$ddmDropdownDefaultValue}<?php } ?>
						</p>
					</div>
					<div class="options validation">
						<p class="p0">
							<label for="dropdownRequired"><?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkDropdownRequired', (array) $this->variables)) { echo $this->variables['chkDropdownRequired']; } else { ?>{$chkDropdownRequired}<?php } ?>
						</p>
						<p class="validationRequiredErrorMessage hidden">
							<label for="dropdownRequiredErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtDropdownRequiredErrorMessage', (array) $this->variables)) { echo $this->variables['txtDropdownRequiredErrorMessage']; } else { ?>{$txtDropdownRequiredErrorMessage}<?php } ?>
							<span id="dropdownRequiredErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div id="radiobuttonDialog" title="<?php if(array_key_exists('lblRadiobutton', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRadiobutton']); } else { ?>{$lblRadiobutton|ucfirst}<?php } ?>" class="dialog" style="display: none;">
		<input type="hidden" name="radiobutton_id" id="radiobuttonId" value="" />

		<div class="tabs forkForms">
			<ul>
				<li><a href="#tabRadiobuttonBasic"><?php if(array_key_exists('lblBasic', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBasic']); } else { ?>{$lblBasic|ucfirst}<?php } ?></a></li>
				<li><a href="#tabRadiobuttonProperties"><?php if(array_key_exists('lblProperties', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblProperties']); } else { ?>{$lblProperties|ucfirst}<?php } ?></a></li>
			</ul>

			<div id="tabRadiobuttonBasic" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="radiobuttonLabel"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtRadiobuttonLabel', (array) $this->variables)) { echo $this->variables['txtRadiobuttonLabel']; } else { ?>{$txtRadiobuttonLabel}<?php } ?>
							<span id="radiobuttonLabelError" class="formError" style="display: none;"></span>
						</p>
						<p>
							<label for="radiobuttonValues"><?php if(array_key_exists('lblValues', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblValues']); } else { ?>{$lblValues|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('txtRadiobuttonValues', (array) $this->variables)) { echo $this->variables['txtRadiobuttonValues']; } else { ?>{$txtRadiobuttonValues}<?php } ?> <?php if(array_key_exists('txtRadiobuttonValuesError', (array) $this->variables)) { echo $this->variables['txtRadiobuttonValuesError']; } else { ?>{$txtRadiobuttonValuesError}<?php } ?>
							<span id="radiobuttonValuesError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>

			<div id="tabRadiobuttonProperties" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="radiobuttonDefaultValue"><?php if(array_key_exists('lblDefaultValue', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefaultValue']); } else { ?>{$lblDefaultValue|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('ddmRadiobuttonDefaultValue', (array) $this->variables)) { echo $this->variables['ddmRadiobuttonDefaultValue']; } else { ?>{$ddmRadiobuttonDefaultValue}<?php } ?>
						</p>
					</div>
					<div class="options validation">
						<p class="p0">
							<label for="radiobuttonRequired"><?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkRadiobuttonRequired', (array) $this->variables)) { echo $this->variables['chkRadiobuttonRequired']; } else { ?>{$chkRadiobuttonRequired}<?php } ?>
						</p>
						<p class="validationRequiredErrorMessage hidden">
							<label for="radiobuttonRequiredErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtRadiobuttonRequiredErrorMessage', (array) $this->variables)) { echo $this->variables['txtRadiobuttonRequiredErrorMessage']; } else { ?>{$txtRadiobuttonRequiredErrorMessage}<?php } ?>
							<span id="radiobuttonRequiredErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div id="checkboxDialog" title="<?php if(array_key_exists('lblCheckbox', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCheckbox']); } else { ?>{$lblCheckbox|ucfirst}<?php } ?>" class="dialog" style="display: none;">
		<input type="hidden" name="checkbox_id" id="checkboxId" value="" />

		<div class="tabs forkForms">
			<ul>
				<li><a href="#tabCheckboxBasic"><?php if(array_key_exists('lblBasic', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBasic']); } else { ?>{$lblBasic|ucfirst}<?php } ?></a></li>
				<li><a href="#tabCheckboxProperties"><?php if(array_key_exists('lblProperties', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblProperties']); } else { ?>{$lblProperties|ucfirst}<?php } ?></a></li>
			</ul>

			<div id="tabCheckboxBasic" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="checkboxLabel"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtCheckboxLabel', (array) $this->variables)) { echo $this->variables['txtCheckboxLabel']; } else { ?>{$txtCheckboxLabel}<?php } ?>
							<span id="checkboxLabelError" class="formError" style="display: none;"></span>
						</p>
						<p>
							<label for="checkboxValues"><?php if(array_key_exists('lblValues', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblValues']); } else { ?>{$lblValues|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('txtCheckboxValues', (array) $this->variables)) { echo $this->variables['txtCheckboxValues']; } else { ?>{$txtCheckboxValues}<?php } ?> <?php if(array_key_exists('txtCheckboxValuesError', (array) $this->variables)) { echo $this->variables['txtCheckboxValuesError']; } else { ?>{$txtCheckboxValuesError}<?php } ?>
						</p>
					</div>
				</div>
			</div>

			<div id="tabCheckboxProperties" class="box">
				<div class="horizontal">
					<div class="options">
						<p>
							<label for="checkboxDefaultValue"><?php if(array_key_exists('lblDefaultValue', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefaultValue']); } else { ?>{$lblDefaultValue|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('ddmCheckboxDefaultValue', (array) $this->variables)) { echo $this->variables['ddmCheckboxDefaultValue']; } else { ?>{$ddmCheckboxDefaultValue}<?php } ?>
						</p>
					</div>
					<div class="options validation">
						<p class="p0">
							<label for="checkboxRequired"><?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?></label>
							<?php if(array_key_exists('chkCheckboxRequired', (array) $this->variables)) { echo $this->variables['chkCheckboxRequired']; } else { ?>{$chkCheckboxRequired}<?php } ?>
						</p>
						<p class="validationRequiredErrorMessage hidden">
							<label for="checkboxRequiredErrorMessage"><?php if(array_key_exists('lblErrorMessage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblErrorMessage']); } else { ?>{$lblErrorMessage|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
							<?php if(array_key_exists('txtCheckboxRequiredErrorMessage', (array) $this->variables)) { echo $this->variables['txtCheckboxRequiredErrorMessage']; } else { ?>{$txtCheckboxRequiredErrorMessage}<?php } ?>
							<span id="checkboxRequiredErrorMessageError" class="formError" style="display: none;"></span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div id="submitDialog" title="<?php if(array_key_exists('lblSubmitButton', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSubmitButton']); } else { ?>{$lblSubmitButton|ucfirst}<?php } ?>" class="dialog box forkForms" style="display: none;">
		<div class="horizontal">
			<div class="options">
				<input type="hidden" name="submit_id" id="submitId" value="" />
				<p>
					<label for="submit"><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
					<?php if(array_key_exists('txtSubmit', (array) $this->variables)) { echo $this->variables['txtSubmit']; } else { ?>{$txtSubmit}<?php } ?>
				</p>
				<div class="validation">
					<span id="submitError" class="formError" style="display: none;"></span>
				</div>
			</div>
		</div>
	</div>

	
	<div id="headingDialog" title="<?php if(array_key_exists('lblHeading', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblHeading']); } else { ?>{$lblHeading|ucfirst}<?php } ?>" class="dialog box forkForms" style="display: none;">
		<div class="horizontal">
			<div class="options">
				<input type="hidden" name="heading_id" id="headingId" value="" />
				<p>
					<label for="heading"><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
					<?php if(array_key_exists('txtHeading', (array) $this->variables)) { echo $this->variables['txtHeading']; } else { ?>{$txtHeading}<?php } ?>
					<span id="headingError" class="formError" style="display: none;"></span>
				</p>
			</div>
		</div>
	</div>

	
	<div id="paragraphDialog" title="<?php if(array_key_exists('lblParagraph', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblParagraph']); } else { ?>{$lblParagraph|ucfirst}<?php } ?>" class="dialog box boxLevel2 forkForms" style="display: none;">
		<input type="hidden" name="paragraph_id" id="paragraphId" value="" />
		<div class="heading">
			<h3><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?></h3>
		</div>
		<p>
			<?php if(array_key_exists('txtParagraph', (array) $this->variables)) { echo $this->variables['txtParagraph']; } else { ?>{$txtParagraph}<?php } ?>
			<span id="paragraphError" class="formError" style="display: none;"></span>
		</p>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
