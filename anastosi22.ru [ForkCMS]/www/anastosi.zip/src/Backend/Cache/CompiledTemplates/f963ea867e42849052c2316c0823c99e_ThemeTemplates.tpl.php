<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<?php
					if(isset($this->forms['themes']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['themes']->getAction(); ?>" method="<?php echo $this->forms['themes']->getMethod(); ?>"<?php echo $this->forms['themes']->getParametersHTML(); ?>>
						<?php echo $this->forms['themes']->getField('form')->parse();
						if($this->forms['themes']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['themes']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['themes']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="pageTitle">
		<h2>
			<?php if(array_key_exists('lblExtensions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExtensions']); } else { ?>{$lblExtensions|ucfirst}<?php } ?>: <label for="theme"><?php if(array_key_exists('lblTemplates', (array) $this->variables)) { echo $this->variables['lblTemplates']; } else { ?>{$lblTemplates}<?php } ?> <?php if(array_key_exists('lblFor', (array) $this->variables)) { echo $this->variables['lblFor']; } else { ?>{$lblFor}<?php } ?></label> <?php if(array_key_exists('ddmTheme', (array) $this->variables)) { echo $this->variables['ddmTheme']; } else { ?>{$ddmTheme}<?php } ?>
		</h2>

		<?php
					if(isset($this->variables['showExtensionsAddThemeTemplate']) && count($this->variables['showExtensionsAddThemeTemplate']) != 0 && $this->variables['showExtensionsAddThemeTemplate'] != '' && $this->variables['showExtensionsAddThemeTemplate'] !== false)
					{
						?>
		<div class="buttonHolderRight">
			<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'export_theme_templates'); } else { ?>{$var|geturl:'export_theme_templates'}<?php } ?><?php
					if(isset($this->variables['selectedTheme']) && count($this->variables['selectedTheme']) != 0 && $this->variables['selectedTheme'] != '' && $this->variables['selectedTheme'] !== false)
					{
						?>&amp;theme=<?php if(array_key_exists('selectedTheme', (array) $this->variables)) { echo $this->variables['selectedTheme']; } else { ?>{$selectedTheme}<?php } ?><?php } ?>" class="button icon iconExport" title="<?php if(array_key_exists('lblExport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExport']); } else { ?>{$lblExport|ucfirst}<?php } ?>">
				<span><?php if(array_key_exists('lblExport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExport']); } else { ?>{$lblExport|ucfirst}<?php } ?></span>
			</a>
			<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'add_theme_template'); } else { ?>{$var|geturl:'add_theme_template'}<?php } ?><?php
					if(isset($this->variables['selectedTheme']) && count($this->variables['selectedTheme']) != 0 && $this->variables['selectedTheme'] != '' && $this->variables['selectedTheme'] !== false)
					{
						?>&amp;theme=<?php if(array_key_exists('selectedTheme', (array) $this->variables)) { echo $this->variables['selectedTheme']; } else { ?>{$selectedTheme}<?php } ?><?php } ?>" class="button icon iconAdd" title="<?php if(array_key_exists('lblAddTemplate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddTemplate']); } else { ?>{$lblAddTemplate|ucfirst}<?php } ?>">
				<span><?php if(array_key_exists('lblAddTemplate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddTemplate']); } else { ?>{$lblAddTemplate|ucfirst}<?php } ?></span>
			</a>
		</div>
		<?php } ?>
	</div>

	<div class="dataGridHolder">
		<?php
					if(isset($this->variables['dataGrid']) && count($this->variables['dataGrid']) != 0 && $this->variables['dataGrid'] != '' && $this->variables['dataGrid'] !== false)
					{
						?><?php if(array_key_exists('dataGrid', (array) $this->variables)) { echo $this->variables['dataGrid']; } else { ?>{$dataGrid}<?php } ?><?php } ?>
		<?php if(!isset($this->variables['dataGrid']) || count($this->variables['dataGrid']) == 0 || $this->variables['dataGrid'] == '' || $this->variables['dataGrid'] === false): ?><p><?php if(array_key_exists('msgNoItems', (array) $this->variables)) { echo $this->variables['msgNoItems']; } else { ?>{$msgNoItems}<?php } ?></p><?php endif; ?>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
