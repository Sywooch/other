<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
    <h2><?php if(array_key_exists('lblGallery', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblGallery']); } else { ?>{$lblGallery|ucfirst}<?php } ?>: <?php if(array_key_exists('lblAdd', (array) $this->variables)) { echo $this->variables['lblAdd']; } else { ?>{$lblAdd}<?php } ?></h2>
</div>

<?php
					if(isset($this->forms['add']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['add']->getAction(); ?>" method="<?php echo $this->forms['add']->getMethod(); ?>"<?php echo $this->forms['add']->getParametersHTML(); ?>>
						<?php echo $this->forms['add']->getField('form')->parse();
						if($this->forms['add']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['add']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['add']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
    <?php
					if(isset($this->variables['categories']) && count($this->variables['categories']) != 0 && $this->variables['categories'] != '' && $this->variables['categories'] !== false)
					{
						?>
        <p>
            <?php if(array_key_exists('lblTitle', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTitle']); } else { ?>{$lblTitle|ucfirst}<?php } ?><br/>
            <?php if(array_key_exists('txtTitle', (array) $this->variables)) { echo $this->variables['txtTitle']; } else { ?>{$txtTitle}<?php } ?> <?php if(array_key_exists('txtTitleError', (array) $this->variables)) { echo $this->variables['txtTitleError']; } else { ?>{$txtTitleError}<?php } ?>
        </p>

    <div id="pageUrl">
        <div class="oneLiner">
            <?php
					if(isset($this->variables['detailURL']) && count($this->variables['detailURL']) != 0 && $this->variables['detailURL'] != '' && $this->variables['detailURL'] !== false)
					{
						?><p><span><a href="<?php if(array_key_exists('detailURL', (array) $this->variables)) { echo $this->variables['detailURL']; } else { ?>{$detailURL}<?php } ?>"><?php if(array_key_exists('detailURL', (array) $this->variables)) { echo $this->variables['detailURL']; } else { ?>{$detailURL}<?php } ?>/<span id="generatedUrl"></span></a></span></p><?php } ?>
            <?php if(!isset($this->variables['detailURL']) || count($this->variables['detailURL']) == 0 || $this->variables['detailURL'] == '' || $this->variables['detailURL'] === false): ?><p class="infoMessage"><?php if(array_key_exists('errNoModuleLinked', (array) $this->variables)) { echo $this->variables['errNoModuleLinked']; } else { ?>{$errNoModuleLinked}<?php } ?></p><?php endif; ?>
        </div>
    </div>

    <div class="tabs">
        <ul>
            <li><a href="#tabContent"><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?></a></li>
            <li><a href="#tabSEO"><?php if(array_key_exists('lblSEO', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSEO']); } else { ?>{$lblSEO|ucfirst}<?php } ?></a></li>
        </ul>

        <div class="ui-tabs">
            <div class="ui-tabs-panel">

                <div id="tabContent">
                <div class="options">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                        <tr>
                            <td id="leftColumn">
                                <div class="box">
                                    <div class="heading">
                                        <h3><?php if(array_key_exists('lblDescription', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDescription']); } else { ?>{$lblDescription|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>"></abbr></h3>
                                    </div>
                                    <div class="optionsRTE">
                                        <?php if(array_key_exists('txtDescription', (array) $this->variables)) { echo $this->variables['txtDescription']; } else { ?>{$txtDescription}<?php } ?> <?php if(array_key_exists('txtDescriptionError', (array) $this->variables)) { echo $this->variables['txtDescriptionError']; } else { ?>{$txtDescriptionError}<?php } ?>
                                    </div>
                                </div>
                                <p>
                                <?php
					if(isset($this->variables['item']['filename']) && count($this->variables['item']['filename']) != 0 && $this->variables['item']['filename'] != '' && $this->variables['item']['filename'] !== false)
					{
						?>
                                <p>
                                    <img src="<?php if(array_key_exists('FRONTEND_FILES_URL', (array) $this->variables)) { echo $this->variables['FRONTEND_FILES_URL']; } else { ?>{$FRONTEND_FILES_URL}<?php } ?>/userfiles/images/slideshow/thumbnails/<?php if(isset($this->variables['item']) && array_key_exists('filename', (array) $this->variables['item'])) { echo $this->variables['item']['filename']; } else { ?>{$item.filename}<?php } ?>" width="200" alt="" />
                                </p>
                                <p>
                                    <label for="deleteImage"><?php if(array_key_exists('chkDeleteImage', (array) $this->variables)) { echo $this->variables['chkDeleteImage']; } else { ?>{$chkDeleteImage}<?php } ?> <?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></label>
                                    <?php if(array_key_exists('chkDeleteImageError', (array) $this->variables)) { echo $this->variables['chkDeleteImageError']; } else { ?>{$chkDeleteImageError}<?php } ?>
                                </p>
                                <?php } ?>
                                <label for="filename"><?php if(array_key_exists('lblImage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblImage']); } else { ?>{$lblImage|ucfirst}<?php } ?></label>
                                <?php if(array_key_exists('fileFilename', (array) $this->variables)) { echo $this->variables['fileFilename']; } else { ?>{$fileFilename}<?php } ?> <?php if(array_key_exists('fileFilenameError', (array) $this->variables)) { echo $this->variables['fileFilenameError']; } else { ?>{$fileFilenameError}<?php } ?>
                                </p>
                            </td>

                            <td id="sidebar">

                                <div id="slideshowCategory" class="box">
                                    <div class="heading">
                                        <h3><?php if(array_key_exists('lblCategory', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCategory']); } else { ?>{$lblCategory|ucfirst}<?php } ?></h3>
                                    </div>

                                    <div class="options">
                                        <p>
                                            <?php if(array_key_exists('ddmCategories', (array) $this->variables)) { echo $this->variables['ddmCategories']; } else { ?>{$ddmCategories}<?php } ?> <?php if(array_key_exists('ddmCategoriesError', (array) $this->variables)) { echo $this->variables['ddmCategoriesError']; } else { ?>{$ddmCategoriesError}<?php } ?>
                                        </p>
                                    </div>
                                </div>

<div id="publishOptions" class="box">
                            <div class="heading">
                                <h3><?php if(array_key_exists('lblStatus', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblStatus']); } else { ?>{$lblStatus|ucfirst}<?php } ?></h3>
                            </div>

                            <div class="options">
                                <ul class="inputList">
                                    <?php
					if(!isset($this->variables['hidden']))
					{
						?>{iteration:hidden}<?php
						$this->variables['hidden'] = array();
						$this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['fail'] = true;
					}
				if(isset(${'hidden'})) $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['old'] = ${'hidden'};
				$this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['iteration'] = $this->variables['hidden'];
				$this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['i'] = 1;
				$this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['count'] = count($this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['iteration'] as ${'hidden'})
				{
					if(!isset(${'hidden'}['first']) && $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['i'] == 1) ${'hidden'}['first'] = true;
					if(!isset(${'hidden'}['last']) && $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['i'] == $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['count']) ${'hidden'}['last'] = true;
					if(isset(${'hidden'}['formElements']) && is_array(${'hidden'}['formElements']))
					{
						foreach(${'hidden'}['formElements'] as $name => $object)
						{
							${'hidden'}[$name] = $object->parse();
							${'hidden'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
                                    <li>
                                        <?php if(array_key_exists('rbtHidden', (array) ${'hidden'})) { echo ${'hidden'}['rbtHidden']; } else { ?>{$hidden->rbtHidden}<?php } ?>
                                        <label for="<?php if(array_key_exists('id', (array) ${'hidden'})) { echo ${'hidden'}['id']; } else { ?>{$hidden->id}<?php } ?>"><?php if(array_key_exists('label', (array) ${'hidden'})) { echo ${'hidden'}['label']; } else { ?>{$hidden->label}<?php } ?></label>
                                    </li>
                                    <?php
					$this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['fail']) && $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:hidden}<?php
					}
				if(isset($this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['old'])) ${'hidden'} = $this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']['old'];
				else unset($this->iterations['972fc772ec4cf411f370f9b34b788e20_Add.tpl.php_1']);
				?>
                                </ul>
                            </div>

                            <div class="options">
                                <p class="p0"><label for="publishOnDate"><?php if(array_key_exists('lblPublishOn', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPublishOn']); } else { ?>{$lblPublishOn|ucfirst}<?php } ?></label></p>
                                <div class="oneLiner">
                                    <p>
                                        <?php if(array_key_exists('txtPublishOnDate', (array) $this->variables)) { echo $this->variables['txtPublishOnDate']; } else { ?>{$txtPublishOnDate}<?php } ?> <?php if(array_key_exists('txtPublishOnDateError', (array) $this->variables)) { echo $this->variables['txtPublishOnDateError']; } else { ?>{$txtPublishOnDateError}<?php } ?>
                                    </p>
                                    <p>
                                        <label for="publishOnTime"><?php if(array_key_exists('lblAt', (array) $this->variables)) { echo $this->variables['lblAt']; } else { ?>{$lblAt}<?php } ?></label>
                                    </p>
                                    <p>
                                        <?php if(array_key_exists('txtPublishOnTime', (array) $this->variables)) { echo $this->variables['txtPublishOnTime']; } else { ?>{$txtPublishOnTime}<?php } ?> <?php if(array_key_exists('txtPublishOnTimeError', (array) $this->variables)) { echo $this->variables['txtPublishOnTimeError']; } else { ?>{$txtPublishOnTimeError}<?php } ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                                <div id="publishOptions" class="box">
                                    <div class="heading">
                                        <h3><?php if(array_key_exists('lblDimensions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDimensions']); } else { ?>{$lblDimensions|ucfirst}<?php } ?></h3>
                                    </div>
                                    <div class="options">
                                        <?php if(array_key_exists('lblWidth', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblWidth']); } else { ?>{$lblWidth|ucfirst}<?php } ?>
                                        <p>
                                        <?php if(array_key_exists('txtWidth', (array) $this->variables)) { echo $this->variables['txtWidth']; } else { ?>{$txtWidth}<?php } ?> <?php if(array_key_exists('txtWidthError', (array) $this->variables)) { echo $this->variables['txtWidthError']; } else { ?>{$txtWidthError}<?php } ?>
                                        </p>
                                        <?php if(array_key_exists('lblHeight', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblHeight']); } else { ?>{$lblHeight|ucfirst}<?php } ?>
                                        <p>
                                        <?php if(array_key_exists('txtHeight', (array) $this->variables)) { echo $this->variables['txtHeight']; } else { ?>{$txtHeight}<?php } ?> <?php if(array_key_exists('txtHeightError', (array) $this->variables)) { echo $this->variables['txtHeightError']; } else { ?>{$txtHeightError}<?php } ?>
                                        </p>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            </div>

        <div id="tabSEO">
            <?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/seo.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/seo.tpl}<?php
				}
?>
        </div>

        </div>
        <div class="fullwidthOptions">
            <div class="buttonHolderRight">
                <input id="addButton" class="inputButton button mainButton" type="submit" name="add" value="<?php if(array_key_exists('lblPublish', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPublish']); } else { ?>{$lblPublish|ucfirst}<?php } ?>" />
            </div>
        </div>
    <?php } ?>

</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Slideshow\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
