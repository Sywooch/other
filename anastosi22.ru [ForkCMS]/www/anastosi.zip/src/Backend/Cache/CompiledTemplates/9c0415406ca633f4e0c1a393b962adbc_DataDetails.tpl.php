<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblFormBuilder', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFormBuilder']); } else { ?>{$lblFormBuilder|ucfirst}<?php } ?>: <?php if(array_key_exists('lblFormData', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['lblFormData'], $this->variables['name']); } else { ?>{$lblFormData|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></h2>

	<?php
					if(isset($this->variables['showFormBuilderData']) && count($this->variables['showFormBuilderData']) != 0 && $this->variables['showFormBuilderData'] != '' && $this->variables['showFormBuilderData'] !== false)
					{
						?>
	<div class="buttonHolderRight">
		<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'data'); } else { ?>{$var|geturl:'data'}<?php } ?>&amp;id=<?php if(array_key_exists('formId', (array) $this->variables)) { echo $this->variables['formId']; } else { ?>{$formId}<?php } ?>&amp;start_date=<?php if(isset($this->variables['filter']) && array_key_exists('start_date', (array) $this->variables['filter'])) { echo $this->variables['filter']['start_date']; } else { ?>{$filter.start_date}<?php } ?>&amp;end_date=<?php if(isset($this->variables['filter']) && array_key_exists('end_date', (array) $this->variables['filter'])) { echo $this->variables['filter']['end_date']; } else { ?>{$filter.end_date}<?php } ?>" class="button icon iconBack"><span><?php if(array_key_exists('lblBackToData', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBackToData']); } else { ?>{$lblBackToData|ucfirst}<?php } ?></span></a>
	</div>
	<?php } ?>
</div>

<div class="box">
	<div class="heading">
		<h3><?php if(array_key_exists('lblSenderInformation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSenderInformation']); } else { ?>{$lblSenderInformation|ucfirst}<?php } ?></h3>
	</div>
	<div class="options">
		<p><strong><?php if(array_key_exists('lblSentOn', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSentOn']); } else { ?>{$lblSentOn|ucfirst}<?php } ?>:</strong> <?php if(array_key_exists('sentOn', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::formatDateTime($this->variables['sentOn']); } else { ?>{$sentOn|formatdatetime}<?php } ?></p>
	</div>
</div>

<div class="box">
	<div class="heading">
		<h3><?php if(array_key_exists('lblContent', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblContent']); } else { ?>{$lblContent|ucfirst}<?php } ?></h3>
	</div>
	<div class="options">
		<?php
					if(isset($this->variables['data']) && count($this->variables['data']) != 0 && $this->variables['data'] != '' && $this->variables['data'] !== false)
					{
						?>
			<?php
					if(!isset($this->variables['data']))
					{
						?>{iteration:data}<?php
						$this->variables['data'] = array();
						$this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['fail'] = true;
					}
				if(isset(${'data'})) $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['old'] = ${'data'};
				$this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['iteration'] = $this->variables['data'];
				$this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['i'] = 1;
				$this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['count'] = count($this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['iteration'] as ${'data'})
				{
					if(!isset(${'data'}['first']) && $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['i'] == 1) ${'data'}['first'] = true;
					if(!isset(${'data'}['last']) && $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['i'] == $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['count']) ${'data'}['last'] = true;
					if(isset(${'data'}['formElements']) && is_array(${'data'}['formElements']))
					{
						foreach(${'data'}['formElements'] as $name => $object)
						{
							${'data'}[$name] = $object->parse();
							${'data'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
				<p><strong><?php if(array_key_exists('label', (array) ${'data'})) { echo ${'data'}['label']; } else { ?>{$data->label}<?php } ?>:</strong> <?php if(array_key_exists('value', (array) ${'data'})) { echo ${'data'}['value']; } else { ?>{$data->value}<?php } ?></p>
			<?php
					$this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['fail']) && $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:data}<?php
					}
				if(isset($this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['old'])) ${'data'} = $this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']['old'];
				else unset($this->iterations['9c0415406ca633f4e0c1a393b962adbc_DataDetails.tpl.php_1']);
				?>
		<?php } ?>
	</div>
</div>

<?php
					if(isset($this->variables['showFormBuilderMassDataAction']) && count($this->variables['showFormBuilderMassDataAction']) != 0 && $this->variables['showFormBuilderMassDataAction'] != '' && $this->variables['showFormBuilderMassDataAction'] !== false)
					{
						?>
<div class="fullwidthOptions">
	<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'mass_data_action'); } else { ?>{$var|geturl:'mass_data_action'}<?php } ?>&amp;action=delete&amp;form_id=<?php if(array_key_exists('formId', (array) $this->variables)) { echo $this->variables['formId']; } else { ?>{$formId}<?php } ?>&amp;id=<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
		<span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
	</a>
</div>
<?php } ?>

<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
	<p><?php if(array_key_exists('msgConfirmDeleteData', (array) $this->variables)) { echo $this->variables['msgConfirmDeleteData']; } else { ?>{$msgConfirmDeleteData}<?php } ?></p>
</div>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
