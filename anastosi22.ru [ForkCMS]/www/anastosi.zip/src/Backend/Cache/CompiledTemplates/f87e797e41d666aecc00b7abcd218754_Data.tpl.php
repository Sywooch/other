<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblFormBuilder', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFormBuilder']); } else { ?>{$lblFormBuilder|ucfirst}<?php } ?>: <?php if(array_key_exists('lblFormData', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['lblFormData'], $this->variables['name']); } else { ?>{$lblFormData|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></h2>

	<div class="buttonHolderRight">
		<?php
					if(isset($this->variables['showFormBuilderIndex']) && count($this->variables['showFormBuilderIndex']) != 0 && $this->variables['showFormBuilderIndex'] != '' && $this->variables['showFormBuilderIndex'] !== false)
					{
						?><a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'index'); } else { ?>{$var|geturl:'index'}<?php } ?>" class="button icon iconBack"><span><?php if(array_key_exists('lblOverview', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblOverview']); } else { ?>{$lblOverview|ucfirst}<?php } ?></span></a><?php } ?>
		<?php
					if(isset($this->variables['showFormBuilderExportData']) && count($this->variables['showFormBuilderExportData']) != 0 && $this->variables['showFormBuilderExportData'] != '' && $this->variables['showFormBuilderExportData'] !== false)
					{
						?><a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'export_data'); } else { ?>{$var|geturl:'export_data'}<?php } ?>&id=<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>&amp;start_date=<?php if(array_key_exists('start_date', (array) $this->variables)) { echo $this->variables['start_date']; } else { ?>{$start_date}<?php } ?>&amp;end_date=<?php if(array_key_exists('end_date', (array) $this->variables)) { echo $this->variables['end_date']; } else { ?>{$end_date}<?php } ?>" class="button icon iconExport"><span><?php if(array_key_exists('lblExport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExport']); } else { ?>{$lblExport|ucfirst}<?php } ?></span></a><?php } ?>
	</div>
</div>

<div class="dataGridHolder">
	<?php
					if(isset($this->forms['filter']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['filter']->getAction(); ?>" method="<?php echo $this->forms['filter']->getMethod(); ?>"<?php echo $this->forms['filter']->getParametersHTML(); ?>>
						<?php echo $this->forms['filter']->getField('form')->parse();
						if($this->forms['filter']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['filter']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['filter']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
		<div class="dataFilter">

			<input type="hidden" name="id" value="<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" />

			<table>
				<tbody>
					<tr>
						<td>
							<div class="options">
								<p>
									<label for="startDate"><?php if(array_key_exists('lblStartDate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblStartDate']); } else { ?>{$lblStartDate|ucfirst}<?php } ?></label>
									<?php if(array_key_exists('txtStartDate', (array) $this->variables)) { echo $this->variables['txtStartDate']; } else { ?>{$txtStartDate}<?php } ?> <?php if(array_key_exists('txtStartDateError', (array) $this->variables)) { echo $this->variables['txtStartDateError']; } else { ?>{$txtStartDateError}<?php } ?>
								</p>
							</div>
						</td>
						<td>
							<div class="options">
								<p>
									<label for="endDate"><?php if(array_key_exists('lblEndDate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblEndDate']); } else { ?>{$lblEndDate|ucfirst}<?php } ?></label>
									<?php if(array_key_exists('txtEndDate', (array) $this->variables)) { echo $this->variables['txtEndDate']; } else { ?>{$txtEndDate}<?php } ?> <?php if(array_key_exists('txtEndDateError', (array) $this->variables)) { echo $this->variables['txtEndDateError']; } else { ?>{$txtEndDateError}<?php } ?>
								</p>
							</div>
						</td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="2">
							<div class="options">
								<div class="buttonHolder">
									<input id="search" class="inputButton button mainButton" type="submit" name="search" value="<?php if(array_key_exists('lblUpdateFilter', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblUpdateFilter']); } else { ?>{$lblUpdateFilter|ucfirst}<?php } ?>" />
								</div>
							</div>
						</td>
					</tr>
				</tfoot>
			</table>
		</div>
	</form>
				<?php } ?>

	<?php
					if(isset($this->variables['dataGrid']) && count($this->variables['dataGrid']) != 0 && $this->variables['dataGrid'] != '' && $this->variables['dataGrid'] !== false)
					{
						?>
		<form action="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'mass_data_action'); } else { ?>{$var|geturl:'mass_data_action'}<?php } ?>" method="get" class="forkForms">
			<div class="dataGridHolder">
				<input type="hidden" name="form_id" value="<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" />
				<?php if(array_key_exists('dataGrid', (array) $this->variables)) { echo $this->variables['dataGrid']; } else { ?>{$dataGrid}<?php } ?>
			</div>
		</form>
	<?php } ?>
	<?php if(!isset($this->variables['dataGrid']) || count($this->variables['dataGrid']) == 0 || $this->variables['dataGrid'] == '' || $this->variables['dataGrid'] === false): ?><p><?php if(array_key_exists('msgNoData', (array) $this->variables)) { echo $this->variables['msgNoData']; } else { ?>{$msgNoData}<?php } ?></p><?php endif; ?>
</div>

<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
	<p><?php if(array_key_exists('msgConfirmMassDelete', (array) $this->variables)) { echo $this->variables['msgConfirmMassDelete']; } else { ?>{$msgConfirmMassDelete}<?php } ?></p>
</div>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\FormBuilder\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
