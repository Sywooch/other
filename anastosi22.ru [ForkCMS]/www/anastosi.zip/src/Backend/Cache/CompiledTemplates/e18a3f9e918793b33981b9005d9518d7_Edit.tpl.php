<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblLocation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLocation']); } else { ?>{$lblLocation|ucfirst}<?php } ?>: <?php if(array_key_exists('lblEdit', (array) $this->variables)) { echo $this->variables['lblEdit']; } else { ?>{$lblEdit}<?php } ?></h2>
</div>

<?php
					if(isset($this->forms['edit']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['edit']->getAction(); ?>" method="<?php echo $this->forms['edit']->getMethod(); ?>"<?php echo $this->forms['edit']->getParametersHTML(); ?>>
						<?php echo $this->forms['edit']->getField('form')->parse();
						if($this->forms['edit']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['edit']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['edit']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<p>
		<label for="title"><?php if(array_key_exists('lblTitle', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTitle']); } else { ?>{$lblTitle|ucfirst}<?php } ?></label>
		<?php if(array_key_exists('txtTitle', (array) $this->variables)) { echo $this->variables['txtTitle']; } else { ?>{$txtTitle}<?php } ?> <?php if(array_key_exists('txtTitleError', (array) $this->variables)) { echo $this->variables['txtTitleError']; } else { ?>{$txtTitleError}<?php } ?>
	</p>

	<div class="box horizontal">
		<div class="heading">
			<h3><?php if(array_key_exists('lblAddress', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddress']); } else { ?>{$lblAddress|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<p>
				<label for="street"><?php if(array_key_exists('lblStreet', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblStreet']); } else { ?>{$lblStreet|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtStreet', (array) $this->variables)) { echo $this->variables['txtStreet']; } else { ?>{$txtStreet}<?php } ?> <?php if(array_key_exists('txtStreetError', (array) $this->variables)) { echo $this->variables['txtStreetError']; } else { ?>{$txtStreetError}<?php } ?>
			</p>
			<p>
				<label for="number"><?php if(array_key_exists('lblNumber', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblNumber']); } else { ?>{$lblNumber|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtNumber', (array) $this->variables)) { echo $this->variables['txtNumber']; } else { ?>{$txtNumber}<?php } ?> <?php if(array_key_exists('txtNumberError', (array) $this->variables)) { echo $this->variables['txtNumberError']; } else { ?>{$txtNumberError}<?php } ?>
			</p>
			<p>
				<label for="zip"><?php if(array_key_exists('lblZip', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblZip']); } else { ?>{$lblZip|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtZip', (array) $this->variables)) { echo $this->variables['txtZip']; } else { ?>{$txtZip}<?php } ?> <?php if(array_key_exists('txtZipError', (array) $this->variables)) { echo $this->variables['txtZipError']; } else { ?>{$txtZipError}<?php } ?>
			</p>
			<p>
				<label for="city"><?php if(array_key_exists('lblCity', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCity']); } else { ?>{$lblCity|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtCity', (array) $this->variables)) { echo $this->variables['txtCity']; } else { ?>{$txtCity}<?php } ?> <?php if(array_key_exists('txtCityError', (array) $this->variables)) { echo $this->variables['txtCityError']; } else { ?>{$txtCityError}<?php } ?>
			</p>
			<p>
				<label for="country"><?php if(array_key_exists('lblCountry', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCountry']); } else { ?>{$lblCountry|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('ddmCountry', (array) $this->variables)) { echo $this->variables['ddmCountry']; } else { ?>{$ddmCountry}<?php } ?> <?php if(array_key_exists('ddmCountryError', (array) $this->variables)) { echo $this->variables['ddmCountryError']; } else { ?>{$ddmCountryError}<?php } ?>
			</p>
			<?php if(array_key_exists('hidMapId', (array) $this->variables)) { echo $this->variables['hidMapId']; } else { ?>{$hidMapId}<?php } ?> <?php if(array_key_exists('hidRedirect', (array) $this->variables)) { echo $this->variables['hidRedirect']; } else { ?>{$hidRedirect}<?php } ?>

		<div class="buttonHolderRight">
			<input id="editButton" class="inputButton button mainButton" type="submit" name="edit" value="<?php if(array_key_exists('lblUpdateMap', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblUpdateMap']); } else { ?>{$lblUpdateMap|ucfirst}<?php } ?>" />
		</div>
		</div>
	</div>
</form>
				<?php } ?>

<table width="100%">
	<tr>
		<td id="leftColumn">
			<div class="box">
				<div class="heading">
					<h3><?php if(array_key_exists('lblMap', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblMap']); } else { ?>{$lblMap|ucfirst}<?php } ?></h3>
				</div>

				
				<div class="options">
					<div id="map" style="height: <?php if(isset($this->variables['settings']) && array_key_exists('height', (array) $this->variables['settings'])) { echo $this->variables['settings']['height']; } else { ?>{$settings.height}<?php } ?>px; width: <?php if(isset($this->variables['settings']) && array_key_exists('width', (array) $this->variables['settings'])) { echo $this->variables['settings']['width']; } else { ?>{$settings.width}<?php } ?>px;">
					</div>
				</div>
			</div>
		</td>

		<?php
					if(isset($this->forms['settings']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['settings']->getAction(); ?>" method="<?php echo $this->forms['settings']->getMethod(); ?>"<?php echo $this->forms['settings']->getParametersHTML(); ?>>
						<?php echo $this->forms['settings']->getField('form')->parse();
						if($this->forms['settings']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['settings']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['settings']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
		<td id="rightColumn" style="width: 300px; padding-left: 10px;">
			<div class="box">
				<div class="heading">
					<h3><?php if(array_key_exists('lblSettings', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSettings']); } else { ?>{$lblSettings|ucfirst}<?php } ?></h3>
				</div>

				
				<div class="options">
					<p>
						<label for="zoomLevel"><?php if(array_key_exists('lblZoomLevel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblZoomLevel']); } else { ?>{$lblZoomLevel|ucfirst}<?php } ?></label>
						<?php if(array_key_exists('ddmZoomLevel', (array) $this->variables)) { echo $this->variables['ddmZoomLevel']; } else { ?>{$ddmZoomLevel}<?php } ?> <?php if(array_key_exists('ddmZoomLevelError', (array) $this->variables)) { echo $this->variables['ddmZoomLevelError']; } else { ?>{$ddmZoomLevelError}<?php } ?>
					</p>
				</div>

				
				<div class="options"<?php if(!isset($this->variables['godUser']) || count($this->variables['godUser']) == 0 || $this->variables['godUser'] == '' || $this->variables['godUser'] === false): ?> style="display:none;"<?php endif; ?>>
					<p>
						<label for="width"><?php if(array_key_exists('lblWidth', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblWidth']); } else { ?>{$lblWidth|ucfirst}<?php } ?></label>
						<?php if(array_key_exists('txtWidth', (array) $this->variables)) { echo $this->variables['txtWidth']; } else { ?>{$txtWidth}<?php } ?> <?php if(array_key_exists('txtWidthError', (array) $this->variables)) { echo $this->variables['txtWidthError']; } else { ?>{$txtWidthError}<?php } ?>
						<span class="helpTxt">
							<?php if(array_key_exists('msgWidthHelp', (array) $this->variables)) { echo sprintf($this->variables['msgWidthHelp'], 300, 800); } else { ?>{$msgWidthHelp|sprintf:300:800}<?php } ?>
						</span>
					</p>
				</div>

				
				<div class="options"<?php if(!isset($this->variables['godUser']) || count($this->variables['godUser']) == 0 || $this->variables['godUser'] == '' || $this->variables['godUser'] === false): ?> style="display:none;"<?php endif; ?>>
					<p>
						<label for="height"><?php if(array_key_exists('lblHeight', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblHeight']); } else { ?>{$lblHeight|ucfirst}<?php } ?></label>
						<?php if(array_key_exists('txtHeight', (array) $this->variables)) { echo $this->variables['txtHeight']; } else { ?>{$txtHeight}<?php } ?> <?php if(array_key_exists('txtHeightError', (array) $this->variables)) { echo $this->variables['txtHeightError']; } else { ?>{$txtHeightError}<?php } ?>
						<span class="helpTxt">
							<?php if(array_key_exists('msgHeightHelp', (array) $this->variables)) { echo sprintf($this->variables['msgHeightHelp'], 150); } else { ?>{$msgHeightHelp|sprintf:150}<?php } ?>
						</span>
					</p>
				</div>

				
				<div class="options">
					<p>
						<label for="mapType"><?php if(array_key_exists('lblMapType', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblMapType']); } else { ?>{$lblMapType|ucfirst}<?php } ?></label>
						<?php if(array_key_exists('ddmMapType', (array) $this->variables)) { echo $this->variables['ddmMapType']; } else { ?>{$ddmMapType}<?php } ?> <?php if(array_key_exists('ddmMapTypeError', (array) $this->variables)) { echo $this->variables['ddmMapTypeError']; } else { ?>{$ddmMapTypeError}<?php } ?>
					</p>
				</div>

				
				<div class="options">
					<p>
						<label for="fullUrl"><?php if(array_key_exists('chkFullUrl', (array) $this->variables)) { echo $this->variables['chkFullUrl']; } else { ?>{$chkFullUrl}<?php } ?> <?php if(array_key_exists('msgShowMapUrl', (array) $this->variables)) { echo $this->variables['msgShowMapUrl']; } else { ?>{$msgShowMapUrl}<?php } ?></label>
					</p>
				</div>

				
				<div class="options">
					<p>
						<label for="directions"><?php if(array_key_exists('chkDirections', (array) $this->variables)) { echo $this->variables['chkDirections']; } else { ?>{$chkDirections}<?php } ?> <?php if(array_key_exists('msgShowDirections', (array) $this->variables)) { echo $this->variables['msgShowDirections']; } else { ?>{$msgShowDirections}<?php } ?></label>
					</p>
				</div>

				
				<div class="options">
					<p>
						<label for="markerOverview"><?php if(array_key_exists('chkMarkerOverview', (array) $this->variables)) { echo $this->variables['chkMarkerOverview']; } else { ?>{$chkMarkerOverview}<?php } ?> <?php if(array_key_exists('msgShowMarkerOverview', (array) $this->variables)) { echo $this->variables['msgShowMarkerOverview']; } else { ?>{$msgShowMarkerOverview}<?php } ?></label>
					</p>
				</div>
			</div>
		</td>
		</form>
				<?php } ?>
	</tr>
</table>

<div class="fullwidthOptions">
	<?php
					if(isset($this->variables['showLocationDelete']) && count($this->variables['showLocationDelete']) != 0 && $this->variables['showLocationDelete'] != '' && $this->variables['showLocationDelete'] !== false)
					{
						?>
	<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'delete'); } else { ?>{$var|geturl:'delete'}<?php } ?>&amp;id=<?php if(isset($this->variables['item']) && array_key_exists('id', (array) $this->variables['item'])) { echo $this->variables['item']['id']; } else { ?>{$item.id}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
		<span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
	</a>
	<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
		<p>
			<?php if(array_key_exists('msgConfirmDelete', (array) $this->variables) && isset($this->variables['item']) && array_key_exists('title', (array) $this->variables['item'])) { echo sprintf($this->variables['msgConfirmDelete'], $this->variables['item']['title']); } else { ?>{$msgConfirmDelete|sprintf:<?php if(isset($this->variables['item']) && array_key_exists('title', (array) $this->variables['item'])) { echo $this->variables['item']['title']; } else { ?>{$item.title}<?php } ?>}<?php } ?>
		</p>
	</div>
	<?php } ?>

	<div class="buttonHolderRight">
		<a href="#" id="saveLiveData" class="button mainButton">
			<span><?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?></span>
		</a>
	</div>
</div>

<script type="text/javascript">
	var mapOptions =
	{
		zoom: '<?php if(isset($this->variables['settings']) && array_key_exists('zoom_level', (array) $this->variables['settings'])) { echo $this->variables['settings']['zoom_level']; } else { ?>{$settings.zoom_level}<?php } ?>' == 'auto' ? 0 : <?php if(isset($this->variables['settings']) && array_key_exists('zoom_level', (array) $this->variables['settings'])) { echo $this->variables['settings']['zoom_level']; } else { ?>{$settings.zoom_level}<?php } ?>,
		type: '<?php if(isset($this->variables['settings']) && array_key_exists('map_type', (array) $this->variables['settings'])) { echo $this->variables['settings']['map_type']; } else { ?>{$settings.map_type}<?php } ?>',
		center:
		{
			lat: <?php if(isset($this->variables['settings']['center']) && array_key_exists('lat', (array) $this->variables['settings']['center'])) { echo $this->variables['settings']['center']['lat']; } else { ?>{$settings.center.lat}<?php } ?>,
			lng: <?php if(isset($this->variables['settings']['center']) && array_key_exists('lng', (array) $this->variables['settings']['center'])) { echo $this->variables['settings']['center']['lng']; } else { ?>{$settings.center.lng}<?php } ?>
		}
	};
	var markers = [];
	<?php
					if(isset($this->variables['item']['lat']) && count($this->variables['item']['lat']) != 0 && $this->variables['item']['lat'] != '' && $this->variables['item']['lat'] !== false)
					{
						?>
		<?php
					if(isset($this->variables['item']['lng']) && count($this->variables['item']['lng']) != 0 && $this->variables['item']['lng'] != '' && $this->variables['item']['lng'] !== false)
					{
						?>
			markers.push(
			{
				lat: <?php if(isset($this->variables['item']) && array_key_exists('lat', (array) $this->variables['item'])) { echo $this->variables['item']['lat']; } else { ?>{$item.lat}<?php } ?>,
				lng: <?php if(isset($this->variables['item']) && array_key_exists('lng', (array) $this->variables['item'])) { echo $this->variables['item']['lng']; } else { ?>{$item.lng}<?php } ?>,
				title: '<?php if(isset($this->variables['item']) && array_key_exists('title', (array) $this->variables['item'])) { echo $this->variables['item']['title']; } else { ?>{$item.title}<?php } ?>',
				text: '<p><?php if(isset($this->variables['item']) && array_key_exists('street', (array) $this->variables['item'])) { echo $this->variables['item']['street']; } else { ?>{$item.street}<?php } ?> <?php if(isset($this->variables['item']) && array_key_exists('number', (array) $this->variables['item'])) { echo $this->variables['item']['number']; } else { ?>{$item.number}<?php } ?></p><p><?php if(isset($this->variables['item']) && array_key_exists('zip', (array) $this->variables['item'])) { echo $this->variables['item']['zip']; } else { ?>{$item.zip}<?php } ?> <?php if(isset($this->variables['item']) && array_key_exists('city', (array) $this->variables['item'])) { echo $this->variables['item']['city']; } else { ?>{$item.city}<?php } ?></p>',
				dragable: true
			});
		<?php } ?>
	<?php } ?>
</script>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
