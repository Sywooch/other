<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblLocation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLocation']); } else { ?>{$lblLocation|ucfirst}<?php } ?>: <?php if(array_key_exists('lblAdd', (array) $this->variables)) { echo $this->variables['lblAdd']; } else { ?>{$lblAdd}<?php } ?></h2>
</div>

<?php
					if(isset($this->forms['add']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['add']->getAction(); ?>" method="<?php echo $this->forms['add']->getMethod(); ?>"<?php echo $this->forms['add']->getParametersHTML(); ?>>
						<?php echo $this->forms['add']->getField('form')->parse();
						if($this->forms['add']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['add']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['add']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<p>
		<label for="title"><?php if(array_key_exists('lblTitle', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTitle']); } else { ?>{$lblTitle|ucfirst}<?php } ?></label>
		<?php if(array_key_exists('txtTitle', (array) $this->variables)) { echo $this->variables['txtTitle']; } else { ?>{$txtTitle}<?php } ?> <?php if(array_key_exists('txtTitleError', (array) $this->variables)) { echo $this->variables['txtTitleError']; } else { ?>{$txtTitleError}<?php } ?>
	</p>

	<div class="box horizontal">
		<div class="heading">
			<h3><?php if(array_key_exists('lblAddress', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddress']); } else { ?>{$lblAddress|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<p>
				<label for="street"><?php if(array_key_exists('lblStreet', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblStreet']); } else { ?>{$lblStreet|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtStreet', (array) $this->variables)) { echo $this->variables['txtStreet']; } else { ?>{$txtStreet}<?php } ?> <?php if(array_key_exists('txtStreetError', (array) $this->variables)) { echo $this->variables['txtStreetError']; } else { ?>{$txtStreetError}<?php } ?>
			</p>
			<p>
				<label for="number"><?php if(array_key_exists('lblNumber', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblNumber']); } else { ?>{$lblNumber|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtNumber', (array) $this->variables)) { echo $this->variables['txtNumber']; } else { ?>{$txtNumber}<?php } ?> <?php if(array_key_exists('txtNumberError', (array) $this->variables)) { echo $this->variables['txtNumberError']; } else { ?>{$txtNumberError}<?php } ?>
			</p>
			<p>
				<label for="zip"><?php if(array_key_exists('lblZip', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblZip']); } else { ?>{$lblZip|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtZip', (array) $this->variables)) { echo $this->variables['txtZip']; } else { ?>{$txtZip}<?php } ?> <?php if(array_key_exists('txtZipError', (array) $this->variables)) { echo $this->variables['txtZipError']; } else { ?>{$txtZipError}<?php } ?>
			</p>
			<p>
				<label for="city"><?php if(array_key_exists('lblCity', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCity']); } else { ?>{$lblCity|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtCity', (array) $this->variables)) { echo $this->variables['txtCity']; } else { ?>{$txtCity}<?php } ?> <?php if(array_key_exists('txtCityError', (array) $this->variables)) { echo $this->variables['txtCityError']; } else { ?>{$txtCityError}<?php } ?>
			</p>
			<p>
				<label for="country"><?php if(array_key_exists('lblCountry', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCountry']); } else { ?>{$lblCountry|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('ddmCountry', (array) $this->variables)) { echo $this->variables['ddmCountry']; } else { ?>{$ddmCountry}<?php } ?> <?php if(array_key_exists('ddmCountryError', (array) $this->variables)) { echo $this->variables['ddmCountryError']; } else { ?>{$ddmCountryError}<?php } ?>
			</p>
		</div>
	</div>

	<div class="fullwidthOptions">
		<div class="buttonHolderRight">
			<input id="addButton" class="inputButton button mainButton" type="submit" name="add" value="<?php if(array_key_exists('lblAddToMap', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddToMap']); } else { ?>{$lblAddToMap|ucfirst}<?php } ?>" />
		</div>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Location\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
