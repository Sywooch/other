<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<?php
					if(isset($this->forms['edit']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['edit']->getAction(); ?>" method="<?php echo $this->forms['edit']->getMethod(); ?>"<?php echo $this->forms['edit']->getParametersHTML(); ?>>
						<?php echo $this->forms['edit']->getField('form')->parse();
						if($this->forms['edit']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['edit']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['edit']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="box horizontal labelWidthLong">
		<div class="heading">
			<h3><?php if(array_key_exists('lblExtensions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExtensions']); } else { ?>{$lblExtensions|ucfirst}<?php } ?>: <?php if(array_key_exists('lblEditTemplate', (array) $this->variables)) { echo $this->variables['lblEditTemplate']; } else { ?>{$lblEditTemplate}<?php } ?></h3>
		</div>

		<div class="options">
			<p>
				<label for="file"><?php if(array_key_exists('msgPathToTemplate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['msgPathToTemplate']); } else { ?>{$msgPathToTemplate|ucfirst}<?php } ?></label>
				<label for="theme" class="visuallyHidden"><?php if(array_key_exists('lblTheme', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTheme']); } else { ?>{$lblTheme|ucfirst}<?php } ?></label>
				<?php if(array_key_exists('ddmTheme', (array) $this->variables)) { echo $this->variables['ddmTheme']; } else { ?>{$ddmTheme}<?php } ?><small><code>/Core/Layout/Templates/</code></small><?php if(array_key_exists('txtFile', (array) $this->variables)) { echo $this->variables['txtFile']; } else { ?>{$txtFile}<?php } ?> <?php if(array_key_exists('ddmThemeError', (array) $this->variables)) { echo $this->variables['ddmThemeError']; } else { ?>{$ddmThemeError}<?php } ?> <?php if(array_key_exists('txtFileError', (array) $this->variables)) { echo $this->variables['txtFileError']; } else { ?>{$txtFileError}<?php } ?>
				<span class="helpTxt"><?php if(array_key_exists('msgHelpTemplateLocation', (array) $this->variables)) { echo $this->variables['msgHelpTemplateLocation']; } else { ?>{$msgHelpTemplateLocation}<?php } ?></span>
			</p>
			<p>
				<label for="label"><?php if(array_key_exists('lblLabel', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLabel']); } else { ?>{$lblLabel|ucfirst}<?php } ?></label>
				<?php if(array_key_exists('txtLabel', (array) $this->variables)) { echo $this->variables['txtLabel']; } else { ?>{$txtLabel}<?php } ?> <?php if(array_key_exists('txtLabelError', (array) $this->variables)) { echo $this->variables['txtLabelError']; } else { ?>{$txtLabelError}<?php } ?>
			</p>
		</div>
	</div>

	<div class="box horizontal">
		<div class="heading">
			<h3><?php if(array_key_exists('lblPositions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPositions']); } else { ?>{$lblPositions|ucfirst}<?php } ?></h3>
		</div>

		
		<div id="positionsList" class="options">

			<?php
					if(!isset($this->variables['positions']))
					{
						?>{iteration:positions}<?php
						$this->variables['positions'] = array();
						$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['fail'] = true;
					}
				if(isset(${'positions'})) $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['old'] = ${'positions'};
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['iteration'] = $this->variables['positions'];
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['i'] = 1;
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['count'] = count($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['iteration'] as ${'positions'})
				{
					if(!isset(${'positions'}['first']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['i'] == 1) ${'positions'}['first'] = true;
					if(!isset(${'positions'}['last']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['i'] == $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['count']) ${'positions'}['last'] = true;
					if(isset(${'positions'}['formElements']) && is_array(${'positions'}['formElements']))
					{
						foreach(${'positions'}['formElements'] as $name => $object)
						{
							${'positions'}[$name] = $object->parse();
							${'positions'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
				<div class="position clearfix"<?php if(!isset(${'positions'}['i']) || count(${'positions'}['i']) == 0 || ${'positions'}['i'] == '' || ${'positions'}['i'] === false): ?> style="display: none"<?php endif; ?>>

					
					<label for="position<?php if(array_key_exists('i', (array) ${'positions'})) { echo ${'positions'}['i']; } else { ?>{$positions->i}<?php } ?>"><span class="positionLabel"><?php if(array_key_exists('lblPosition', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPosition']); } else { ?>{$lblPosition|ucfirst}<?php } ?></span> <a href="#" class="deletePosition button icon iconOnly iconDelete"><span><?php if(array_key_exists('lblDeletePosition', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDeletePosition']); } else { ?>{$lblDeletePosition|ucfirst}<?php } ?></span></a></label>

					
					<?php if(array_key_exists('txtPosition', (array) ${'positions'})) { echo ${'positions'}['txtPosition']; } else { ?>{$positions->txtPosition}<?php } ?>

					<?php if(array_key_exists('txtPositionError', (array) ${'positions'})) { echo ${'positions'}['txtPositionError']; } else { ?>{$positions->txtPositionError}<?php } ?>

					<div class="defaultBlocks">

						
						<?php
					if(isset(${'positions'}['blocks']) && count(${'positions'}['blocks']) != 0 && ${'positions'}['blocks'] != '' && ${'positions'}['blocks'] !== false)
					{
						?>
							<?php
					if(!isset(${'positions'}['blocks']))
					{
						?>{iteration:positions->blocks}<?php
						${'positions'}['blocks'] = array();
						$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['fail'] = true;
					}
				if(isset(${'positions'}['blocks'])) $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['old'] = ${'positions'}['blocks'];
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['iteration'] = ${'positions'}['blocks'];
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['i'] = 1;
				$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['count'] = count($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['iteration']);
				foreach((array) $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['iteration'] as ${'positions'}['blocks'])
				{
					if(!isset(${'positions'}['blocks']['first']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['i'] == 1) ${'positions'}['blocks']['first'] = true;
					if(!isset(${'positions'}['blocks']['last']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['i'] == $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['count']) ${'positions'}['blocks']['last'] = true;
					if(isset(${'positions'}['blocks']['formElements']) && is_array(${'positions'}['blocks']['formElements']))
					{
						foreach(${'positions'}['blocks']['formElements'] as $name => $object)
						{
							${'positions'}['blocks'][$name] = $object->parse();
							${'positions'}['blocks'][$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
								<div class="defaultBlock">
									<?php if(isset(${'positions'}['blocks']) && array_key_exists('ddmType', (array) ${'positions'}['blocks'])) { echo ${'positions'}['blocks']['ddmType']; } else { ?>{$positions->blocks.ddmType}<?php } ?>
									<?php if(isset(${'positions'}['blocks']) && array_key_exists('ddmTypeError', (array) ${'positions'}['blocks'])) { echo ${'positions'}['blocks']['ddmTypeError']; } else { ?>{$positions->blocks.ddmTypeError}<?php } ?>

									
									<a href="#" class="deleteBlock button icon iconOnly iconDelete"><span><?php if(array_key_exists('lblDeleteBlock', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDeleteBlock']); } else { ?>{$lblDeleteBlock|ucfirst}<?php } ?></span></a>
								</div>
							<?php
					$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['i']++;
				}
					if(isset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['fail']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['fail'] == true)
					{
						?>{/iteration:positions->blocks}<?php
					}
				if(isset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['old'])) ${'positions'}['blocks'] = $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']['old'];
				else unset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_2']['blocks']);
				?>
						<?php } ?>

						
						<a href="#" class="addBlock button icon iconAdd"><span><?php if(array_key_exists('lblAddBlock', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddBlock']); } else { ?>{$lblAddBlock|ucfirst}<?php } ?></span></a>

					</div>

				</div>
			<?php
					$this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['fail']) && $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:positions}<?php
					}
				if(isset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['old'])) ${'positions'} = $this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']['old'];
				else unset($this->iterations['e301fc9dc9ae96e94b5803076eac202a_EditThemeTemplate.tpl.php_1']);
				?>

			
			<p>
				<a href="#" id="addPosition" class="button icon iconAdd"><span><?php if(array_key_exists('lblAddPosition', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAddPosition']); } else { ?>{$lblAddPosition|ucfirst}<?php } ?></span></a>
			</p>

			<?php
					if(isset($this->variables['formErrors']) && count($this->variables['formErrors']) != 0 && $this->variables['formErrors'] != '' && $this->variables['formErrors'] !== false)
					{
						?><span class="formError"><?php if(array_key_exists('formErrors', (array) $this->variables)) { echo $this->variables['formErrors']; } else { ?>{$formErrors}<?php } ?></span><?php } ?>
		</div>
	</div>

	<div class="box horizontal">
		<div class="heading">
			<h3>
				<label for="format"><?php if(array_key_exists('lblLayout', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLayout']); } else { ?>{$lblLayout|ucfirst}<?php } ?></label>
			</h3>
		</div>

		<div id="templateLayout" class="options clearfix">
			<p>
				<?php if(array_key_exists('txtFormat', (array) $this->variables)) { echo $this->variables['txtFormat']; } else { ?>{$txtFormat}<?php } ?> <?php if(array_key_exists('txtFormatError', (array) $this->variables)) { echo $this->variables['txtFormatError']; } else { ?>{$txtFormatError}<?php } ?>
				<span class="helpTxt"><?php if(array_key_exists('msgHelpTemplateFormat', (array) $this->variables)) { echo $this->variables['msgHelpTemplateFormat']; } else { ?>{$msgHelpTemplateFormat}<?php } ?></span>
			</p>

			<div class="longHelpTxt">
				<?php if(array_key_exists('msgHelpPositionsLayout', (array) $this->variables)) { echo $this->variables['msgHelpPositionsLayout']; } else { ?>{$msgHelpPositionsLayout}<?php } ?>
			</div>
		</div>
	</div>

	<div class="box horizontal">
		<div class="heading">
			<h3><?php if(array_key_exists('lblStatus', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblStatus']); } else { ?>{$lblStatus|ucfirst}<?php } ?></h3>
		</div>

		<div class="options">
			<ul class="inputList pb0">
				<li><label for="active"><?php if(array_key_exists('chkActive', (array) $this->variables)) { echo $this->variables['chkActive']; } else { ?>{$chkActive}<?php } ?> <?php if(array_key_exists('lblActive', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblActive']); } else { ?>{$lblActive|ucfirst}<?php } ?></label> <?php if(array_key_exists('chkActiveError', (array) $this->variables)) { echo $this->variables['chkActiveError']; } else { ?>{$chkActiveError}<?php } ?></li>
				<li><label for="default"><?php if(array_key_exists('chkDefault', (array) $this->variables)) { echo $this->variables['chkDefault']; } else { ?>{$chkDefault}<?php } ?> <?php if(array_key_exists('lblDefault', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDefault']); } else { ?>{$lblDefault|ucfirst}<?php } ?></label> <?php if(array_key_exists('chkDefaultError', (array) $this->variables)) { echo $this->variables['chkDefaultError']; } else { ?>{$chkDefaultError}<?php } ?></li>
			</ul>
		</div>
	</div>

	<div class="box horizontal">
		<div class="heading">
			<h3><?php if(array_key_exists('lblOverwrite', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblOverwrite']); } else { ?>{$lblOverwrite|ucfirst}<?php } ?></h3>
		</div>

		<div class="options">
			<ul class="inputList pb0">
				<li><label for="overwrite"><?php if(array_key_exists('chkOverwrite', (array) $this->variables)) { echo $this->variables['chkOverwrite']; } else { ?>{$chkOverwrite}<?php } ?> <?php if(array_key_exists('lblOverwrite', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblOverwrite']); } else { ?>{$lblOverwrite|ucfirst}<?php } ?></label> <?php if(array_key_exists('chkOverwriteError', (array) $this->variables)) { echo $this->variables['chkOverwriteError']; } else { ?>{$chkOverwriteError}<?php } ?></li>
			</ul>
			<div class="longHelpTxt">
				<span class="infoMessage"><?php if(array_key_exists('msgHelpOverwrite', (array) $this->variables)) { echo $this->variables['msgHelpOverwrite']; } else { ?>{$msgHelpOverwrite}<?php } ?></span>
			</div>
		</div>
	</div>

	<div class="fullwidthOptions">
		<?php
					if(isset($this->variables['showExtensionsDeleteThemeTemplate']) && count($this->variables['showExtensionsDeleteThemeTemplate']) != 0 && $this->variables['showExtensionsDeleteThemeTemplate'] != '' && $this->variables['showExtensionsDeleteThemeTemplate'] !== false)
					{
						?>
			<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'delete_theme_template'); } else { ?>{$var|geturl:'delete_theme_template'}<?php } ?>&amp;id=<?php if(isset($this->variables['template']) && array_key_exists('id', (array) $this->variables['template'])) { echo $this->variables['template']['id']; } else { ?>{$template.id}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
				<span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
			</a>
		<?php } ?>

		<div class="buttonHolderRight">
			<input id="editButton" class="inputButton button mainButton" type="submit" name="edit" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
		</div>
	</div>

	<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
		<p><?php if(array_key_exists('msgConfirmDeleteTemplate', (array) $this->variables) && isset($this->variables['template']) && array_key_exists('label', (array) $this->variables['template'])) { echo sprintf($this->variables['msgConfirmDeleteTemplate'], $this->variables['template']['label']); } else { ?>{$msgConfirmDeleteTemplate|sprintf:<?php if(isset($this->variables['template']) && array_key_exists('label', (array) $this->variables['template'])) { echo $this->variables['template']['label']; } else { ?>{$template.label}<?php } ?>}<?php } ?></p>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
