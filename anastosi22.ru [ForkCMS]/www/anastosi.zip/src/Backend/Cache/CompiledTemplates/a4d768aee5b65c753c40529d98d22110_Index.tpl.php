<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>


<div class="pageTitle">
	<h2><?php if(array_key_exists('lblAnalytics', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAnalytics']); } else { ?>{$lblAnalytics|ucfirst}<?php } ?></h2>
</div>

<?php
					if(isset($this->variables['warnings']) && count($this->variables['warnings']) != 0 && $this->variables['warnings'] != '' && $this->variables['warnings'] !== false)
					{
						?>
	<div class="generalMessage infoMessage content">
		<p><strong><?php if(array_key_exists('msgConfigurationError', (array) $this->variables)) { echo $this->variables['msgConfigurationError']; } else { ?>{$msgConfigurationError}<?php } ?></strong></p>
		<ul class="pb0">
			<?php
					if(!isset($this->variables['warnings']))
					{
						?>{iteration:warnings}<?php
						$this->variables['warnings'] = array();
						$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['fail'] = true;
					}
				if(isset(${'warnings'})) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['old'] = ${'warnings'};
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['iteration'] = $this->variables['warnings'];
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['i'] = 1;
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['count'] = count($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['iteration'] as ${'warnings'})
				{
					if(!isset(${'warnings'}['first']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['i'] == 1) ${'warnings'}['first'] = true;
					if(!isset(${'warnings'}['last']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['i'] == $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['count']) ${'warnings'}['last'] = true;
					if(isset(${'warnings'}['formElements']) && is_array(${'warnings'}['formElements']))
					{
						foreach(${'warnings'}['formElements'] as $name => $object)
						{
							${'warnings'}[$name] = $object->parse();
							${'warnings'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
				<li><?php if(array_key_exists('message', (array) ${'warnings'})) { echo ${'warnings'}['message']; } else { ?>{$warnings->message}<?php } ?></li>
			<?php
					$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['fail']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:warnings}<?php
					}
				if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['old'])) ${'warnings'} = $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']['old'];
				else unset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_1']);
				?>
		</ul>
	</div>
<?php } ?>

<?php if(!isset($this->variables['warnings']) || count($this->variables['warnings']) == 0 || $this->variables['warnings'] == '' || $this->variables['warnings'] === false): ?>
	<?php if(!isset($this->variables['dataAvailable']) || count($this->variables['dataAvailable']) == 0 || $this->variables['dataAvailable'] == '' || $this->variables['dataAvailable'] === false): ?>
		<div class="generalMessage infoMessage content singleMessage">
			<p><strong><?php if(array_key_exists('msgNoData', (array) $this->variables)) { echo $this->variables['msgNoData']; } else { ?>{$msgNoData}<?php } ?></strong></p>
		</div>
	<?php endif; ?>

	<div class="box">
		<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_MODULE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_MODULE_PATH']; } else { ?>{$BACKEND_MODULE_PATH}<?php } ?>/Layout/Templates/Period.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_MODULE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_MODULE_PATH']; } else { ?>{$BACKEND_MODULE_PATH}<?php } ?>/Layout/Templates/Period.tpl}<?php
				}
?>

		<div class="options content">
			<div class="analyticsColWrapper clearfix">
				<div class="analyticsCol">
					<p><strong><?php if(array_key_exists('pageviews', (array) $this->variables)) { echo $this->variables['pageviews']; } else { ?>{$pageviews}<?php } ?> </strong><a href="<?php if(array_key_exists('googlePageviewsURL', (array) $this->variables)) { echo $this->variables['googlePageviewsURL']; } else { ?>{$googlePageviewsURL}<?php } ?>"><?php if(array_key_exists('lblPageviews', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPageviews']); } else { ?>{$lblPageviews|ucfirst}<?php } ?></a></p>
					<p><strong><?php if(array_key_exists('visitors', (array) $this->variables)) { echo $this->variables['visitors']; } else { ?>{$visitors}<?php } ?> </strong><a href="<?php if(array_key_exists('googleVisitorsURL', (array) $this->variables)) { echo $this->variables['googleVisitorsURL']; } else { ?>{$googleVisitorsURL}<?php } ?>"><?php if(array_key_exists('lblVisitors', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblVisitors']); } else { ?>{$lblVisitors|ucfirst}<?php } ?></a></p>
				</div>
				<div class="analyticsCol">
					<p><strong><?php if(array_key_exists('pagesPerVisit', (array) $this->variables)) { echo $this->variables['pagesPerVisit']; } else { ?>{$pagesPerVisit}<?php } ?> </strong><a href="<?php if(array_key_exists('googleAveragePageviewsURL', (array) $this->variables)) { echo $this->variables['googleAveragePageviewsURL']; } else { ?>{$googleAveragePageviewsURL}<?php } ?>"><?php if(array_key_exists('lblPagesPerVisit', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPagesPerVisit']); } else { ?>{$lblPagesPerVisit|ucfirst}<?php } ?></a> <small>(<?php if(array_key_exists('pagesPerVisitDifference', (array) $this->variables)) { echo $this->variables['pagesPerVisitDifference']; } else { ?>{$pagesPerVisitDifference}<?php } ?>%)</small></p>
					<p><strong><?php if(array_key_exists('timeOnSite', (array) $this->variables)) { echo $this->variables['timeOnSite']; } else { ?>{$timeOnSite}<?php } ?> </strong><a href="<?php if(array_key_exists('googleTimeOnSiteURL', (array) $this->variables)) { echo $this->variables['googleTimeOnSiteURL']; } else { ?>{$googleTimeOnSiteURL}<?php } ?>"><?php if(array_key_exists('lblAverageTimeOnSite', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAverageTimeOnSite']); } else { ?>{$lblAverageTimeOnSite|ucfirst}<?php } ?></a> <small>(<?php if(array_key_exists('timeOnSiteDifference', (array) $this->variables)) { echo $this->variables['timeOnSiteDifference']; } else { ?>{$timeOnSiteDifference}<?php } ?>%)</small></p>
				</div>
				<div class="analyticsCol">
					<p><strong><?php if(array_key_exists('newVisits', (array) $this->variables)) { echo $this->variables['newVisits']; } else { ?>{$newVisits}<?php } ?>% </strong><a href="<?php if(array_key_exists('googleVisitorTypesURL', (array) $this->variables)) { echo $this->variables['googleVisitorTypesURL']; } else { ?>{$googleVisitorTypesURL}<?php } ?>"><?php if(array_key_exists('lblNewVisitsPercentage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblNewVisitsPercentage']); } else { ?>{$lblNewVisitsPercentage|ucfirst}<?php } ?></a> <small>(<?php if(array_key_exists('newVisitsDifference', (array) $this->variables)) { echo $this->variables['newVisitsDifference']; } else { ?>{$newVisitsDifference}<?php } ?>%)</small></p>
					<p><strong><?php if(array_key_exists('bounces', (array) $this->variables)) { echo $this->variables['bounces']; } else { ?>{$bounces}<?php } ?>% </strong><a href="<?php if(array_key_exists('googleBouncesURL', (array) $this->variables)) { echo $this->variables['googleBouncesURL']; } else { ?>{$googleBouncesURL}<?php } ?>"><?php if(array_key_exists('lblBounceRate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblBounceRate']); } else { ?>{$lblBounceRate|ucfirst}<?php } ?></a> <small>(<?php if(array_key_exists('bouncesDifference', (array) $this->variables)) { echo $this->variables['bouncesDifference']; } else { ?>{$bouncesDifference}<?php } ?>%)</small></p>
				</div>
			</div>
		</div>

		<div class="options content">
			<div class="analyticsGraphWrapper">
				<div class="analyticsLeftCol">
					<div class="box boxLevel2">
						<div class="heading">
							<h3><a href="<?php if(array_key_exists('googleVisitorsURL', (array) $this->variables)) { echo $this->variables['googleVisitorsURL']; } else { ?>{$googleVisitorsURL}<?php } ?>"><?php if(array_key_exists('lblRecentVisits', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRecentVisits']); } else { ?>{$lblRecentVisits|ucfirst}<?php } ?></a></h3>
							<div class="buttonHolderRight">
								<a class="button icon iconGoto linkButton" href="<?php if(array_key_exists('googleVisitorsURL', (array) $this->variables)) { echo $this->variables['googleVisitorsURL']; } else { ?>{$googleVisitorsURL}<?php } ?>"><span><?php if(array_key_exists('lblViewReport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblViewReport']); } else { ?>{$lblViewReport|ucfirst}<?php } ?></span></a>
							</div>
						</div>
						<div class="options">
							<?php
					if(isset($this->variables['graphData']) && count($this->variables['graphData']) != 0 && $this->variables['graphData'] != '' && $this->variables['graphData'] !== false)
					{
						?>
								<div id="dataChartDoubleMetricPerDay" class="hidden">
									<span id="maxYAxis"><?php if(array_key_exists('maxYAxis', (array) $this->variables)) { echo $this->variables['maxYAxis']; } else { ?>{$maxYAxis}<?php } ?></span>
									<span id="tickInterval"><?php if(array_key_exists('tickInterval', (array) $this->variables)) { echo $this->variables['tickInterval']; } else { ?>{$tickInterval}<?php } ?></span>
									<span id="yAxisTitle"><?php if(array_key_exists('lblVisits', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblVisits']); } else { ?>{$lblVisits|ucfirst}<?php } ?></span>
									<ul class="series">
										<?php
					if(!isset($this->variables['graphData']))
					{
						?>{iteration:graphData}<?php
						$this->variables['graphData'] = array();
						$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['fail'] = true;
					}
				if(isset(${'graphData'})) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['old'] = ${'graphData'};
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['iteration'] = $this->variables['graphData'];
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['i'] = 1;
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['count'] = count($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['iteration']);
				foreach((array) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['iteration'] as ${'graphData'})
				{
					if(!isset(${'graphData'}['first']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['i'] == 1) ${'graphData'}['first'] = true;
					if(!isset(${'graphData'}['last']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['i'] == $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['count']) ${'graphData'}['last'] = true;
					if(isset(${'graphData'}['formElements']) && is_array(${'graphData'}['formElements']))
					{
						foreach(${'graphData'}['formElements'] as $name => $object)
						{
							${'graphData'}[$name] = $object->parse();
							${'graphData'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
											<li class="serie" id="metric<?php if(array_key_exists('i', (array) ${'graphData'})) { echo ${'graphData'}['i']; } else { ?>{$graphData->i}<?php } ?>serie">
												<span class="name"><?php if(array_key_exists('label', (array) ${'graphData'})) { echo ${'graphData'}['label']; } else { ?>{$graphData->label}<?php } ?></span>
												<ul class="data">
													<?php
					if(!isset(${'graphData'}['data']))
					{
						?>{iteration:graphData->data}<?php
						${'graphData'}['data'] = array();
						$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['fail'] = true;
					}
				if(isset(${'graphData'}['data'])) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['old'] = ${'graphData'}['data'];
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['iteration'] = ${'graphData'}['data'];
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['i'] = 1;
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['count'] = count($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['iteration']);
				foreach((array) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['iteration'] as ${'graphData'}['data'])
				{
					if(!isset(${'graphData'}['data']['first']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['i'] == 1) ${'graphData'}['data']['first'] = true;
					if(!isset(${'graphData'}['data']['last']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['i'] == $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['count']) ${'graphData'}['data']['last'] = true;
					if(isset(${'graphData'}['data']['formElements']) && is_array(${'graphData'}['data']['formElements']))
					{
						foreach(${'graphData'}['data']['formElements'] as $name => $object)
						{
							${'graphData'}['data'][$name] = $object->parse();
							${'graphData'}['data'][$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
														<li>
															<span class="fulldate"><?php if(isset(${'graphData'}['data']) && array_key_exists('date', (array) ${'graphData'}['data']) && array_key_exists('INTERFACE_LANGUAGE', (array) $this->variables)) { echo ucwords(SpoonTemplateModifiers::date(${'graphData'}['data']['date'], 'D d M', $this->variables['INTERFACE_LANGUAGE'])); } else { ?>{$graphData->data.date|date:'D d M':<?php if(array_key_exists('INTERFACE_LANGUAGE', (array) $this->variables)) { echo $this->variables['INTERFACE_LANGUAGE']; } else { ?>{$INTERFACE_LANGUAGE}<?php } ?>|ucwords}<?php } ?></span>
															<span class="date"><?php if(isset(${'graphData'}['data']) && array_key_exists('date', (array) ${'graphData'}['data']) && array_key_exists('INTERFACE_LANGUAGE', (array) $this->variables)) { echo ucwords(SpoonTemplateModifiers::date(${'graphData'}['data']['date'], 'd M', $this->variables['INTERFACE_LANGUAGE'])); } else { ?>{$graphData->data.date|date:'d M':<?php if(array_key_exists('INTERFACE_LANGUAGE', (array) $this->variables)) { echo $this->variables['INTERFACE_LANGUAGE']; } else { ?>{$INTERFACE_LANGUAGE}<?php } ?>|ucwords}<?php } ?></span>
															<span class="value"><?php if(isset(${'graphData'}['data']) && array_key_exists('value', (array) ${'graphData'}['data'])) { echo ${'graphData'}['data']['value']; } else { ?>{$graphData->data.value}<?php } ?></span>
														</li>
													<?php
					$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['i']++;
				}
					if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['fail']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['fail'] == true)
					{
						?>{/iteration:graphData->data}<?php
					}
				if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['old'])) ${'graphData'}['data'] = $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']['old'];
				else unset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_4']['data']);
				?>
												</ul>
											</li>
										<?php
					$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['i']++;
				}
					if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['fail']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['fail'] == true)
					{
						?>{/iteration:graphData}<?php
					}
				if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['old'])) ${'graphData'} = $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']['old'];
				else unset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_2']);
				?>
									</ul>
								</div>
								<div id="chartDoubleMetricPerDay">&nbsp;</div>
							<?php } ?>
							<div class="buttonHolderRight">
								<a href="http://highcharts.com/" class="analyticsBacklink">Highcharts</a>
							</div>
						</div>
					</div>
				</div>

				<div class="analyticsRightCol">
					<div class="box boxLevel2">
						<div class="heading">
							<h3><a href="<?php if(array_key_exists('googleTrafficSourcesURL', (array) $this->variables)) { echo $this->variables['googleTrafficSourcesURL']; } else { ?>{$googleTrafficSourcesURL}<?php } ?>"><?php if(array_key_exists('lblPageviewsByTrafficSources', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPageviewsByTrafficSources']); } else { ?>{$lblPageviewsByTrafficSources|ucfirst}<?php } ?></a></h3>
							<div class="buttonHolderRight">
								<a class="button icon iconGoto linkButton" href="<?php if(array_key_exists('googleTrafficSourcesURL', (array) $this->variables)) { echo $this->variables['googleTrafficSourcesURL']; } else { ?>{$googleTrafficSourcesURL}<?php } ?>"><span><?php if(array_key_exists('lblViewReport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblViewReport']); } else { ?>{$lblViewReport|ucfirst}<?php } ?></span></a>
							</div>
						</div>
						<div class="options">
							<?php
					if(isset($this->variables['pieGraphData']) && count($this->variables['pieGraphData']) != 0 && $this->variables['pieGraphData'] != '' && $this->variables['pieGraphData'] !== false)
					{
						?>
								<div id="dataChartPieChart" class="hidden">
									<ul class="data">
										<?php
					if(!isset($this->variables['pieGraphData']))
					{
						?>{iteration:pieGraphData}<?php
						$this->variables['pieGraphData'] = array();
						$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['fail'] = true;
					}
				if(isset(${'pieGraphData'})) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['old'] = ${'pieGraphData'};
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['iteration'] = $this->variables['pieGraphData'];
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['i'] = 1;
				$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['count'] = count($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['iteration']);
				foreach((array) $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['iteration'] as ${'pieGraphData'})
				{
					if(!isset(${'pieGraphData'}['first']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['i'] == 1) ${'pieGraphData'}['first'] = true;
					if(!isset(${'pieGraphData'}['last']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['i'] == $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['count']) ${'pieGraphData'}['last'] = true;
					if(isset(${'pieGraphData'}['formElements']) && is_array(${'pieGraphData'}['formElements']))
					{
						foreach(${'pieGraphData'}['formElements'] as $name => $object)
						{
							${'pieGraphData'}[$name] = $object->parse();
							${'pieGraphData'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
											<li><span class="label"><?php if(array_key_exists('label', (array) ${'pieGraphData'})) { echo ${'pieGraphData'}['label']; } else { ?>{$pieGraphData->label}<?php } ?></span><span class="value"><?php if(array_key_exists('value', (array) ${'pieGraphData'})) { echo ${'pieGraphData'}['value']; } else { ?>{$pieGraphData->value}<?php } ?></span><span class="percentage"><?php if(array_key_exists('percentage', (array) ${'pieGraphData'})) { echo ${'pieGraphData'}['percentage']; } else { ?>{$pieGraphData->percentage}<?php } ?></span></li>
										<?php
					$this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['i']++;
				}
					if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['fail']) && $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['fail'] == true)
					{
						?>{/iteration:pieGraphData}<?php
					}
				if(isset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['old'])) ${'pieGraphData'} = $this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']['old'];
				else unset($this->iterations['a4d768aee5b65c753c40529d98d22110_Index.tpl.php_3']);
				?>
									</ul>
								</div>
								<div id="chartPieChart">&nbsp;</div>
							<?php } ?>
							<div class="buttonHolderRight">
								<a href="http://highcharts.com/" class="analyticsBacklink">Highcharts</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="dataGridHolder" id="analyticsDataGridLeftCol">
		<div class="tableHeading">
			<h3><a href="<?php if(array_key_exists('googleTopReferrersURL', (array) $this->variables)) { echo $this->variables['googleTopReferrersURL']; } else { ?>{$googleTopReferrersURL}<?php } ?>"><?php if(array_key_exists('lblTopReferrers', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTopReferrers']); } else { ?>{$lblTopReferrers|ucfirst}<?php } ?></a></h3>
			<div class="buttonHolderRight">
				<a class="button icon iconGoto linkButton" href="<?php if(array_key_exists('googleTopReferrersURL', (array) $this->variables)) { echo $this->variables['googleTopReferrersURL']; } else { ?>{$googleTopReferrersURL}<?php } ?>"><span><?php if(array_key_exists('lblViewReport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblViewReport']); } else { ?>{$lblViewReport|ucfirst}<?php } ?></span></a>
			</div>
		</div>

		
		<?php
					if(isset($this->variables['dgReferrers']) && count($this->variables['dgReferrers']) != 0 && $this->variables['dgReferrers'] != '' && $this->variables['dgReferrers'] !== false)
					{
						?>
			<?php if(array_key_exists('dgReferrers', (array) $this->variables)) { echo $this->variables['dgReferrers']; } else { ?>{$dgReferrers}<?php } ?>
		<?php } ?>
		<?php if(!isset($this->variables['dgReferrers']) || count($this->variables['dgReferrers']) == 0 || $this->variables['dgReferrers'] == '' || $this->variables['dgReferrers'] === false): ?>
			<table class="dataGrid">
				<tr>
					<td><?php if(array_key_exists('msgNoReferrers', (array) $this->variables)) { echo $this->variables['msgNoReferrers']; } else { ?>{$msgNoReferrers}<?php } ?></td>
				</tr>
			</table>
		<?php endif; ?>
	</div>

	<div class="dataGridHolder" id="analyticsDataGridRightCol">
		<div class="tableHeading">
			<h3><a href="<?php if(array_key_exists('googleTopKeywordsURL', (array) $this->variables)) { echo $this->variables['googleTopKeywordsURL']; } else { ?>{$googleTopKeywordsURL}<?php } ?>"><?php if(array_key_exists('lblTopKeywords', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTopKeywords']); } else { ?>{$lblTopKeywords|ucfirst}<?php } ?></a></h3>
			<div class="buttonHolderRight">
				<a class="button icon iconGoto linkButton" href="<?php if(array_key_exists('googleTopKeywordsURL', (array) $this->variables)) { echo $this->variables['googleTopKeywordsURL']; } else { ?>{$googleTopKeywordsURL}<?php } ?>"><span><?php if(array_key_exists('lblViewReport', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblViewReport']); } else { ?>{$lblViewReport|ucfirst}<?php } ?></span></a>
			</div>
		</div>

		
		<?php
					if(isset($this->variables['dgKeywords']) && count($this->variables['dgKeywords']) != 0 && $this->variables['dgKeywords'] != '' && $this->variables['dgKeywords'] !== false)
					{
						?>
			<?php if(array_key_exists('dgKeywords', (array) $this->variables)) { echo $this->variables['dgKeywords']; } else { ?>{$dgKeywords}<?php } ?>
		<?php } ?>
		<?php if(!isset($this->variables['dgKeywords']) || count($this->variables['dgKeywords']) == 0 || $this->variables['dgKeywords'] == '' || $this->variables['dgKeywords'] === false): ?>
			<table class="dataGrid">
				<tr>
					<td><?php if(array_key_exists('msgNoKeywords', (array) $this->variables)) { echo $this->variables['msgNoKeywords']; } else { ?>{$msgNoKeywords}<?php } ?></td>
				</tr>
			</table>
		<?php endif; ?>
	</div>
<?php endif; ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
