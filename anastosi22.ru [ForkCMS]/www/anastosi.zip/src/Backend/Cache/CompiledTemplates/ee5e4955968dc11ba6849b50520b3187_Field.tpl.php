<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<div id="fieldHolder-<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" class="field options">
	
	<?php
					if(isset($this->variables['plaintext']) && count($this->variables['plaintext']) != 0 && $this->variables['plaintext'] != '' && $this->variables['plaintext'] !== false)
					{
						?>
		<div class="fieldWrapper content">
			<?php if(array_key_exists('content', (array) $this->variables)) { echo $this->variables['content']; } else { ?>{$content}<?php } ?>
		</div>
	<?php } ?>

	
	<?php
					if(isset($this->variables['simple']) && count($this->variables['simple']) != 0 && $this->variables['simple'] != '' && $this->variables['simple'] !== false)
					{
						?>
		<div class="fieldWrapper horizontal">
			<label for="field<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>">
				<?php if(array_key_exists('label', (array) $this->variables)) { echo $this->variables['label']; } else { ?>{$label}<?php } ?><?php
					if(isset($this->variables['required']) && count($this->variables['required']) != 0 && $this->variables['required'] != '' && $this->variables['required'] !== false)
					{
						?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr><?php } ?>
			</label>
			<?php if(array_key_exists('field', (array) $this->variables)) { echo $this->variables['field']; } else { ?>{$field}<?php } ?>
		</div>
	<?php } ?>

	
	<?php
					if(isset($this->variables['multiple']) && count($this->variables['multiple']) != 0 && $this->variables['multiple'] != '' && $this->variables['multiple'] !== false)
					{
						?>
		<div class="fieldWrapper horizontal">
			<p class="label"><?php if(array_key_exists('label', (array) $this->variables)) { echo $this->variables['label']; } else { ?>{$label}<?php } ?><?php
					if(isset($this->variables['required']) && count($this->variables['required']) != 0 && $this->variables['required'] != '' && $this->variables['required'] !== false)
					{
						?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr><?php } ?></p>
			<ul class="inputList">
			<?php
					if(!isset($this->variables['items']))
					{
						?>{iteration:items}<?php
						$this->variables['items'] = array();
						$this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['fail'] = true;
					}
				if(isset(${'items'})) $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['old'] = ${'items'};
				$this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['iteration'] = $this->variables['items'];
				$this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['i'] = 1;
				$this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['count'] = count($this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['iteration'] as ${'items'})
				{
					if(!isset(${'items'}['first']) && $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['i'] == 1) ${'items'}['first'] = true;
					if(!isset(${'items'}['last']) && $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['i'] == $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['count']) ${'items'}['last'] = true;
					if(isset(${'items'}['formElements']) && is_array(${'items'}['formElements']))
					{
						foreach(${'items'}['formElements'] as $name => $object)
						{
							${'items'}[$name] = $object->parse();
							${'items'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
				<li><label for="<?php if(array_key_exists('id', (array) ${'items'})) { echo ${'items'}['id']; } else { ?>{$items->id}<?php } ?>"><?php if(array_key_exists('field', (array) ${'items'})) { echo ${'items'}['field']; } else { ?>{$items->field}<?php } ?> <?php if(array_key_exists('label', (array) ${'items'})) { echo ${'items'}['label']; } else { ?>{$items->label}<?php } ?></label></li>
			<?php
					$this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['fail']) && $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:items}<?php
					}
				if(isset($this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['old'])) ${'items'} = $this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']['old'];
				else unset($this->iterations['ee5e4955968dc11ba6849b50520b3187_Field.tpl.php_1']);
				?>
			</ul>
		</div>
	<?php } ?>

	<p class="buttonHolderRight">
		<span class="dragAndDropHandle"></span>
		<a class="button icon iconOnly iconDelete deleteField" href="#delete-<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" rel="<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>"><span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo $this->variables['lblDelete']; } else { ?>{$lblDelete}<?php } ?></span></a>
		<a class="button icon iconOnly iconEdit editField" href="#edit-<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>" rel="<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?>"><span><?php if(array_key_exists('lblEdit', (array) $this->variables)) { echo $this->variables['lblEdit']; } else { ?>{$lblEdit}<?php } ?></span></a>
	</p>
</div>