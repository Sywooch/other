<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>


<div class="pageTitle">
	<h2><?php if(array_key_exists('lblModuleSettings', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblModuleSettings']); } else { ?>{$lblModuleSettings|ucfirst}<?php } ?>: <?php if(array_key_exists('lblAnalytics', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAnalytics']); } else { ?>{$lblAnalytics|ucfirst}<?php } ?></h2>
</div>

<?php
					if(isset($this->variables['Wizard']) && count($this->variables['Wizard']) != 0 && $this->variables['Wizard'] != '' && $this->variables['Wizard'] !== false)
					{
						?>
	<div class="generalMessage infoMessage content">
		<p><strong><?php if(array_key_exists('msgConfigurationError', (array) $this->variables)) { echo $this->variables['msgConfigurationError']; } else { ?>{$msgConfigurationError}<?php } ?></strong></p>
		<ul class="pb0">
			<?php
					if(isset($this->variables['NoSessionToken']) && count($this->variables['NoSessionToken']) != 0 && $this->variables['NoSessionToken'] != '' && $this->variables['NoSessionToken'] !== false)
					{
						?><li><?php if(array_key_exists('errNoSessionToken', (array) $this->variables)) { echo $this->variables['errNoSessionToken']; } else { ?>{$errNoSessionToken}<?php } ?></li><?php } ?>
			<?php
					if(isset($this->variables['NoTableId']) && count($this->variables['NoTableId']) != 0 && $this->variables['NoTableId'] != '' && $this->variables['NoTableId'] !== false)
					{
						?><li><?php if(array_key_exists('errNoTableId', (array) $this->variables)) { echo $this->variables['errNoTableId']; } else { ?>{$errNoTableId}<?php } ?></li><?php } ?>
		</ul>
	</div>
<?php } ?>

<div class="box">
	<div class="heading">
		<h3><?php if(array_key_exists('lblGoogleAnalyticsLink', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblGoogleAnalyticsLink']); } else { ?>{$lblGoogleAnalyticsLink|ucfirst}<?php } ?></h3>
	</div>

	<div class="options">
		<?php
					if(isset($this->variables['Wizard']) && count($this->variables['Wizard']) != 0 && $this->variables['Wizard'] != '' && $this->variables['Wizard'] !== false)
					{
						?>
			<?php
					if(isset($this->variables['NoSessionToken']) && count($this->variables['NoSessionToken']) != 0 && $this->variables['NoSessionToken'] != '' && $this->variables['NoSessionToken'] !== false)
					{
						?>
				<?php
					if(isset($this->forms['apiKey']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['apiKey']->getAction(); ?>" method="<?php echo $this->forms['apiKey']->getMethod(); ?>"<?php echo $this->forms['apiKey']->getParametersHTML(); ?>>
						<?php echo $this->forms['apiKey']->getField('form')->parse();
						if($this->forms['apiKey']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['apiKey']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['apiKey']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
					<p><?php if(array_key_exists('msgLinkGoogleAccount', (array) $this->variables)) { echo $this->variables['msgLinkGoogleAccount']; } else { ?>{$msgLinkGoogleAccount}<?php } ?></p>

					<div class="inputList">
						<label for="key"><?php if(array_key_exists('lblApiKey', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblApiKey']); } else { ?>{$lblApiKey|ucfirst}<?php } ?></label>
						<?php if(array_key_exists('txtKey', (array) $this->variables)) { echo $this->variables['txtKey']; } else { ?>{$txtKey}<?php } ?> <?php if(array_key_exists('txtKeyError', (array) $this->variables)) { echo $this->variables['txtKeyError']; } else { ?>{$txtKeyError}<?php } ?>
					</div>

					<div class="buttonHolder">
						<input id="submitForm" class="inputButton button mainButton" type="submit" name="submitForm" value="<?php if(array_key_exists('msgAuthenticateAtGoogle', (array) $this->variables)) { echo $this->variables['msgAuthenticateAtGoogle']; } else { ?>{$msgAuthenticateAtGoogle}<?php } ?>" />
					</div>

				</form>
				<?php } ?>
			<?php } ?>

			<?php
					if(isset($this->variables['NoTableId']) && count($this->variables['NoTableId']) != 0 && $this->variables['NoTableId'] != '' && $this->variables['NoTableId'] !== false)
					{
						?>
				<?php
					if(isset($this->variables['accounts']) && count($this->variables['accounts']) != 0 && $this->variables['accounts'] != '' && $this->variables['accounts'] !== false)
					{
						?>
					<p><?php if(array_key_exists('msgLinkWebsiteProfile', (array) $this->variables)) { echo $this->variables['msgLinkWebsiteProfile']; } else { ?>{$msgLinkWebsiteProfile}<?php } ?></p>
					<?php
					if(isset($this->forms['linkProfile']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['linkProfile']->getAction(); ?>" method="<?php echo $this->forms['linkProfile']->getMethod(); ?>"<?php echo $this->forms['linkProfile']->getParametersHTML(); ?>>
						<?php echo $this->forms['linkProfile']->getField('form')->parse();
						if($this->forms['linkProfile']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['linkProfile']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['linkProfile']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
					<div class="oneLiner fakeP">
						<p>
							<?php if(array_key_exists('ddmTableId', (array) $this->variables)) { echo $this->variables['ddmTableId']; } else { ?>{$ddmTableId}<?php } ?> <?php
					if(isset($this->variables['tableIdError']) && count($this->variables['tableIdError']) != 0 && $this->variables['tableIdError'] != '' && $this->variables['tableIdError'] !== false)
					{
						?><br /><span class="formerror"><?php if(array_key_exists('tableIdError', (array) $this->variables)) { echo $this->variables['tableIdError']; } else { ?>{$tableIdError}<?php } ?></span><?php } ?>
						</p>
						<div class="buttonHolder">
							<input id="submitForm" class="inputButton button mainButton" type="submit" name="submitForm" value="<?php if(array_key_exists('lblLinkThisProfile', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLinkThisProfile']); } else { ?>{$lblLinkThisProfile|ucfirst}<?php } ?>" />
						</div>
					</div>
					</form>
				<?php } ?>
				<?php } ?>

				<?php if(!isset($this->variables['accounts']) || count($this->variables['accounts']) == 0 || $this->variables['accounts'] == '' || $this->variables['accounts'] === false): ?>
					<p><?php if(array_key_exists('msgNoAccounts', (array) $this->variables)) { echo $this->variables['msgNoAccounts']; } else { ?>{$msgNoAccounts}<?php } ?></p>
				<?php endif; ?>

				<div class="buttonHolder">
					<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'settings'); } else { ?>{$var|geturl:'settings'}<?php } ?>&amp;remove=session_token" data-message-id="confirmDeleteSessionToken" class="askConfirmation submitButton button inputButton"><span><?php if(array_key_exists('msgRemoveAccountLink', (array) $this->variables)) { echo $this->variables['msgRemoveAccountLink']; } else { ?>{$msgRemoveAccountLink}<?php } ?></span></a>
				</div>
			<?php } ?>
		<?php } ?>

		<?php
					if(isset($this->variables['EverythingIsPresent']) && count($this->variables['EverythingIsPresent']) != 0 && $this->variables['EverythingIsPresent'] != '' && $this->variables['EverythingIsPresent'] !== false)
					{
						?>
			<p>
				<?php if(array_key_exists('lblLinkedAccount', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLinkedAccount']); } else { ?>{$lblLinkedAccount|ucfirst}<?php } ?>: <strong><?php if(array_key_exists('accountName', (array) $this->variables)) { echo $this->variables['accountName']; } else { ?>{$accountName}<?php } ?></strong><br />
				<?php if(array_key_exists('lblLinkedProfile', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLinkedProfile']); } else { ?>{$lblLinkedProfile|ucfirst}<?php } ?>: <strong><?php if(array_key_exists('profileTitle', (array) $this->variables)) { echo $this->variables['profileTitle']; } else { ?>{$profileTitle}<?php } ?></strong>
			</p>
			<div class="buttonHolder">
				<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'settings'); } else { ?>{$var|geturl:'settings'}<?php } ?>&amp;remove=table_id" data-message-id="confirmDeleteTableId" class="askConfirmation submitButton button inputButton"><span><?php if(array_key_exists('msgRemoveProfileLink', (array) $this->variables)) { echo $this->variables['msgRemoveProfileLink']; } else { ?>{$msgRemoveProfileLink}<?php } ?></span></a>
				<?php
					if(isset($this->variables['showAnalyticsIndex']) && count($this->variables['showAnalyticsIndex']) != 0 && $this->variables['showAnalyticsIndex'] != '' && $this->variables['showAnalyticsIndex'] !== false)
					{
						?><a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'index'); } else { ?>{$var|geturl:'index'}<?php } ?>" class="mainButton button"><span><?php if(array_key_exists('lblViewStatistics', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblViewStatistics']); } else { ?>{$lblViewStatistics|ucfirst}<?php } ?></span></a><?php } ?>
			</div>
		<?php } ?>

		<div id="confirmDeleteSessionToken" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
			<p>
				<?php if(array_key_exists('msgConfirmDeleteLinkGoogleAccount', (array) $this->variables)) { echo $this->variables['msgConfirmDeleteLinkGoogleAccount']; } else { ?>{$msgConfirmDeleteLinkGoogleAccount}<?php } ?>
			</p>
		</div>

		<div id="confirmDeleteTableId" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
			<p>
				<?php if(array_key_exists('msgConfirmDeleteLinkAccount', (array) $this->variables) && array_key_exists('accountName', (array) $this->variables)) { echo sprintf($this->variables['msgConfirmDeleteLinkAccount'], $this->variables['accountName']); } else { ?>{$msgConfirmDeleteLinkAccount|sprintf:<?php if(array_key_exists('accountName', (array) $this->variables)) { echo $this->variables['accountName']; } else { ?>{$accountName}<?php } ?>}<?php } ?>
			</p>
		</div>
	</div>
</div>

<?php
					if(isset($this->variables['EverythingIsPresent']) && count($this->variables['EverythingIsPresent']) != 0 && $this->variables['EverythingIsPresent'] != '' && $this->variables['EverythingIsPresent'] !== false)
					{
						?>
	<?php
					if(isset($this->forms['trackingType']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['trackingType']->getAction(); ?>" method="<?php echo $this->forms['trackingType']->getMethod(); ?>"<?php echo $this->forms['trackingType']->getParametersHTML(); ?>>
						<?php echo $this->forms['trackingType']->getField('form')->parse();
						if($this->forms['trackingType']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['trackingType']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['trackingType']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
		<div class="box">
			<div class="heading">
				<h3><?php if(array_key_exists('lblTrackingType', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTrackingType']); } else { ?>{$lblTrackingType|ucfirst}<?php } ?></h3>
			</div>

			<div class="options">
				<p><?php if(array_key_exists('msgHelpTrackingType', (array) $this->variables)) { echo $this->variables['msgHelpTrackingType']; } else { ?>{$msgHelpTrackingType}<?php } ?></p>
				<?php
					if(!isset($this->variables['type']))
					{
						?>{iteration:type}<?php
						$this->variables['type'] = array();
						$this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['fail'] = true;
					}
				if(isset(${'type'})) $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['old'] = ${'type'};
				$this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['iteration'] = $this->variables['type'];
				$this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['i'] = 1;
				$this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['count'] = count($this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['iteration'] as ${'type'})
				{
					if(!isset(${'type'}['first']) && $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['i'] == 1) ${'type'}['first'] = true;
					if(!isset(${'type'}['last']) && $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['i'] == $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['count']) ${'type'}['last'] = true;
					if(isset(${'type'}['formElements']) && is_array(${'type'}['formElements']))
					{
						foreach(${'type'}['formElements'] as $name => $object)
						{
							${'type'}[$name] = $object->parse();
							${'type'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
					<label for="<?php if(array_key_exists('id', (array) ${'type'})) { echo ${'type'}['id']; } else { ?>{$type->id}<?php } ?>"><?php if(array_key_exists('rbtType', (array) ${'type'})) { echo ${'type'}['rbtType']; } else { ?>{$type->rbtType}<?php } ?> <?php if(array_key_exists('label', (array) ${'type'})) { echo ${'type'}['label']; } else { ?>{$type->label}<?php } ?></label><br />
				<?php
					$this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['fail']) && $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:type}<?php
					}
				if(isset($this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['old'])) ${'type'} = $this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']['old'];
				else unset($this->iterations['7b4c59d7486c73e34526e67de4a1c61a_Settings.tpl.php_1']);
				?>
				<?php if(array_key_exists('rbtTypeError', (array) $this->variables)) { echo $this->variables['rbtTypeError']; } else { ?>{$rbtTypeError}<?php } ?>
			</div>
		</div>

		<div class="fullwidthOptions">
			<div class="buttonHolderRight">
				<input id="save" class="inputButton button mainButton" type="submit" name="save" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
			</div>
		</div>
	</form>
				<?php } ?>
<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Analytics\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
