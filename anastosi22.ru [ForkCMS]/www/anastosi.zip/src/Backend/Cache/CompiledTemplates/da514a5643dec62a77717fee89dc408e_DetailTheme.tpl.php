<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblExtensions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExtensions']); } else { ?>{$lblExtensions|ucfirst}<?php } ?>: <?php if(array_key_exists('msgTheme', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['msgTheme'], $this->variables['name']); } else { ?>{$msgTheme|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></h2>
</div>

<?php
					if(isset($this->variables['warnings']) && count($this->variables['warnings']) != 0 && $this->variables['warnings'] != '' && $this->variables['warnings'] !== false)
					{
						?>
	<div class="generalMessage infoMessage content">
		<ul class="pb0">
			<?php
					if(!isset($this->variables['warnings']))
					{
						?>{iteration:warnings}<?php
						$this->variables['warnings'] = array();
						$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['fail'] = true;
					}
				if(isset(${'warnings'})) $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['old'] = ${'warnings'};
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['iteration'] = $this->variables['warnings'];
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['i'] = 1;
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['count'] = count($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['iteration']);
				foreach((array) $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['iteration'] as ${'warnings'})
				{
					if(!isset(${'warnings'}['first']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['i'] == 1) ${'warnings'}['first'] = true;
					if(!isset(${'warnings'}['last']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['i'] == $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['count']) ${'warnings'}['last'] = true;
					if(isset(${'warnings'}['formElements']) && is_array(${'warnings'}['formElements']))
					{
						foreach(${'warnings'}['formElements'] as $name => $object)
						{
							${'warnings'}[$name] = $object->parse();
							${'warnings'}[$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
				<li><?php if(array_key_exists('message', (array) ${'warnings'})) { echo ${'warnings'}['message']; } else { ?>{$warnings->message}<?php } ?></li>
			<?php
					$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['i']++;
				}
					if(isset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['fail']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['fail'] == true)
					{
						?>{/iteration:warnings}<?php
					}
				if(isset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['old'])) ${'warnings'} = $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']['old'];
				else unset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_1']);
				?>
		</ul>
	</div>
<?php } ?>

<?php
					if(isset($this->variables['information']) && count($this->variables['information']) != 0 && $this->variables['information'] != '' && $this->variables['information'] !== false)
					{
						?>
	<table width="100%">
		<tr>
			<td id="leftColumn">
				<?php
					if(isset($this->variables['information']['description']) && count($this->variables['information']['description']) != 0 && $this->variables['information']['description'] != '' && $this->variables['information']['description'] !== false)
					{
						?>
					<div class="box">
						<div class="heading">
							<h3><?php if(array_key_exists('lblDescription', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDescription']); } else { ?>{$lblDescription|ucfirst}<?php } ?></h3>
						</div>
						<div class="options">
							<p><?php if(isset($this->variables['information']) && array_key_exists('description', (array) $this->variables['information'])) { echo $this->variables['information']['description']; } else { ?>{$information.description}<?php } ?></p>
						</div>
					</div>
				<?php } ?>
				<?php
					if(isset($this->variables['dataGridTemplates']) && count($this->variables['dataGridTemplates']) != 0 && $this->variables['dataGridTemplates'] != '' && $this->variables['dataGridTemplates'] !== false)
					{
						?>
					<div class="box">
						<div class="heading">
							<h3><?php if(array_key_exists('lblTemplates', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTemplates']); } else { ?>{$lblTemplates|ucfirst}<?php } ?></h3>
						</div>
						<div class="dataGridHolder">
							<?php if(array_key_exists('dataGridTemplates', (array) $this->variables)) { echo $this->variables['dataGridTemplates']; } else { ?>{$dataGridTemplates}<?php } ?>
						</div>
					</div>
				<?php } ?>
			</td>
			<td id="sidebar">
				<?php
					if(isset($this->variables['information']['thumbnail']) && count($this->variables['information']['thumbnail']) != 0 && $this->variables['information']['thumbnail'] != '' && $this->variables['information']['thumbnail'] !== false)
					{
						?>
					<div class="box">
						<div class="heading">
							<h3><?php if(array_key_exists('lblImage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblImage']); } else { ?>{$lblImage|ucfirst}<?php } ?></h3>
						</div>
						<div class="options">
							<img src="/src/Frontend/Themes/<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>/<?php if(isset($this->variables['information']) && array_key_exists('thumbnail', (array) $this->variables['information'])) { echo $this->variables['information']['thumbnail']; } else { ?>{$information.thumbnail}<?php } ?>" alt="<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>" />
						</div>
					</div>
				<?php } ?>

				<?php
					if(isset($this->variables['information']['version']) && count($this->variables['information']['version']) != 0 && $this->variables['information']['version'] != '' && $this->variables['information']['version'] !== false)
					{
						?>
					<div class="box">
						<div class="heading">
							<h3><?php if(array_key_exists('lblVersion', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblVersion']); } else { ?>{$lblVersion|ucfirst}<?php } ?></h3>
						</div>
						<div class="options">
							<p><?php if(isset($this->variables['information']) && array_key_exists('version', (array) $this->variables['information'])) { echo $this->variables['information']['version']; } else { ?>{$information.version}<?php } ?></p>
						</div>
					</div>
				<?php } ?>

				<?php
					if(isset($this->variables['information']['authors']) && count($this->variables['information']['authors']) != 0 && $this->variables['information']['authors'] != '' && $this->variables['information']['authors'] !== false)
					{
						?>
					<div class="box">
						<div class="heading">
							<h3><?php if(array_key_exists('lblAuthors', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAuthors']); } else { ?>{$lblAuthors|ucfirst}<?php } ?></h3>
						</div>
						<div class="options">
							<ul>
								<?php
					if(!isset($this->variables['information']['authors']))
					{
						?>{iteration:information.authors}<?php
						$this->variables['information']['authors'] = array();
						$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['fail'] = true;
					}
				if(isset(${'information'}['authors'])) $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['old'] = ${'information'}['authors'];
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['iteration'] = $this->variables['information']['authors'];
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['i'] = 1;
				$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['count'] = count($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['iteration']);
				foreach((array) $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['iteration'] as ${'information'}['authors'])
				{
					if(!isset(${'information'}['authors']['first']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['i'] == 1) ${'information'}['authors']['first'] = true;
					if(!isset(${'information'}['authors']['last']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['i'] == $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['count']) ${'information'}['authors']['last'] = true;
					if(isset(${'information'}['authors']['formElements']) && is_array(${'information'}['authors']['formElements']))
					{
						foreach(${'information'}['authors']['formElements'] as $name => $object)
						{
							${'information'}['authors'][$name] = $object->parse();
							${'information'}['authors'][$name .'Error'] = (is_callable(array($object, 'getErrors')) && $object->getErrors() != '') ? '<span class="formError">' . $object->getErrors() .'</span>' : '';
						}
					} ?>
									<li>
										<?php
					if(isset(${'information'}['authors']['url']) && count(${'information'}['authors']['url']) != 0 && ${'information'}['authors']['url'] != '' && ${'information'}['authors']['url'] !== false)
					{
						?>
											<a href="<?php if(isset(${'information'}['authors']) && array_key_exists('url', (array) ${'information'}['authors'])) { echo ${'information'}['authors']['url']; } else { ?>{$information.authors->url}<?php } ?>" title="<?php if(isset(${'information'}['authors']) && array_key_exists('name', (array) ${'information'}['authors'])) { echo ${'information'}['authors']['name']; } else { ?>{$information.authors->name}<?php } ?>">
										<?php } ?>
										<?php if(isset(${'information'}['authors']) && array_key_exists('name', (array) ${'information'}['authors'])) { echo ${'information'}['authors']['name']; } else { ?>{$information.authors->name}<?php } ?>
										<?php
					if(isset(${'information'}['authors']['url']) && count(${'information'}['authors']['url']) != 0 && ${'information'}['authors']['url'] != '' && ${'information'}['authors']['url'] !== false)
					{
						?>
											</a>
										<?php } ?>
									</li>
								<?php
					$this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['i']++;
				}
					if(isset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['fail']) && $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['fail'] == true)
					{
						?>{/iteration:information.authors}<?php
					}
				if(isset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['old'])) ${'information'}['authors'] = $this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']['old'];
				else unset($this->iterations['da514a5643dec62a77717fee89dc408e_DetailTheme.tpl.php_2']['authors']);
				?>
							</ul>
						</div>
					</div>
				<?php } ?>
			</td>
		</tr>
	</table>
<?php } ?>

<?php
					if(isset($this->variables['showExtensionsInstallTheme']) && count($this->variables['showExtensionsInstallTheme']) != 0 && $this->variables['showExtensionsInstallTheme'] != '' && $this->variables['showExtensionsInstallTheme'] !== false)
					{
						?>
<div class="fullwidthOptions">
	<div class="buttonHolderRight">
		<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo Backend\Core\Engine\TemplateModifiers::getURL($this->variables['var'], 'install_theme'); } else { ?>{$var|geturl:'install_theme'}<?php } ?>&amp;theme=<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>" data-message-id="confirmInstall" class="askConfirmation button mainButton">
			<span><?php if(array_key_exists('lblInstall', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblInstall']); } else { ?>{$lblInstall|ucfirst}<?php } ?></span>
		</a>
	</div>
</div>
<?php } ?>

<div id="confirmInstall" title="<?php if(array_key_exists('lblInstall', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblInstall']); } else { ?>{$lblInstall|ucfirst}<?php } ?>?" style="display: none;">
	<p>
		<?php if(array_key_exists('msgConfirmThemeInstall', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['msgConfirmThemeInstall'], $this->variables['name']); } else { ?>{$msgConfirmThemeInstall|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?>
	</p>
</div>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
