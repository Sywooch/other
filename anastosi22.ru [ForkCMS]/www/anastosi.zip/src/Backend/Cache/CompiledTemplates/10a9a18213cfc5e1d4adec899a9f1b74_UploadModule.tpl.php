<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureStartModule.tpl}<?php
				}
?>

<div class="box">
	<div class="heading">
		<h3><?php if(array_key_exists('lblExtensions', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblExtensions']); } else { ?>{$lblExtensions|ucfirst}<?php } ?>: <?php if(array_key_exists('lblUploadModule', (array) $this->variables)) { echo $this->variables['lblUploadModule']; } else { ?>{$lblUploadModule}<?php } ?></h3>
	</div>

	<?php
					if(isset($this->variables['zlibIsMissing']) && count($this->variables['zlibIsMissing']) != 0 && $this->variables['zlibIsMissing'] != '' && $this->variables['zlibIsMissing'] !== false)
					{
						?>
		<div class="options">
			<p>
				<?php if(array_key_exists('msgZlibIsMissing', (array) $this->variables)) { echo $this->variables['msgZlibIsMissing']; } else { ?>{$msgZlibIsMissing}<?php } ?>
			</p>
		</div>
	<?php } ?>

	<?php
					if(isset($this->variables['notWritable']) && count($this->variables['notWritable']) != 0 && $this->variables['notWritable'] != '' && $this->variables['notWritable'] !== false)
					{
						?>
		<div class="options">
			<p>
				<?php if(array_key_exists('msgModulesNotWritable', (array) $this->variables)) { echo $this->variables['msgModulesNotWritable']; } else { ?>{$msgModulesNotWritable}<?php } ?>
			</p>
		</div>
	<?php } ?>

	<?php if(!isset($this->variables['zlibIsMissing']) || count($this->variables['zlibIsMissing']) == 0 || $this->variables['zlibIsMissing'] == '' || $this->variables['zlibIsMissing'] === false): ?>
		<?php
					if(isset($this->forms['upload']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['upload']->getAction(); ?>" method="<?php echo $this->forms['upload']->getMethod(); ?>"<?php echo $this->forms['upload']->getParametersHTML(); ?>>
						<?php echo $this->forms['upload']->getField('form')->parse();
						if($this->forms['upload']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['upload']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['upload']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
			<div class="options">
				<div class="horizontal">
					<p>
						<label for="file"><?php if(array_key_exists('lblFile', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFile']); } else { ?>{$lblFile|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
						<?php if(array_key_exists('fileFile', (array) $this->variables)) { echo $this->variables['fileFile']; } else { ?>{$fileFile}<?php } ?> <?php if(array_key_exists('fileFileError', (array) $this->variables)) { echo $this->variables['fileFileError']; } else { ?>{$fileFileError}<?php } ?>
					</p>
				</div>
			</div>

			<div class="fullwidthOptions">
				<div class="buttonHolderRight">
					<input id="importButton" class="inputButton button mainButton" type="submit" name="add" value="<?php if(array_key_exists('lblInstall', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblInstall']); } else { ?>{$lblInstall|ucfirst}<?php } ?>" />
				</div>
			</div>
		</form>
				<?php } ?>
	<?php endif; ?>
</div>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/StructureEndModule.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile() || !file_exists($this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates'))) $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				if($return === false && $this->compile('D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'D:\localhost\htdocs\src\Backend\Modules\Extensions\Layout\Templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/Layout/Templates/Footer.tpl}<?php
				}
?>
