﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('uicolor','lv',{uicolor:{title:'UI krāsas izvēle',preview:'Priekšskatījums',config:'Ielīmējiet šo rindu jūsu config.js failā',predefined:'Predefinēti krāsu komplekti'}});
