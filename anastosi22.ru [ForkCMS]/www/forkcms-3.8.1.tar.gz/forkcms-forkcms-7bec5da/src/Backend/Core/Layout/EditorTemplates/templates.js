[
	{
		"title": "Left aligned image",
		"image": "src/Backend/Core/Layout/EditorTemplates/images/left_aligned_image.gif",
		"description": "A paragraph of text with an image on the left.",
		"html": "<p><img class=alignLeft src=src/Backend/Core/Layout/EditorTemplates/images/left_aligned_image.gif height=70 width=100 />Type the text here</p>"
	},
	{
		"title": "Right aligned image",
		"image": "src/Backend/Core/Layout/EditorTemplates/images/right_aligned_image.gif",
		"description": "A paragraph of text with an image on the right.",
		"html": "<p><img class=alignRight src=src/Backend/Core/Layout/EditorTemplates/images/right_aligned_image.gif height=70 width=100 />Type the text here</p>"
	}
]
