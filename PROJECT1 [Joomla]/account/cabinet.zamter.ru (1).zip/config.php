<?php
// HTTP
define('HTTP_SERVER', 'http://cabinet.zamter.ru/');

// HTTPS
define('HTTPS_SERVER', 'http://cabinet.zamter.ru/');

// DIR
define('DIR_APPLICATION', '/home/users2/z/zamter/domains/cabinet.zamter.ru/catalog/');
define('DIR_SYSTEM', '/home/users2/z/zamter/domains/cabinet.zamter.ru/system/');
define('DIR_DATABASE', '/home/users2/z/zamter/domains/cabinet.zamter.ru/system/database/');
define('DIR_LANGUAGE', '/home/users2/z/zamter/domains/cabinet.zamter.ru/catalog/language/');
define('DIR_TEMPLATE', '/home/users2/z/zamter/domains/cabinet.zamter.ru/catalog/view/theme/');
define('DIR_CONFIG', '/home/users2/z/zamter/domains/cabinet.zamter.ru/system/config/');
define('DIR_IMAGE', '/home/users2/z/zamter/domains/cabinet.zamter.ru/image/');
define('DIR_LOGS', '/home/users2/z/zamter/domains/cabinet.zamter.ru/system/logs/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', '045410197_cab');
define('DB_PASSWORD', '3223322');
define('DB_DATABASE', 'zamter_cab');
define('DB_PREFIX', '');
?>