<?php
// Text
$_['text_home']           = 'Главная';
$_['text_wishlist']       = 'Закладки (%s)';
$_['text_shopping_cart']  = 'Корзина покупок';
$_['text_search']         = 'Поиск';
$_['text_welcome']        = '<a href="%s">Войти</a> или <a href="%s">зарегистрироваться</a>';
$_['text_logged']         = 'Вы вошли как <a href="%s">%s</a> <b>(</b> <a href="%s">Выйти</a> <b>)</b>';
$_['text_account']        = 'Постоянный покупатель';
$_['text_checkout']       = 'Оформление заказа';
$_['text_page']           = 'страница';
?>