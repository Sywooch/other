<?php
// Heading 
$_['heading_title'] = 'Выход';

// Text
$_['text_message']  = '<p>Вы вышли из Вашего Личного Кабинета.</p>';
$_['text_account']  = 'Личный Кабинет';
$_['text_logout']   = 'Выход';
?>