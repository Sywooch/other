<?php
$_['text_klarna_fee'] = 'Оплата в системе Klarna ';
?>