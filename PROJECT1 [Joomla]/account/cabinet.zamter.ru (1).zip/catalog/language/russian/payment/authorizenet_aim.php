<?php
// Text
$_['text_title']           = 'Кредитная карта / Дебетовая карта (Authorize.Net)';
$_['text_credit_card']     = 'Данные кредитной карты';
$_['text_wait']            = 'Пожалуйста, подождите!';

// Entry
$_['entry_cc_owner']       = 'Владелец карты:';
$_['entry_cc_number']      = 'Номер карты:';
$_['entry_cc_expire_date'] = 'Дата окончания термина действия карты:';
$_['entry_cc_cvv2']        = 'Защитный код карты (CVV2):';
?>