<?php
// Heading
$_['heading_title']     = 'Спасибо, что покупаете вместе с %s .... ';

// Text
$_['text_title']        = 'Кредитные/дебетовые карты (WorldPay)';
$_['text_response']     = 'Ответ WorldPay:';
$_['text_success']      = '... Ваш платеж был успешно принят.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Подождите...</span></b><br><a href="%s">Кликните сюда...</a>.';
$_['text_failure']      = '... Ваш платеж был отменен!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Подождите...</span></b><br>Если переадресация не произошла, кликните <a href="%s">сюда</a>.';										  
$_['text_pw_mismatch']  = 'CallbackPW не совпадает. Заказ требует перерассмотрения.';
?>