<?php
// Heading
$_['heading_title'] = 'Корзина покупок';

// Text
$_['text_items']    = 'Товаров: %s (%s)';
$_['text_empty']    = 'В корзине пусто!';
$_['text_cart']     = 'Просмотр корзины';
$_['text_checkout'] = 'Оформление заказа';
?>