<?php
// Text
$_['text_title']  = 'Доставка по городу';
$_['text_weight'] = 'Вес:';
?>