<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Экспресс';
$_['text_standard'] = 'Стандарт';
$_['text_eta']      = 'Дней';
?>