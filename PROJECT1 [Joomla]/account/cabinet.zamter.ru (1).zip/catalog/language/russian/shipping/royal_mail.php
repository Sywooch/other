<?php
// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Вес:';
$_['text_insurance']             = 'Застраховано на:';
$_['text_1st_class_standard']    = 'Доставка почтой Первого Класса';
$_['text_1st_class_recorded']    = 'Заказная доставка почтой Первого Класса';
$_['text_2nd_class_standard']    = 'Доставка почтой Второго Класса';
$_['text_2nd_class_recorded']    = 'Заказная доставка почтой Второго Класса';
$_['text_special_delivery_500']  = 'Спецальная доставка следующего дня (&фунты;500)';
$_['text_special_delivery_1000'] = 'Спецальная доставка следующего дня (&фунты;1000)';
$_['text_special_delivery_2500'] = 'Спецальная доставка следующего дня (&фунты;2500)';
$_['text_standard_parcels']      = 'Стандартная посылка';
$_['text_airmail']               = 'Авиапочта';
$_['text_international_signed']  = 'Международная подпись';
$_['text_airsure']               = 'Рекомендованная авиапочта';
$_['text_surface']               = 'Внешние параметры';
?>