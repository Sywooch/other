<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Вес:'; 
$_['text_insurance']   = 'Застраховано на:';   
$_['text_time']        = 'Предполагаемое время доставки: 48 часов'; 
?>