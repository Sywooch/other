<?php
// Heading 
$_['heading_title']  = 'Live Chat';
?>