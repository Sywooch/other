<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<?php if( !$my->id ){ ?>
<div id="fd" class="es mod-es-login style-vertical module-social<?php echo $suffix;?>">
	<div class="mod-bd mt-10">
		<div class="es-form-wrap">
			<form class="es-form-login" method="post" action="<?php echo JRoute::_( 'index.php' );?>">
				<fieldset>
					<input type="text" placeholder="<?php echo $config->get( 'registrations.emailasusername' ) ? JText::_( 'MOD_EASYSOCIAL_LOGIN_EMAIL_PLACEHOLDER' ) : JText::_( 'MOD_EASYSOCIAL_LOGIN_USERNAME_PLACEHOLDER' );?>" name="username" class="form-control input-xs" />

					<input type="password" placeholder="<?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_PASSWORD_PLACEHOLDER' );?>" name="password" class="form-control input-xs" />

					<?php if( $params->get( 'show_remember_me' , true ) ){ ?>
					<div class="checkbox">
						<label for="remember-me">
							<input type="checkbox" id="remember-me" name="remember" value="yes" /> <?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_KEEP_ME_LOGGED_IN' );?>
						</label>
					</div>
					<?php } ?>

					<button type="submit" class="btn btn-block btn-es-primary btn-login"><?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_SUBMIT' );?></button>

					<?php if( $params->get( 'show_register_link' , true ) ){ ?>
					<div class="help-block mt-10 fd-small">
						<a href="<?php echo FRoute::registration();?>"><?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_REGISTER_NOW' );?></a>
					</div>
					<?php } ?>


					<?php if( $params->get( 'show_forget_username' , true ) && !$config->get( 'registrations.emailasusername' ) ){ ?>
					<div class="help-block mt-10 fd-small">
						<a href="<?php echo FRoute::profile( array( 'layout' => 'forgetUsername' ) );?>"><?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_FORGOT_USERNAME' );?></a>
					</div>
					<?php } ?>

					<?php if( $params->get( 'show_forget_password' , true ) ){ ?>
					<div class="help-block mt-5 fd-small">
						<a href="<?php echo FRoute::profile( array( 'layout' => 'forgetPassword' ) );?>"><?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_FORGOT_PASSWORD' );?></a>
					</div>
					<?php } ?>

					<?php if( $params->get( 'show_facebook_login' ) && $config->get( 'oauth.facebook.registration.enabled' ) && $config->get( 'registrations.enabled' )
							&& $config->get( 'oauth.facebook.secret' )
							&& $config->get( 'oauth.facebook.app' )
						){ ?>
					<div class="center es-signin-social">
						<p class="line">
							<strong><?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_SIGN_IN_WITH_SOCIAL_IDENTITY' );?></strong>
						</p>

						<?php echo $facebook->getLoginButton( FRoute::registration( array( 'layout' => 'oauthDialog' , 'client' => 'facebook', 'external' => true ) , false ) ); ?>
					</div>
					<?php } ?>

				</fieldset>

				<input type="hidden" name="option" value="com_easysocial" />
				<input type="hidden" name="controller" value="profile" />
				<input type="hidden" name="task" value="login" />
				<input type="hidden" name="return" value="<?php echo $return;?>" />
				<?php echo $modules->html( 'form.token' );?>

			</form>
		</div>
	</div>
</div>
<?php } else { ?>
<form action="<?php echo JRoute::_( 'index.php' );?>" id="es-mod-login-signout-form" method="post">
	<div class="text-center">
		<a href="javascript:void(0);" onclick="document.getElementById( 'es-mod-login-signout-form' ).submit();" class="btn btn-primary">
			<?php echo JText::_( 'MOD_EASYSOCIAL_LOGIN_SIGN_OUT' );?>
		</a>
	</div>

	<input type="hidden" name="return" value="<?php echo base64_encode( JRequest::getURI() );?>" />
	<input type="hidden" name="option" value="com_users" />
	<input type="hidden" name="task" value="user.logout" />
	<?php echo $modules->html( 'form.token' ); ?>
</form>
<?php } ?>
