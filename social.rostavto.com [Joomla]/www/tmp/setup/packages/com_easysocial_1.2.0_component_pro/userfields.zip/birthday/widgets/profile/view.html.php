<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

/**
 * Profile view for Notes app.
 *
 * @since	1.0
 * @access	public
 */
class BirthdayFieldWidgetsProfile
{
	/**
	 * Renders the age of the user.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function getAge( $value )
	{
		$birthDate 		= new DateTime( $value );

		// Don't use diff because PHP 5.2 doesn't support
		// $age			= $birthDate->diff( new DateTime );

		$now = new DateTime();

		$years = floor(($now->format('U') - $birthDate->format('U')) / (60*60*24*365));

		return $years;
	}

	/**
	 * Displays the age in the position profileHeaderA
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function profileHeaderA( $key , $user , $field )
	{
		$my = Foundry::user();
		$privacyLib = Foundry::privacy( $my->id );
		if( !$privacyLib->validate( 'core.view' , $field->id, SOCIAL_TYPE_FIELD , $user->id ) )
		{
			return;
		}

		$params = $field->getParams();

		if( $params->get( 'show_age' ) && !$privacyLib->validate( 'core.view', $field->id, 'field.datetime.year', $user->id ) )
		{
			return;
		}

		// Get the current stored value.
		$value 	= $field->data;

		if( empty( $value ) )
		{
			return false;
		}

		$data = new stdClass();

		$json = Foundry::json();

		if( $json->isJsonString( $value ) )
		{
			$data = $json->decode( $value );
		}
		else
		{
			$tmp = Foundry::date( $value, false );
			$data->year = $tmp->toFormat( 'Y' );
			$data->month = $tmp->toFormat( 'n' );
			$data->day = $tmp->toFormat( 'j' );
		}

		if( !isset( $data->year ) )
		{
			$data->year = '';
		}

		if( !isset( $data->month ) )
		{
			$data->month = '';
		}

		if( !isset( $data->day ) )
		{
			$data->day = '';
		}

		$date = null;

		if( !empty( $data->year ) && !empty( $data->month ) && !empty( $data->day ) )
		{
			$date = $data->year . '-' . $data->month . '-' . $data->day;
		}

		if( !$date )
		{
			return;
		}

		$theme 	= Foundry::themes();

		if( $params->get( 'show_age' ) )
		{
			// Compute the age now.
			$age 	= $this->getAge( $date );
			$theme->set( 'value', $age );
		}
		else
		{
			$format = $privacyLib->validate( 'core.view', $field->id, 'field.datetime.year', $user->id ) ? 'j F Y' : 'j F';
			$birthday = Foundry::date( $date )->toFormat( $format );
			$theme->set( 'value', $birthday );
		}

		$theme->set( 'params'	, $params );

		echo $theme->output( 'fields/user/birthday/widgets/display' );
	}
}
