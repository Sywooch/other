<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

// Include the datetime field
Foundry::import( 'fields:/user/datetime/datetime' );

/**
 * Field application for Birthday
 * Extends from datetime field since 1.2
 *
 * @since	1.0
 * @author	Jason Rey <jasonrey@stackideas.com>
 */
class SocialFieldsUserBirthday extends SocialFieldsUserDateTime
{
	public function onRegisterValidate( &$post )
	{
		if( !$this->checkAge( $post ) )
		{
			return false;
		}

		return parent::onRegisterValidate( $post );
	}

	public function onEditValidate( &$post )
	{
		if( !$this->checkAge( $post ) )
		{
			return false;
		}

		$state = parent::onEditValidate( $post );

		return $state;
	}

	private function checkAge( $post )
	{
		if( $this->params->get( 'age_limit' ) < 1  || empty( $post[$this->inputName] ) )
		{
			return true;
		}

		$value = $post[$this->inputName];

		$data	= $this->getDatetimeValue( $value );

		// We don't throw validity error here, leave it up to the parent function to do it
		if( !$data->isValid() )
		{
			return true;
		}

		$now = Foundry::date()->toUnix();
		$birthDate = $data->toDate()->toUnix();

		$diff = floor(($now - $birthDate) / (60*60*24*365) );

		if( $diff < $this->params->get( 'age_limit' ) )
		{
			$this->setError( JText::sprintf( 'PLG_FIELDS_BIRTHDAY_VALIDATION_AGE_LIMIT', $this->params->get( 'age_limit' ) ) );
			return false;
		}

		return true;
	}

	public function onRegisterOAuthBeforeSave( &$post, $client )
	{
		if( empty( $post['birthday'] ) )
		{
			return;
		}

		// Facebook format is M/D/Y, we reformat it to Y-M-D
		$date = explode( '/', $post['birthday'] );

		$reformedDate = Foundry::date( $date[2] . '-' . $date[0] . '-' . $date[1] );

		$post[ $this->inputName ] = array( 'data' => $reformedDate->toMySQL(), 'raw' => $reformedDate->toSql() );
	}

	public function onOAuthGetUserPermission( &$permissions )
	{
		$permissions[] = 'user_birthday';
	}

	public function onOAuthGetMetaFields( &$fields )
	{
		$fields[] = 'birthday';
	}
}
