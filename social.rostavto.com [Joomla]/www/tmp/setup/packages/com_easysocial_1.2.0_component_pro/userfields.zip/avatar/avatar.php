<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

// Include the fields library
Foundry::import( 'admin:/includes/fields/dependencies' );

require_once( dirname( __FILE__ ) . '/helper.php' );

/**
 * Field application for Avatar
 *
 * @since	1.0
 * @author	Jason Rey <jasonrey@stackideas.com>
 */
class SocialFieldsUserAvatar extends SocialFieldItem
{
	/**
	 * Displays the field input for user when they register their account.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	array
	 * @param	SocialTableRegistration
	 * @return	string	The html output.
	 *
	 * @author	Jason Rey <jasonrey@stackideas.com>
	 */
	public function onRegister( &$post, &$registration )
	{
		$avatars = array();

		// Load the default avatars
		if( isset( $registration->profile_id ) )
		{
			$model 		= Foundry::model( 'Avatars' );
			$avatars 	= $model->getDefaultAvatars( $registration->profile_id );
		}

		$this->set( 'avatars'		, $avatars );

		// Set the blank avatar
		$this->set( 'imageSource', 'media/com_easysocial/defaults/avatars/ ' . $this->group . '/square.png' );

		// Set errors
		$error	= $registration->getErrors( $this->inputName );

		$this->set( 'error', $error );

		$this->set( 'hasAvatar', false );

		$this->set( 'defaultAvatar', rtrim( JURI::root() , '/' ) . Foundry::config()->get( 'avatars.default.' . $this->group . '.' . SOCIAL_AVATAR_SQUARE ) );

		// Display the output.
		return $this->display();
	}

	/**
	 * Determines whether there's any errors in the submission in the registration form.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	array 	The posted data.
	 * @param	SocialTableRegistration		The registration ORM table.
	 * @return	bool	Determines if the system should proceed or throw errors.
	 *
	 * @author	Jason Rey <jasonrey@stackideas.com>
	 */
	public function onRegisterValidate( &$post, &$registration )
	{
		$state 	= $this->validate( $post );

		return $state;
	}

	/**
	 * Once a user registration is completed, the field should automatically
	 * move the temporary avatars into the user's folder if required.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onRegisterAfterSave( &$post, &$user )
	{
		$value = !empty( $post[ $this->inputName ] ) ? $post[ $this->inputName ] : '';

		if( !empty( $value ) )
		{
			$this->createAvatar( $value, $user->id );
		}

		unset( $post[ $this->inputName ] );
	}


	/**
	 * Processes before the user account is created when user signs in with oauth.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onRegisterOAuthAfterSave( &$data, &$oauthClient, SocialUser &$user )
	{
		// Let's see if avatarUrl is provided.
		if( !isset( $data[ 'avatar' ] ) || empty( $data[ 'avatar' ] ) )
		{
			return;
		}

		$avatarUrl	 		= $data[ 'avatar' ];

		// Store the avatar internally.
		$key 				= md5( $data[ 'oauth_id' ] . $data[ 'username' ] );
		$tmpAvatarPath 		= SOCIAL_MEDIA . '/tmp/' . $key;
		$tmpAvatarFile 		= $tmpAvatarPath . '/' . $key;

		jimport( 'joomla.filesystem.folder' );

		if( !JFolder::exists( $tmpAvatarPath ) )
		{
			$state 	= JFolder::create( $tmpAvatarPath );

			if( !$state )
			{
				Foundry::logError( __FILE__, __LINE__, 'OAUTH: Unable to create avatar folder.' );
			}
		}

		$connector 	= Foundry::get( 'Connector' );
		$connector->addUrl( $avatarUrl );
		$connector->connect();

		$contents 	= $connector->getResult( $avatarUrl );

		jimport( 'joomla.filesystem.file' );

		if( !JFile::write( $tmpAvatarFile, $contents ) )
		{
			dump( 'here' );
			Foundry::logError( __FILE__, __LINE__, 'AVATAR: Unable to store oauth avatar to tmp folder, ' . $tmpAvatarFile );
			return;
		}

		$image = Foundry::image();
		$image->load( $tmpAvatarFile );

		$avatar		= Foundry::avatar( $image , $user->id , SOCIAL_TYPE_USER );

		// Check if there's a profile photos album that already exists.
		$albumModel	= Foundry::model( 'Albums' );

		// Retrieve the user's default album
		$album		= $albumModel->getDefaultAlbum( $user->id , SOCIAL_TYPE_USER , SOCIAL_ALBUM_PROFILE_PHOTOS );

		$photo 				= Foundry::table( 'Photo' );
		$photo->uid 		= $user->id;
		$photo->user_id 	= $user->id;
		$photo->type 		= SOCIAL_TYPE_USER;
		$photo->album_id 	= $album->id;
		$photo->title 		= $user->getName();
		$photo->caption 	= JText::_( 'COM_EASYSOCIAL_PHOTO_IMPORTED_FROM_FACEBOOK' );
		$photo->ordering	= 0;

		// We need to set the photo state to "SOCIAL_PHOTOS_STATE_TMP"
		$photo->state 		= SOCIAL_PHOTOS_STATE_TMP;

		// Try to store the photo first
		$state 		= $photo->store();

		if( !$state )
		{
			$this->setError( JText::_( 'PLG_FIELDS_AVATAR_ERROR_CREATING_PHOTO_OBJECT' ) );
			return false;
		}

		// Push all the ordering of the photo down
		$photosModel = Foundry::model( 'photos' );
		$photosModel->pushPhotosOrdering( $album->id , $photo->id );

		// If album doesn't have a cover, set the current photo as the cover.
		if( !$album->hasCover() )
		{
			$album->cover_id 	= $photo->id;

			// Store the album
			$album->store();
		}

		// Get the photos library
		$photoLib 	= Foundry::get( 'Photos' , $image );
		$storage   = $photoLib->getStoragePath($album->id, $photo->id);
		$paths 		= $photoLib->create( $storage );

		// Create metadata about the photos
		foreach( $paths as $type => $fileName )
		{
			$meta 				= Foundry::table( 'PhotoMeta' );
			$meta->photo_id		= $photo->id;
			$meta->group 		= SOCIAL_PHOTOS_META_PATH;
			$meta->property 	= $type;
			$meta->value		= $storage . '/' . $fileName;

			$meta->store();
		}

		// Assign a badge for the user
		$photo->assignBadge( 'photos.upload' , $user->id );

		// @points: photos.upload
		// Assign points when user uploads a new photo
		$photo->assignPoints( 'photos.upload' , $user->id );

		// Synchronize Indexer
		$indexer 	= Foundry::get( 'Indexer' );
		$template	= $indexer->getTemplate();
		$template->setContent( $photo->title , $photo->caption );

		$url 	= FRoute::photos( array( 'layout' => 'item', 'id' => $photo->getAlias() ) );
		$url 	= '/' . ltrim( $url , '/' );
		$url 	= str_replace('/administrator/', '/', $url );

		$template->setSource( $photo->id , SOCIAL_INDEXER_TYPE_PHOTOS , $photo->uid , $url );
		$template->setThumbnail( $photo->getSource( 'thumbnail' ) );

		$indexer->index( $template );

		// Create the avatars now
		$avatar->store( $photo );

		// Once we are done creating the avatar, delete the temporary folder.
		$state		= JFolder::delete( $tmpAvatarPath );
	}

	/**
	 * Displays the field input for user when they edit their account.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialUser		The user that is being edited.
	 * @param	Array			The post data.
	 * @param	Array			The error data.
	 * @return	string			The html string of the field
	 *
	 * @author	Jason Rey <jasonrey@stackideas.com>
	 */
	public function onEdit( &$post, &$user, $errors )
	{
		$avatars = array();

		if( isset( $user->profile_id ) )
		{
			// Load the default avatars
			$model 		= Foundry::model( 'Avatars' );
			$avatars 	= $model->getDefaultAvatars( $user->profile_id );
		}

		$this->set( 'avatars'		, $avatars );

		$imageSource = $user->getAvatar( SOCIAL_AVATAR_SQUARE );

		$this->set( 'imageSource'	, $imageSource );

		// Set errors
		$error = $this->getError( $errors );

		$this->set( 'error', $error );

		$this->set( 'hasAvatar', $user->hasAvatar() );

		$this->set( 'defaultAvatar', rtrim( JURI::root() , '/' ) . Foundry::config()->get( 'avatars.default.' . $this->group . '.' . SOCIAL_AVATAR_SQUARE ) );

		// Display the output.
		return $this->display();
	}

	/**
	 * Performs validation checks when a user edits their profile
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onAdminEditValidate( &$post, &$user )
	{
		return true;
	}

	/**
	 * Performs validation checks when a user edits their profile
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onEditValidate( &$post, &$user )
	{
		$state 	= $this->validate( $post, $user );

		return $state;
	}

	/**
	 * Once a user edit is completed, the field should automatically
	 * move the temporary avatars into the user's folder if required.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onEditAfterSave( &$post, &$user )
	{
		$value = !empty( $post[ $this->inputName ] ) ? $post[ $this->inputName ] : '';

		if( !empty( $value ) )
		{
			$this->createAvatar( $value, $user->id );
		}

		unset( $post[ $this->inputName ] );
	}

	/**
	 * Performs validation checks when a user edits their profile
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function validate( &$post, $user = null )
	{
		$value = !empty( $post[ $this->inputName ] ) ? $post[ $this->inputName ] : '';

		if( ( empty( $user ) || !$user->hasAvatar() ) && $this->isRequired() && empty( $value ) )
		{
			$this->setError( JText::_( 'PLG_FIELDS_AVATAR_VALIDATION_EMPTY_PROFILE_PICTURE' ) );

			return false;
		}

		if( !empty( $value ) )
		{
			$value = Foundry::json()->decode( $value );

			if( ( empty( $user ) || !$user->hasAvatar() ) && $this->isRequired() && empty( $value->source ) )
			{
				$this->setError( JText::_( 'PLG_FIELDS_AVATAR_VALIDATION_EMPTY_PROFILE_PICTURE' ) );

				return false;
			}
		}

		return true;
	}

	public function createAvatar( $value, $uid )
	{
		$value = Foundry::makeObject( $value );

		if( !empty( $value->data ) )
		{
			$value->data = Foundry::makeObject( $value->data );
		}

		if( $value->type === 'remove' )
		{
			$table = Foundry::table( 'avatar' );
			$state = $table->load( array( 'uid' => $uid, 'type' => $this->group ) );

			if( $state )
			{
				$table->delete();
			}

			return true;
		}

		if( $value->type === 'gallery' )
		{
			$table = Foundry::table( 'avatar' );
			$state = $table->load( array( 'uid' => $uid, 'type' => $this->group ) );

			if( !$state )
			{
				$table->uid = $uid;
				$table->type = $this->group;
			}

			$table->avatar_id = $value->source;

			$table->store();

			return true;
		}

		if( $value->type === 'upload' )
		{
			$data = new stdClass();

			if( !empty( $value->path ) )
			{
				$image = Foundry::image();
				$image->load( $value->path );

				$avatar	= Foundry::avatar( $image, $uid, $this->group );

				// Check if there's a profile photos album that already exists.
				$albumModel	= Foundry::model( 'Albums' );

				// Retrieve the user's default album
				$album 	= $albumModel->getDefaultAlbum( $uid , $this->group , SOCIAL_ALBUM_PROFILE_PHOTOS );

				$photo 				= Foundry::table( 'Photo' );
				$photo->uid 		= $uid;
				$photo->type 		= $this->group;
				$photo->user_id 	= Foundry::user()->id;
				$photo->album_id 	= $album->id;
				$photo->title 		= $value->name;
				$photo->caption 	= '';
				$photo->ordering	= 0;

				// We need to set the photo state to "SOCIAL_PHOTOS_STATE_TMP"
				$photo->state 		= SOCIAL_PHOTOS_STATE_TMP;

				// Try to store the photo first
				$state 		= $photo->store();

				if( !$state )
				{
					$this->setError( JText::_( 'PLG_FIELDS_AVATAR_ERROR_CREATING_PHOTO_OBJECT' ) );
					return false;
				}

				// Push all the ordering of the photo down
				$photosModel = Foundry::model( 'photos' );
				$photosModel->pushPhotosOrdering( $album->id , $photo->id );

				// If album doesn't have a cover, set the current photo as the cover.
				if( !$album->hasCover() )
				{
					$album->cover_id 	= $photo->id;

					// Store the album
					$album->store();
				}

				// Get the photos library
				$photoLib 	= Foundry::get( 'Photos' , $image );
				$storage    = $photoLib->getStoragePath($album->id, $photo->id);
				$paths 		= $photoLib->create( $storage );

				// Create metadata about the photos
				foreach( $paths as $type => $fileName )
				{
					$meta 				= Foundry::table( 'PhotoMeta' );
					$meta->photo_id		= $photo->id;
					$meta->group 		= SOCIAL_PHOTOS_META_PATH;
					$meta->property 	= $type;
					$meta->value		= $storage . '/' . $fileName;

					$meta->store();
				}

				// Assign a badge for the user
				$photo->assignBadge( 'photos.upload' , $uid );

				// @points: photos.upload
				// Assign points when user uploads a new photo
				$photo->assignPoints( 'photos.upload' , $uid );

				// Synchronize Indexer
				$indexer 	= Foundry::get( 'Indexer' );
				$template	= $indexer->getTemplate();
				$template->setContent( $photo->title , $photo->caption );

				$url 	= FRoute::photos( array( 'layout' => 'item', 'id' => $photo->getAlias() ) );
				$url 	= '/' . ltrim( $url , '/' );
				$url 	= str_replace('/administrator/', '/', $url );

				$template->setSource( $photo->id , SOCIAL_INDEXER_TYPE_PHOTOS , $photo->uid , $url );
				$template->setThumbnail( $photo->getSource( 'thumbnail' ) );

				$indexer->index( $template );

				// Crop the image to follow the avatar format. Get the dimensions from the request.
				if( !empty( $value->data ) && is_object( $value->data ) )
				{
					$width = $value->data->width;
					$height = $value->data->height;
					$top = $value->data->top;
					$left = $value->data->left;

					$avatar->crop( $top , $left , $width , $height );
				}

				// Create the avatars now
				$avatar->store( $photo );
			}

			return true;
		}
	}

	/**
	 * Displays the sample html codes when the field is added into the profile.
	 *
	 * @since	1.0
	 * @access	public
	 * @return	string	The html output.
	 *
	 * @author	Jason Rey <jasonrey@stackideas.com>
	 */
	public function onSample()
	{
		$id = JRequest::getInt( 'id' );

		$model 		= Foundry::model( 'Avatars' );
		$avatars 	= $model->getDefaultAvatars( $id );

		$this->set( 'avatars', $avatars );

		$this->set( 'defaultAvatar', rtrim( JURI::root() , '/' ) . Foundry::config()->get( 'avatars.default.' . $this->group . '.' . SOCIAL_AVATAR_SQUARE ) );

		return $this->display();
	}

	public function onOAuthGetUserMeta( &$details, &$client )
	{
		// Future's sake, check client name through $client

		$config = Foundry::config();

		if( $config->get( 'oauth.facebook.registration.avatar' ) )
		{
			$avatar = $client->api( 'me/picture', array( 'type' => 'large', 'redirect' => false ) );
			$avatarUrl = $avatar['data']['url'];

			$details['avatar'] = $avatarUrl;
		}
	}
}
