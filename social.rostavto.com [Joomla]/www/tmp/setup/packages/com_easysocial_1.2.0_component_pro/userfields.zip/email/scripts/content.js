EasySocial.module('fields/user/email/content', function($) {
	var module = this;

	EasySocial
		.require()
		.language('PLG_FIELDS_EMAIL_VALIDATION_REQUIRED')
		.done(function($) {
			EasySocial.Controller(
				'Field.Email',
				{
					defaultOptions:
					{
						required		: false,

						"{field}"		: "[data-field-email]",

						"{input}"		: "[data-field-email-input]"
					}
				},
				function( self )
				{
					return {
						init: function() {
						},

						validateInput: function() {
							var value 	= self.input().val();

							if($.isEmpty(value)) {
								self.raiseError($.language('PLG_FIELDS_EMAIL_VALIDATION_REQUIRED'));
								return false;
							}

							return true;
						},

						raiseError: function(msg) {
							self.trigger('error', [msg]);
						},

						clearError: function() {
							self.trigger('clear');
						},

						"{self} onSubmit": function(el, event, register) {

							if(!self.options.required) {
								register.push(true);
								return;
							}

							register.push(self.validateInput());

							return;
						}
					}
				});

			module.resolve();
		});
});
