<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die( 'Unauthorized Access');

// Include the fields library
Foundry::import('admin:/includes/fields/fields');

class SocialFieldsUserMultitextbox extends SocialFieldItem
{
	public function onRegister(&$post, &$registration)
	{
		$value = !empty($post[$this->inputName]) ? $post[$this->inputName] : '';

		$error	= $registration->getErrors( $this->inputName );

		$this->set( 'error', $error );

		return $this->onOutput($value);
	}

	public function onRegisterValidate(&$post)
	{
		return $this->onValidate($post);
	}

	public function onRegisterBeforeSave(&$post)
	{
		return $this->onBeforeSave($post);
	}

	public function onEdit(&$post, &$user, $errors)
	{
		$value = !empty($post[$this->inputName]) ? $post[$this->inputName] : $this->value;

		$error = $this->getError($errors);

		$this->set('error', $error);

		return $this->onOutput($value);
	}

	public function onEditValidate(&$post)
	{
		return $this->onValidate($post);
	}

	public function onEditBeforeSave(&$post)
	{
		return $this->onBeforeSave($post);
	}

	public function onSample()
	{
		return $this->display();
	}

	public function onDisplay($user)
	{
		if (empty($this->value))
		{
			return;
		}

		if( !$this->allowedPrivacy( $user ) )
		{
			return;
		}

		$value = Foundry::json()->decode($this->value);

		if (!is_array($value) || empty($value))
		{
			return;
		}

		$this->set('value', $value);

		return $this->display();
	}

	private function onOutput($value)
	{
		$count = 0;

		if (!empty($value))
		{
			$value = Foundry::json()->decode($value);

			$count = count($value);
		}
		else
		{
			$value = array();
		}

		$this->set('value', $value);

		$this->set('count', $count);

		$limit = $this->params->get('max', 0);

		$this->set('limit', $limit);

		return $this->display();
	}

	private function onValidate(&$post)
	{
		if (!$this->isRequired())
		{
			return true;
		}

		if (empty($post[$this->inputName]))
		{
			$this->setError(JText::_('PLG_FIELDS_MULTITEXTBOX_VALIDATION_REQUIRED_FIELD'));
			return false;
		}

		$json = Foundry::json();

		$value = $json->decode($post[$this->inputName]);

		if (!is_array($value) || empty($value))
		{
			$this->setError(JText::_('PLG_FIELDS_MULTITEXTBOX_VALIDATION_REQUIRED_FIELD'));
			return false;
		}

		foreach ($value as $v)
		{
			$v = trim($v);

			if (!empty($v))
			{
				return true;
			}
		}

		$this->setError(JText::_('PLG_FIELDS_MULTITEXTBOX_VALIDATION_REQUIRED_FIELD'));
		return false;
	}

	private function onBeforeSave(&$post)
	{
		if (empty($post[$this->inputName]))
		{
			unset($post[$this->inputName]);
			return true;
		}

		$json = Foundry::json();

		$value = $json->decode($post[$this->inputName]);

		if (!is_array($value) || empty($value))
		{
			unset($post[$this->inputName]);
			return true;
		}

		$result = array();

		foreach ($value as $v)
		{
			$v = trim($v);
			if (!empty($v))
			{
				$result[] = $v;
			}
		}

		if (empty($result))
		{
			unset($post[$this->inputName]);
			return true;
		}

		$post[$this->inputName] = $json->encode($result);

		return true;
	}
}
