<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

Foundry::import('admin:/includes/fields/dependencies');

class SocialFieldsUserText extends SocialFieldItem
{
	public function onRegister()
	{
		$text = $this->params->get( 'text' );

		if (empty($text))
		{
			return;
		}

		$string = Foundry::string();

		if ($this->params->get('bbcode'))
		{

			$text = $string->parseBBCode($text);
		}
		else
		{
			$text = $string->escape($text);
		}

		$this->set('text', $text);

		return $this->display();
	}

	public function onEdit()
	{
		$text = $this->params->get( 'text' );

		if (empty($text))
		{
			return;
		}

		$string = Foundry::string();

		if ($this->params->get('bbcode'))
		{

			$text = $string->parseBBCode($text);
		}
		else
		{
			$text = $string->escape($text);
		}

		$this->set('text', $text);

		return $this->display();
	}

	public function onSample()
	{
		$text = $this->params->get( 'text' );

		$string = Foundry::string();

		if ($this->params->get('bbcode'))
		{

			$text = $string->parseBBCode($text);
		}
		else
		{
			$text = $string->escape($text);
		}

		$this->set('text', $text);

		return $this->display();
	}

	public function onDisplay()
	{
		$text = $this->params->get( 'text' );

		if (empty($text))
		{
			return;
		}

		$string = Foundry::string();

		if ($this->params->get('bbcode'))
		{

			$text = $string->parseBBCode($text);
		}
		else
		{
			$text = $string->escape($text);
		}

		$this->set('text', $text);

		return $this->display();
	}
}
