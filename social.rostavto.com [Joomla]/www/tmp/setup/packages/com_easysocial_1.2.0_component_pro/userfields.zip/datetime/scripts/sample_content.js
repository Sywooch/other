EasySocial.module('fields/user/datetime/sample_content', function($) {
	var module = this;

	EasySocial.require().library('ui/datepicker').done(function() {
		EasySocial.Controller('Field.Datetime.Sample', {
			defaultOptions: {
				'{withCalendar}'	: '[data-with-calendar]',
				'{withoutCalendar}'	: '[data-without-calendar]',

				'{yearPrivacy}'		: '[data-yearprivacy]',

				'{dateFormat}'		: '[data-without-calendar-format]',

				'{date}'			: '[data-field-datetime-select]'
			}
		}, function(self) {
			return {
				init: function() {
					self.date().datepicker({
						changeMonth: true,
						changeYear: true
					});
				},

				'{self} onConfigChange': function(el, event, name, value) {
					switch(name) {
						case 'calendar':
							self.withCalendar().toggle(value);
							self.withoutCalendar().toggle(!value);
						break;

						case 'date_format':
							self.dateFormat().hide();
							self.dateFormat().eq(parseInt(value) - 1).show();
						break;

						case 'year_privacy':
							self.yearPrivacy().toggle(value);
						break;
					}
				}
			}
		});

		module.resolve();
	});
});
