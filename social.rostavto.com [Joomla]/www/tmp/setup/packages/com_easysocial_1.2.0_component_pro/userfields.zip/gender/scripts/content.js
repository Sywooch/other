EasySocial.module('fields/user/gender/content', function($) {
	var module = this;

	EasySocial
		.require()
		.language('PLG_FIELDS_GENDER_VALIDATION_GENDER_REQUIRED')
		.done(function($) {
			EasySocial.Controller(
				'Field.Gender',
				{
					defaultOptions:
					{
						required 		: false,

						"{field}"		: "[data-field-gender]",

						"{input}"		: "[data-field-gender-input]"
					}
				},
				function( self )
				{
					return {
						init : function()
						{
						},

						validateInput: function() {
							if(!self.options.required) {
								return true;
							}

							self.clearError();

							var value = self.input().val();

							if(value === 'null' || $.isEmpty(value))
							{
								self.raiseError();
								return false;
							}

							return true;
						},

						raiseError: function() {
							self.trigger('error', [$.language('PLG_FIELDS_GENDER_VALIDATION_GENDER_REQUIRED')]);
						},

						clearError: function() {
							self.trigger('clear');
						},

						"{input} change": function(el, event) {
							self.validateInput();
						},

						"{self} onSubmit": function(el, event, register) {
							register.push(self.validateInput());
						}
					}
				});

			module.resolve();
		});
});
