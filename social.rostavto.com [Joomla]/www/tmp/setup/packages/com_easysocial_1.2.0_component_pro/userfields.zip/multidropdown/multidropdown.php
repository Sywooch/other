<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

// Include the fields library
Foundry::import('admin:/includes/fields/fields');

class SocialFieldsUserMultidropdown extends SocialFieldItem
{
	public function onRegister(&$post, &$registration)
	{
		$error = $registration->getErrors($this->inputName);

		$this->set('error', $error);

		$value = !empty($post[$this->inputName]) ? $post[$this->inputName] : '';

		return $this->onOutput($value);
	}

	public function onRegisterValidate(&$post)
	{
		return $this->onValidate($post);
	}

	public function onRegisterBeforeSave(&$post)
	{
		return $this->onBeforeSave($post);
	}

	public function onEdit(&$post, &$user, $errors)
	{
		$error = $this->getError($errors);

		$this->set('error', $error);

		$value = !empty($post[$this->inputName]) ? $post[$this->inputName] : $this->value;

		return $this->onOutput($value);
	}

	public function onEditValidate(&$post)
	{
		return $this->onValidate($post);
	}

	public function onEditBeforeSave(&$post)
	{
		return $this->onBeforeSave($post);
	}

	public function onSample()
	{
		$choices = array((object) array('value' => '', 'title' => JText::_( 'PLG_FIELDS_MULTIDROPDOWN_SELECT_A_VALUE')));

		$this->set('choices', $choices);

		return $this->display();
	}

	public function onDisplay($user)
	{
		if (empty($this->value))
		{
			return;
		}

		if( !$this->allowedPrivacy($user))
		{
			return;
		}

		$json = Foundry::json();

		$result = $json->decode($this->value);

		if (!is_array($result) || empty($result))
		{
			return;
		}

		$values = array();

		foreach ($result as $r)
		{
			$option = Foundry::table('fieldoptions');
			$option->load( array( 'parent_id' => $this->field->id, 'key' => 'items', 'value' => $r ) );

			$values[] = $option;
		}

		$this->set('values', $values);

		return $this->display();
	}

	private function onOutput($value)
	{
		$json = Foundry::json();

		$value = $json->decode($value);

		if (!is_array($value))
		{
			$value = array();
		}

		$choices = $this->params->get('items');

		if (!is_array($choices))
		{
			$choices = array();
		}

		array_unshift($choices, (object) array('value' => '', 'title' => JText::_( 'PLG_FIELDS_MULTIDROPDOWN_SELECT_A_VALUE')));

		$limit = $this->params->get('max');

		$count = count($value);

		$this->set(
			array(
				'choices' => $choices,
				'limit' => $limit,
				'count' => $count,
				'value' => $value
			)
		);

		return $this->display();
	}

	private function onValidate($post)
	{
		if (!$this->isRequired())
		{
			return true;
		}

		if (empty($post[$this->inputName]))
		{
			$this->setError(JText::_('PLG_FIELDS_MULTIDROPDOWN_VALIDATION_REQUIRED_FIELD'));
			return false;
		}

		$json = Foundry::json();

		$value = $json->decode($post[$this->inputName]);

		if (!is_array($value) || empty($value))
		{
			$this->setError(JText::_('PLG_FIELDS_MULTIDROPDOWN_VALIDATION_REQUIRED_FIELD'));
			return false;
		}

		foreach ($value as $v)
		{
			if (!empty($v))
			{
				return true;
			}
		}

		$this->setError(JText::_('PLG_FIELDS_MULTIDROPDOWN_VALIDATION_REQUIRED_FIELD'));
		return false;
	}

	private function onBeforeSave($post)
	{
		if (empty($post[$this->inputName]))
		{
			unset($post[$this->inputName]);
			return true;
		}

		$json = Foundry::json();

		$value = $json->decode($post[$this->inputName]);

		if (!is_array($value) || empty($value))
		{
			unset($post[$this->inputName]);
			return true;
		}

		$result = array();

		foreach ($value as $v)
		{
			if (!empty($v))
			{
				$result[] = $v;
			}
		}

		$post[$this->inputName] = $result;

		return true;
	}
}
