<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppBadges extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Responsible to generate the activity contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'badges' )
		{
			return;
		}

		// Get the context id.
		$id 		= $item->contextId;

		// Get the actor
		$actor 		= $item->actor;

		// Get the badge
		$badge 		= Foundry::table( 'Badge' );
		$badge->load( $id );

		$this->set( 'badge' , $badge );
		$this->set( 'actor' , $actor );

		$item->title 	= parent::display( 'logs/' . $item->verb );

		if( $includePrivacy )
		{
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			// item->uid is now streamitem.id
			$item->privacy 	= $privacy->form( $item->uid , SOCIAL_TYPE_ACTIVITY, $item->actor->id, 'core.view' );
		}

		return true;
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'badges' )
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$uid		= $item->id;
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			if( $aItem )
			{
				$uid 	= $aItem[0]->id;

				if( !$privacy->validate( 'core.view', $uid , SOCIAL_TYPE_ACTIVITY , $item->actor_id ) )
				{
					$item->cnt = 0;
				}
			}
		}

		return true;
	}

	public function onStreamValidatePrivacy( SocialStreamItem $item )
	{
		$my 		= Foundry::user();
		$privacy	= Foundry::privacy( $my->id );

		$tbl		= Foundry::table( 'StreamItem' );
		$tbl->load( array('uid' => $item->uid ) );

		if(! $privacy->validate( 'core.view', $tbl->id , SOCIAL_TYPE_ACTIVITY, $item->actor->id ) )
		{
			return false;
		}

		return true;
	}

	/**
	 * Responsible to generate the stream contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareStream( SocialStreamItem &$item )
	{
		// Load up the config object
		$config 	= Foundry::config();

		if( $item->context != 'badges' || !$config->get( 'badges.enabled' ) )
		{
			return;
		}

		// Check if the app should be able to generate the stream.
		$params 	= $this->getParams();

		if( !$params->get( 'stream_achieved' , true ) )
		{
			return;
		}

		// Test if stream item is allowed
		if( !$this->onStreamValidatePrivacy( $item ) )
		{
			return;
		}

		// Get the actor
		$actor 		= $item->actor;

		// Try to get the badge object from the params
		$raw 		= $item->params;
		$badge 		= Foundry::table( 'Badge' );

		if( $raw )
		{
			$obj 	= Foundry::makeObject( $raw );

			$badge->bind( $obj );
		}
		else
		{
			$badge->load( $item->contextId );
		}

		// Set the display mode to be full.
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#FEBC9D';
		$item->fonticon = 'ies-crown';
		$item->label 	= JText::_( 'APP_USER_BADGES_STREAM_TOOLTIP' );

		$this->set( 'badge' , $badge );
		$this->set( 'actor' , $actor );


		$item->title 	= parent::display( 'streams/' . $item->verb . '.title' );
		$item->content	= parent::display( 'streams/' . $item->verb . '.content' );

		return true;
	}
}
