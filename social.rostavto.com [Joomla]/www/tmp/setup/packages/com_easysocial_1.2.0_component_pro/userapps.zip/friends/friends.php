<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppFriends extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Notification triggered when generating notification item.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialTableNotification	The notification table object
	 * @return	null
	 */
	public function onNotificationLoad( &$item )
	{
		switch( $item->cmd )
		{
			case 'approved':

				// Retrieve the target user.
				$user			= Foundry::user( $item->uid );
				$item->title 	= JText::sprintf( 'APP_FRIENDS_NOTIFICATION_APPROVED' , $user->getName() );

				break;
		}
	}

	/**
	 * Responsible to generate the activity contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'friends' )
		{
			return;
		}

		// Get the context id.
		// $id 		= $item->contextId;

		// Get the actor
		$actor 		= array( $item->actor );

		// Set the actor for the themes.
		$this->set( 'actor' , $actor );

		// no target. this could be data error. ignore this item.
		if(! $item->targets )
			return;

		// Receiving actor.
		// $target		= $item->targets[0]; //Foundry::user( $id );
		$target		= $item->targets;


		// Set the target.
		$this->set( 'target'	, $target );

		// If the current viewer is part of this stream, it should contain "You"
		$my = Foundry::user();

		$me 		= ( $my->id == $item->actor->id ) ? true : false ;
		$this->set( 'me' , $me );
		// User A made friends with user B
		if( $item->verb == 'add' )
		{
			$item->display	= SOCIAL_STREAM_DISPLAY_MINI;
			$item->title 	= parent::display( 'streams/' . $item->verb . '.title' );
		}

		if( $includePrivacy )
		{
			$privacy	= Foundry::privacy( $my->id );
			$item->privacy 	= $privacy->form( $item->contextId , 'friends', $item->actor->id, 'core.view' );
		}

		return true;
	}


	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'friends' )
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			$contextId = $aItem[0]->context_id;

			if( !$privacy->validate( 'core.view', $contextId, 'friends', $item->actor_id ) )
			{
				$item->cnt = 0;
			}

		}

		return true;
	}


	/**
	 * Responsible to generate the stream contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'friends' )
		{
			return;
		}

		$my         = Foundry::user();
		$privacy	= Foundry::privacy( $my->id );

		if( $includePrivacy )
		{
			if(! $privacy->validate( 'core.view', $item->contextId, 'friends', $item->actor->id ) )
			{
				return;
			}
		}

		// Get the context id.
		$id 		= $item->contextId;

		// Get the actor
		$actor 		= array( $item->actor );

		// no target. this could be data error. ignore this item.
		if(! $item->targets )
		{
			return;
		}

		// Determines if the stream should be generated
		$params 	= $this->getParams();

		if( !$params->get( 'stream_friends' , true ) )
		{
			return;
		}
		
		// Receiving actor.
		$target		= $item->targets;

		// Get the current view.
		$view 		= JRequest::getVar( 'view' );

		// Get the current id.
		$id 		= JRequest::getInt( 'id' );

		// If the current viewer is part of this stream, it should contain "You"
		$me 		= false;
		$swap 		= false;

		if( count( $item->targets ) > 0 )
		{
			$tmp = array();
			foreach( $item->targets as $user )
			{
				if( $user->id == $my->id )
				{
					$swap   = true;
				}
				else
				{
					$tmp[] = $user;
				}
			}

			if( $swap )
			{
				array_unshift( $tmp, $my );
				$item->targets = $tmp;
			}
		}

		// Decorate the stream
		$item->display		= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 		= '#7AD7EE';
		$item->fonticon		= 'ies-user';
		$item->label 		= JText::_( 'APP_USER_FRIENDS_STREAM_TOOLTIP' );

		// Apply likes on the stream
		$likes 			= Foundry::likes();
		$likes->get( $item->contextId , $item->context );
		$item->likes	= $likes;

		if( $swap )
		{
			$target = $actor;
			$actor 	= $item->targets;
			$me  	= true;
		}
		else
		{
			if( count( $actor ) == 1 && $actor[0]->id == $my->id )
			{
				$me = true;
			}
		}

		// If a user's profile is being viewed, we don't want to show "You"
		if( $view == 'profile' )
		{
			$me 	= false;
		}

		$actorString 	= Foundry::get( 'String' )->namesToStream( $actor, true, 1, true, false, true );
		$targetString 	= Foundry::get( 'String' )->namesToStream( $target, true, 1, true, false, true  );
		$term 			= JText::_( 'APP_FRIENDS_STREAM_IS_NOW_FRIENDS' );

		if( $me || count( $actor ) > 1 )
		{
			$term	= JText::_( 'APP_FRIENDS_STREAM_ARE_NOW_FRIENDS' );
		}

		$this->set( 'term'		, $term );
		$this->set( 'actorString' , $actorString );
		$this->set( 'targetString', $targetString );
		$this->set( 'actor' 	, $actor );
		$this->set( 'target'	, $target );
		$this->set( 'me' 		, $me );

		$item->title 	= parent::display( 'streams/' . $item->verb . '.title' );

		if( $includePrivacy )
		{
			$item->privacy 	= $privacy->form( $item->contextId , 'friends', $item->actor->id, 'core.view' );
		}

		return true;
	}

	/**
	 * Processes a saved story so that we can notify users who are tagged in the system
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onAfterStorySave( &$stream , $streamItem , $streamTemplate )
	{
		// If there's no "with" data, skip this.
		if( !$streamTemplate->with )
		{
			return;
		}

		// Get list of users that are tagged in this post.
		$taggedUsers 	= $streamTemplate->with;

		// Get the creator of this update
		$poster 		= Foundry::user( $streamTemplate->actor_id );

		// Get the permalink to the stream item
		$permalink 			= $streamItem->getPermalink();
		$permalinkEmail 	= $streamItem->getPermalink( true, true );

		// Get the content of the stream item.
		$content 		= $streamTemplate->content;

		foreach( $taggedUsers as $id )
		{
			$taggedUser 	= Foundry::user( $id );

			// Set the email title
			$emailTitle		= JText::sprintf( 'COM_EASYSOCIAL_EMAILS_TITLE_TAGGED_IN_POST' , $poster->getName() );

			// Determine if this user is involved in this or the user created this item.
			$mailParams 	= array();

			$mailParams[ 'posterName' ]		= $poster->getName();
			$mailParams[ 'posterAvatar' ]	= $poster->getAvatar( SOCIAL_AVATAR_LARGE );
			$mailParams[ 'posterLink' ]		= $poster->getPermalink( true, true );
			$mailParams[ 'permalink' ]		= $permalinkEmail;
			$mailParams[ 'content' ]		= $content;

			$systemOptions 	= array(
									'type' 			=> 'stream',
									'context_type'	=> 'tagged',
									'url' 			=> $permalink,
									'actor_id' 		=> $poster->id,
									'uid' 			=> $streamItem->id,
									'aggregate' 	=> false,
								);

			// Add new notification item
			$state 			= Foundry::notify(	'stream.tagged' ,  array( $taggedUser->id ) , array( 'title' => $emailTitle , 'params' => $mailParams , 'template' => 'site/stream/tagged' ), $systemOptions );
		}

		return true;
	}
}
