<?php
/**
* @package 		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license 		Proprietary Use License http://stackideas.com/licensing.html
* @author 		Stack Ideas Sdn Bhd
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<?php echo JText::sprintf( 'APP_USER_KUNENA_STREAM_REPLY' , $this->html( 'html.user' , $actor->id ) , '<a href="' . $topic->getUrl() . '">' . $topic->subject . '</a>' , '<a href="' . $topic->getCategory()->getUrl() . '">' . $topic->getCategory()->name ); ?>