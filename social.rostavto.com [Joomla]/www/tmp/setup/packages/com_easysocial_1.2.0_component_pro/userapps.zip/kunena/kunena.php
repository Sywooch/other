<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppKunena extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Determines if Kunena is installed on the site.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function exists()
	{
		$file = JPATH_ADMINISTRATOR . '/components/com_kunena/api.php';

		if( !JFile::exists( $file ) )
		{
			return false;
		}

		// Load Kunena's api file
		require_once( $file );

		// Load Kunena's language
		KunenaFactory::loadLanguage( 'com_kunena.libraries' , 'admin' );

		return true;
	}

	public function createParent( $messageId = null )
	{
		$parent = new stdClass();
		$parent->forceSecure	= true;
		$parent->forceMinimal	= false;


		if( $messageId )
		{
			$message 	= KunenaForumMessage::getInstance( $messageId );

			$parent->attachments 	= $message->getAttachments();
		}

		return $parent;
	}


	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'kunena')
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$uid		= $item->id;
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			if( $aItem )
			{
				$uid 	= $aItem[0]->id;

				if( !$privacy->validate( 'core.view', $uid , SOCIAL_TYPE_ACTIVITY , $item->actor_id ) )
				{
					$item->cnt = 0;
				}
			}
		}

		return true;
	}

	/**
	 * Prepares the stream item
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{

		if( $item->context != 'kunena' )
		{
			return;
		}

		// Test if Kunena exists;
		if( !$this->exists() )
		{
			return;
		}

		$verb	 	= $item->verb;

		// Decorate the stream
		$item->display 		= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 		= '#6f90b5';
		$item->fonticon		= 'ies-comments-2';
		$item->label 		= JText::_( 'APP_USER_KUNENA_STREAM_TITLE' );

		// Get app params
		$params		= $this->getParams();

		// New forum posts
		if( $verb == 'create' && $params->get( 'stream_create' , true ) )
		{
			$this->processNewTopic( $item , $includePrivacy );
		}

		if( $verb == 'reply' && $params->get( 'stream_reply' , true ) )
		{
			$this->processReply( $item , $includePrivacy );
		}

		if( $verb == 'thanked' && $params->get( 'stream_thanked' , true ) )
		{
			$this->processThanked( $item , $includePrivacy );
		}

		$element		= $item->context;
		$uid     		= $item->contextId;

		if( $includePrivacy )
		{
			$my 		= Foundry::user();
			$privacy 	= Foundry::privacy( $my->id );
			$item->privacy 	= $privacy->form( $uid, $element, $item->actor->id, 'core.view' );
		}
	}

	/**
	 * Processes the stream item for new topics
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item object
	 * @param	bool				Determine if we should include the privacy or not.
	 * @return
	 */
	private function processNewTopic( &$item , $includePrivacy = true )
	{
		// $topic 	= KunenaForumTopicHelper::getTopics( array( $item->contextId ) );
		// $topic 	= $topic[ key($topic) ];

		$topic = KunenaForumTopicHelper::get( $item->contextId );

		// Apply likes on the stream
		$likes 				= Foundry::likes()->get( $item->contextId , 'kunena-create' );
		$item->likes		= $likes;

		// Apply comments on the stream
		$comments			= Foundry::comments( $item->contextId , 'kunena-create' , SOCIAL_APPS_GROUP_USER );
		$item->comments 	= $comments;

		// Set the actor
		$actor 			= $item->actor;

		JFactory::getLanguage()->load( 'com_kunena' , JPATH_ROOT );

		$parent 	= $this->createParent( $topic->first_post_id );

		$topic->message 	= KunenaHtmlParser::parseBBCode( $topic->first_post_message , $parent , 250 );
		$topic->message		= $this->filterContent( $topic->message );

		$this->set( 'actor'	, $actor );
		$this->set( 'topic' , $topic );

		$item->title	= parent::display( 'streams/' . $item->verb . '.title' );
		$item->content	= parent::display( 'streams/' . $item->verb . '.content' );

	}

	/**
	 * Processes the stream item for new topics
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item object
	 * @param	bool				Determine if we should include the privacy or not.
	 * @return
	 */
	private function processReply( &$item , $includePrivacy = true )
	{
		$message 	= KunenaForumMessageHelper::get( $item->contextId );
		$topic 		= $message->getTopic();

		// Apply likes on the stream
		$likes 			= Foundry::likes()->get( $item->contextId , 'kunena-reply' );
		$item->likes	= $likes;

		// Apply comments on the stream
		$comments			= Foundry::comments( $item->contextId , 'kunena-reply' , SOCIAL_APPS_GROUP_USER );
		$item->comments 	= $comments;

		// Set the actor
		$actor 			= $item->actor;
		$parent 		= $this->createParent( $message->id );

		$message->message	= KunenaHtmlParser::parseBBCode( $message->message , $parent , 250 );
		$message->message	= $this->filterContent( $message->message );

		$this->set( 'actor'	, $actor );
		$this->set( 'topic' , $topic );
		$this->set( 'message' , $message );

		$item->title	= parent::display( 'streams/' . $item->verb . '.title' );
		$item->content	= parent::display( 'streams/' . $item->verb . '.content' );
	}

	/**
	 * Processes the stream item for new thanks
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item object
	 * @param	bool				Determine if we should include the privacy or not.
	 * @return
	 */
	private function processThanked( &$item , $includePrivacy = true )
	{
		$message 	= KunenaForumMessageHelper::get( $item->contextId );
		$topic 		= $message->getTopic();

		// Apply likes on the stream
		$likes 			= Foundry::likes()->get( $item->contextId , 'kunena-reply' );
		$item->likes	= $likes;

		// Apply comments on the stream
		$comments			= Foundry::comments( $item->contextId , 'kunena-reply' , SOCIAL_APPS_GROUP_USER );
		$item->comments 	= $comments;

		// Define standard stream looks
		$item->display 	= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 	= '#6f90b5';

		// Set the actor
		$actor 			= $item->actor;
		$target 		= $item->targets[0];

		$parent 		= $this->createParent( $message->id );
		$message->message	= KunenaHtmlParser::parseBBCode( $message->message , $parent , 250 );
		$message->message	= $this->filterContent( $message->message );

		$this->set( 'actor'	, $actor );
		$this->set( 'target', $target );
		$this->set( 'topic' , $topic );
		$this->set( 'message' , $message );

		$item->title	= parent::display( 'streams/' . $item->verb . '.title' );
	}

	private function filterContent( $content )
	{
		/*
		 * temporary fix to prevent email cloaking causing ajax to failed.
		 *
		 */
		$content = strip_tags( $content );

		return $content;
	}

	/**
	 * Prepares the activity log
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
	}


}
