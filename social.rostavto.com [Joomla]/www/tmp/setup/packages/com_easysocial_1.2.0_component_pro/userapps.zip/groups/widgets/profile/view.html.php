<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

/**
 * Displays the groups widget in a profile
 *
 * @since	1.2
 * @access	public
 */
class GroupsWidgetsProfile extends SocialAppsWidgets
{
	/**
	 * Display groups as a widget
	 *
	 * @since	1.2
	 * @access	public
	 * @param	Socialuser
	 * @return
	 */
	public function sidebarBottom( $user )
	{
		$params 	= $this->getParams();

		if( $params->get( 'widget_profile' , true ) )
		{
			echo $this->getGroups( $user );
		}
	}

	/**
	 * Retrieves the list of groups
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return	
	 */
	public function getGroups( $user )
	{
		$model 		= Foundry::model( 'Groups' );
		$groups 	= $model->getGroups( array( 'uid' => $user->id ) );

		// Get the total groups the user owns
		$total 		= $user->getTotalGroups();

		$theme 		= Foundry::themes();
		$theme->set( 'groups'	, $groups );
		$theme->set( 'total' 	, $total );

		return $theme->output( 'themes:/apps/user/groups/widgets/profile/groups' );
	}
}
