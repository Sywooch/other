<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/group/group' );

/**
 * Groups application for EasySocial
 * @since	1.2
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppGroups extends SocialAppItem
{
	/**
	 * Class constructor
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}


	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'groups' )
		{
			return;
		}

		$groupId 	= $item->contextId;
		$group 		= Foundry::group( $groupId );

		if( !$group )
		{
			return;
		}


		$item->display	= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 	= '#2980b9';
		$item->icon 	= '<i class="ies-users" data-original-title="' . JText::_( 'APP_GROUPS_GROUPS_STREAM_TOOLTIP' ) . '" data-es-provide="tooltip"></i>';



		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );


		$item->title 	= parent::display( 'streams/' . $item->verb . '.title' );

		return true;
	}

	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'groups' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}


	/**
	 * Trigger for onPrepareStream
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		// We only want to process related items
		if( $item->context != 'groups' )
		{
			return;
		}

		// Get the group object
		$params 	= Foundry::registry( $item->params );
		$obj 		= $params->get( 'group' );

		if( $obj )
		{
			$group 	= new SocialGroup();
			$group->bind( $obj );			
		}
		else
		{
			$group	= Foundry::group( $item->contextId );
		}

		// If we can't find the group, skip this.
		if( !$group )
		{
			return;
		}

		// Determines if the user can view this group item.
		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE && !$group->isMember() )
		{
			return;
		}

		// Get the app params so that we determine which stream should be appearing
		$app 	= $this->getApp();
		$params	= $app->getParams();

		$item->display	= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 	= '#303229';
		$item->fonticon	= 'ies-users';
		$item->label	= JText::_( 'APP_USER_GROUPS_STREAM_TOOLTIP' );

		// Display stream item for new member join
		if( $item->verb == 'join' && $params->get( 'stream_join' ) )
		{
			$this->prepareJoinStream( $item , $group );
		}

		// Display stream item if member leaves a group
		if( $item->verb == 'leave' && $params->get( 'stream_leave' ) )
		{
			$this->prepareLeaveStream( $item , $group );
		}

		// Display stream item for new group creation
		if( $item->verb == 'create' && $params->get( 'stream_create' ) )
		{
			$this->prepareCreateStream( $item , $group );
		}

		// Display stream item when a member is promoted to be a group admin
		if( $item->verb == 'makeadmin' && $params->get( 'stream_admin' ) )
		{
			$this->prepareMakeAdminStream( $item , $group );
		}

		if( $item->verb == 'update' && $params->get( 'stream_update' ) )
		{
			$this->prepareUpdateStream( $item , $group );
		}
	}

	private function prepareUpdateStream( SocialStreamItem &$item , $group )
	{
		// We want a full display for group creation.
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;

		// Get the actor
		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/update.title' );
		$item->content 	= parent::display( 'streams/content' );
	}

	private function prepareLeaveStream( SocialStreamItem &$item , $group )
	{
		// We want a full display for group creation.
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;

		// Get the actor
		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/leave.title' );
		$item->content 	= parent::display( 'streams/content' );
	}

	private function prepareMakeAdminStream( SocialStreamItem &$item , $group )
	{
		// Get the actor
		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/admin.title' );
	}

	private function prepareJoinStream( SocialStreamItem &$item , SocialGroup $group )
	{
		// We want a full display for group creation.
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;

		// Get the actor
		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/join.title' );
		$item->content	= parent::display( 'streams/content' );
	}

	private function prepareCreateStream( SocialStreamItem &$item , SocialGroup $group )
	{
		// We want a full display for group creation.
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;

		// Get the actor.
		$actor	 		= $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/create.title' );
		$item->content	= parent::display( 'streams/content' );
	}
}
