<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="es-widget widget-groups">
	<div class="es-widget-head">
		<div class="pull-left widget-title">
			<?php echo JText::_( 'APP_USER_GROUPS_WIDGET_GROUPS_TITLE' ); ?>
		</div>
		<span class="widget-label">( <?php echo $total; ?> )</span>
	</div>
	<div class="es-widget-body">
		<ul class="widget-list fd-nav fd-nav-stacked">
			<?php if( $groups ){ ?>
				<?php foreach( $groups as $group ){ ?>
				<li>
					<div>
						<img class="pull-left mr-10 es-avatar" src="<?php echo $group->getAvatar();?>" alt="<?php echo $this->html( 'string.escape' , $group->getName() );?>" />
						<?php echo $this->html( 'html.group' , $group->id ); ?>
					</div>

					<div class="fd-small group-meta">
						<a href="#"><i class="ies-users"></i> <?php echo JText::sprintf( Foundry::string()->computeNoun( 'COM_EASYSOCIAL_GROUPS_MEMBERS' , $group->getTotalMembers() ) , $group->getTotalMembers() );?></a>
					</div>
				</li>
				<?php } ?>
			<?php } else { ?>
				<li class="empty fd-small">
					<?php echo JText::_( 'APP_USER_GROUPS_WIDGET_NO_GROUPS_YET' );?>
				</li>
			<?php } ?>
		</ul>
	</div>
</div>
