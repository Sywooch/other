<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Followers application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppFollowers extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	public function hasActivityLog()
	{
		$config 	= Foundry::config();

		if( !$config->get( 'followers.enabled' ) )
		{
			return false;
		}

		return true;
	}

	/**
	 * Responsible to generate the activity logs.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != SOCIAL_TYPE_FOLLOWERS )
		{
			return;
		}

		$my         = Foundry::user();
		$privacy	= Foundry::privacy( $my->id );


		// Get the context id.
		$id 		= $item->contextId;

		// Get the target.
		$table 		= Foundry::table( 'Subscription' );
		$table->load( $id );

		// Get the actor
		$actor 		= $item->actor;

		// Receiving actor.
		$target		= Foundry::user( $table->uid );

		// If the current viewer is part of this stream, it should contain "You"
		$me 		= '';

		$me 	= $my->id == $actor->id ? 'actor' : $me;
		$me 	= $my->id == $target->id ? 'target' : $me;

		$this->set( 'actor'		, $actor );
		$this->set( 'target'	, $target );
		$this->set( 'me' 		, $me );

		$item->title 	= parent::display( 'logs/' . $item->verb );

		if( $includePrivacy )
		{
			$item->privacy 	= $privacy->form( $id , SOCIAL_TYPE_FOLLOWERS, $item->actor->id, 'followers.view' );
		}

		return true;
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != SOCIAL_TYPE_FOLLOWERS )
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			$contextId = $aItem[0]->context_id;

			if( !$privacy->validate( 'followers.view', $contextId, SOCIAL_TYPE_FOLLOWERS, $item->actor_id ) )
			{
				$item->cnt = 0;
			}

		}

		return true;
	}


	/**
	 * Responsible to generate the stream contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != SOCIAL_TYPE_FOLLOWERS )
		{
			return;
		}

		$my         = Foundry::user();
		$privacy	= Foundry::privacy( $my->id );

		if( $includePrivacy )
		{
			if( !$privacy->validate( 'followers.view', $item->contextId, SOCIAL_TYPE_FOLLOWERS, $item->actor->id ) )
			{
				return;
			}
		}

		$item->display 	= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 	= '#415457';
		$item->fonticon	= 'ies-tree-view';
		$item->label 	= JText::_( 'APP_USER_FOLLOWERS_STREAM_TOOLTIP' );

		// Get the context id.
		$id 		= $item->contextId;

		// Get the target.
		$table 		= Foundry::table( 'Subscription' );
		$table->load( $id );

		// Get the actor
		$actor 		= $item->actor;

		// Receiving actor.
		$target		= Foundry::user( $table->uid );

		// Get the current view.
		$view 		= JRequest::getVar( 'view' );

		// Get the current id.
		$id 		= JRequest::getInt( 'id' );

		// If the current viewer is part of this stream, it should contain "You"
		$me 		= '';

		$me 	= $my->id == $actor->id ? 'actor' : $me;
		$me 	= $my->id == $target->id ? 'target' : $me;

		// If a user's profile is being viewed, we don't want to show "You"
		if( $view == 'profile' )
		{
			$me 	= '';
		}

		$term 	= '';

		if( $me == 'actor' )
		{
			$term 	= JText::_( 'APP_USER_FOLLOWERS_STREAM_TERM_ARE' );
		}

		if( $me == 'target' || !$me )
		{
			$term 	= JText::_( 'APP_USER_FOLLOWERS_STREAM_TERM_IS' );
		}

		$actorString 	= '';

		if( $me == 'actor' )
		{
			$actorString	= JText::_( 'COM_EASYSOCIAL_STREAM_YOU' );
		}
		else
		{
			$actorString 	= '<a href="' . $actor->getPermalink() . '">' . $actor->getName() . '</a>';
		}

		$targetString 	= '';

		if( $me == 'actor' || !$me )
		{
			$targetString 	= '<a href="' . $target->getPermalink() . '">' . $target->getName() . '</a>';
		}

		if( $me == 'target' )
		{
			$targetString 	= '<a href="' . $target->getPermalink() . '">' . JText::_( 'COM_EASYSOCIAL_STREAM_YOU' ) . '</a>';
		}

		$this->set( 'term'			, $term );
		$this->set( 'actorString' 	, $actorString );
		$this->set( 'targetString'	, $targetString );
		$this->set( 'actor'			, $actor );
		$this->set( 'target'		, $target );
		$this->set( 'me' 			, $me );

		// User A following user B
		if( $item->verb == 'follow' )
		{
			$item->title 	= parent::display( 'streams/' . $item->verb . '.title' );
		}

		if( $includePrivacy )
		{
			$item->privacy 	= $privacy->form( $id , SOCIAL_TYPE_FOLLOWERS, $item->actor->id, 'followers.view' );
		}

		return true;
	}
}
