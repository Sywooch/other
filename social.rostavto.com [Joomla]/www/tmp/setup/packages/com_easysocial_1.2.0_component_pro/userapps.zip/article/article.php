<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppArticle extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		// We need the router
		require_once( JPATH_ROOT . '/components/com_content/helpers/route.php' );

		parent::__construct();
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'article')
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$uid		= $item->id;
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			if( $aItem )
			{
				$uid 	= $aItem[0]->id;

				if( !$privacy->validate( 'core.view', $uid , SOCIAL_TYPE_ACTIVITY , $item->actor_id ) )
				{
					$item->cnt = 0;
				}
			}
		}

		return true;
	}

	/**
	 * Prepares the stream item
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'article' )
		{
			return;
		}

		// Decorate the stream item
		$item->display 	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#FCCD1B';
		$item->fonticon	= 'ies-list-2';
		$item->label 	= JText::_( 'APP_USER_ARTICLE_STREAM_TOOLTIP' );

		// Get application params
		$params 	= $this->getParams();

		if( $item->verb == 'create' && $params->get( 'stream_create' , true ) )
		{
			$this->prepareCreateArticleStream( $item );
		}

		if( $item->verb == 'update' && $params->get( 'stream_update', true ) )
		{
			$this->prepareUpdateArticleStream( $item );
		}

		if( $item->verb == 'read' && $params->get( 'stream_read' , true ) )
		{
			$this->prepareReadArticleStream( $item );
		}
	}

	/**
	 * Prepares the stream item for new article creation
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareCreateArticleStream( &$item )
	{
		// Retrieve initial data
		$article 			= $this->getArticle( $item );
		$category			= $this->getCategory( $item , $article );
		$permalink			= $this->getPermalink( $item , $article , $category );
		$categoryPermalink	= $this->getCategoryPermalink( $item , $category );

		// Get the actor
		$actor 		= $item->actor;

		// Get the creation date
		$date 		= Foundry::date( $article->created );

		// Get the content
		$content 	= $article->introtext;

		if( empty( $content ) )
		{
			$content 	= $article->fulltext;
		}

		$this->set( 'content'	, $content );
		$this->set( 'categoryPermalink' , $categoryPermalink );
		$this->set( 'date'		, $date );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'article'	, $article );
		$this->set( 'category'	, $category );
		$this->set( 'actor'		, $actor );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/create.title' );
		$item->content 	= parent::display( 'streams/create.content' );
	}

	/**
	 * Prepares the stream item for new article creation
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareUpdateArticleStream( &$item )
	{
		// Retrieve initial data
		$article 			= $this->getArticle( $item );
		$category			= $this->getCategory( $item , $article );
		$permalink			= $this->getPermalink( $item , $article , $category );
		$categoryPermalink	= $this->getCategoryPermalink( $item , $category );

		// Get the creation date
		$date 		= Foundry::date( $article->created );

		// Get the actor
		$actor 		= $item->actor;

		// Get the content
		$content 	= $article->introtext;

		if( empty( $content ) )
		{
			$content 	= $article->fulltext;
		}

		$this->set( 'content'	, $content );
		$this->set( 'categoryPermalink' , $categoryPermalink );
		$this->set( 'date'		, $date );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'article'	, $article );
		$this->set( 'category'	, $category );
		$this->set( 'actor'		, $actor );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/update.title' );
		$item->content 	= parent::display( 'streams/update.content' );
	}

	/**
	 * Prepares the stream item when an article is being read
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareReadArticleStream( &$item )
	{
		// Retrieve initial data
		$article 			= $this->getArticle( $item );
		$category			= $this->getCategory( $item , $article );
		$permalink			= $this->getPermalink( $item , $article , $category );
		$categoryPermalink	= $this->getCategoryPermalink( $item , $category );

		// Get the actor
		$actor 		= $item->actor;

		// Get the creation date
		$date 		= Foundry::date( $article->created );

		// Get the content
		$content 	= $article->introtext;

		if( empty( $content ) )
		{
			$content 	= $article->fulltext;
		}

		$this->set( 'content'	, $content );
		$this->set( 'categoryPermalink' , $categoryPermalink );
		$this->set( 'date'		, $date );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'article'	, $article );
		$this->set( 'category'	, $category );
		$this->set( 'actor'		, $actor );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/read.title' );
		$item->content 	= parent::display( 'streams/read.content' );
	}

	private function getArticle( $item )
	{
		// Load up the article dataset
		$article 	= JTable::getInstance( 'Content' );

		if( $item->params )
		{
			$registry 	= Foundry::registry( $item->params );

			if( $registry->get( 'article' ) )
			{
				$article->bind( (array) $registry->get( 'article' ) );
			}
		}
		else
		{
			// Load the items manually
			$article->load( $item->contextId );
		}

		return $article;
	}

	private function getCategory( $item , $article )
	{
		// Load up the category dataset
		$category	= JTable::getInstance( 'Category' );

		if( $item->params )
		{
			$registry 	= Foundry::registry( $item->params );

			if( $registry->get( 'category' ) )
			{
				$category->bind( (array) $registry->get( 'category' ) );
			}
		}
		else
		{
			$category->load( $article->catid );
		}

		return $category;
	}

	private function getPermalink( $item , $article , $category )
	{
		if( $item->params )
		{
			$registry 		= Foundry::registry( $item->params );
			$permalink 		= $registry->get( 'permalink' );
		}
		else
		{
			// Get the permalink
			$permalink	= ContentHelperRoute::getArticleRoute( $article->id . ':' . $article->alias , $article->catid . ':' . $category->alias );
		}

		return $permalink;
	}

	private function getCategoryPermalink( $item , $category )
	{
		if( $item->params )
		{
			$registry 	= Foundry::registry( $item->params );

			$categoryPermalink	= $registry->get( 'categoryPermalink' );
		}
		else
		{
			// Get the category permalink
			$categoryPermalink 	= ContentHelperRoute::getCategoryRoute( $category->id . ':' . $category->alias );
		}

		return $categoryPermalink;
	}
}
