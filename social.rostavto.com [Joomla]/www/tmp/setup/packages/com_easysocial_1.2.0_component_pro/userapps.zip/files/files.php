<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );
Foundry::import( 'admin:/includes/group/group' );


/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppFiles extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		// We need the router
		require_once( JPATH_ROOT . '/components/com_content/helpers/route.php' );

		parent::__construct();
	}

	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != SOCIAL_TYPE_FILES)
		{
			return false;
		}


		// if this is a cluster stream, let check if user can view this stream or not.
		if( $item->cluster_id && $item->cluster_type )
		{
			$params 	= Foundry::registry( $item->params );
			$group 		= Foundry::group( $params->get( 'group' ) );

			if( !$group )
			{
				return;
			}

			$item->cnt = 1;

			if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
			{
				if( !$group->isMember( Foundry::user()->id ) )
				{
					$item->cnt = 0;
				}
			}
		}
		else
		{
			// there is no need to validate against privacy for this item.
			$item->cnt = 1;
		}

		return true;
	}

	/**
	 * Prepares the stream item
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != SOCIAL_TYPE_FILES )
		{
			return;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		if( $item->cluster_id && $item->cluster_type )
		{
			$params 	= Foundry::registry( $item->params );
			// $obj 		= $params->get( 'group' );

			// $group 			= new SocialGroup();
			// $group->bind( $obj );

			$group 		= Foundry::group( $params->get( 'group' ) );

			if( !$group )
			{
				return;
			}

			if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
			{
				if( ! $group->isMember( Foundry::user()->id ) )
				{
					return;
				}
			}


			$item->custom_label = JText::_( 'COM_EASYSOCIAL_STREAM_CONTEXT_TITLE_FILES_' . strtoupper( $item->cluster_type ) );

		}

		// Define standard stream looks
		$item->display 	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#0b4b56';
		$item->icon 	= '<i class="ies-file" data-original-title="' . JText::_( 'COM_EASYSOCIAL_STREAM_CONTEXT_TITLE_FILES_TOOLTIP' ) . '" data-es-provide="tooltip"></i>';


		if( $item->verb == 'uploaded' )
		{
			$this->prepareUploadedStream( $item );
		}
	}

	/**
	 * Prepares the stream item for new file uploads
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareUploadedStream( &$item )
	{
		$params 	= Foundry::registry( $item->params );

		// Get the file object
		$file 		= Foundry::table( 'File' );
		$file->bind( $params->get( 'file' ) );

		// Get the actor
		$actor 		= $item->actor;

		$this->set( 'actor' , $actor );
		$this->set( 'file'	, $file );

		$clusterType = '';
		if( $item->cluster_id && $item->cluster_type )
		{
			$group 		= Foundry::group( $params->get( 'group' ) );

			$this->set( 'cluster'	, $group );

			$clusterType = '.' . $item->cluster_type;
		}

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/uploaded.title' . $clusterType );
		$item->content 	= parent::display( 'streams/uploaded.content' );
	}
}
