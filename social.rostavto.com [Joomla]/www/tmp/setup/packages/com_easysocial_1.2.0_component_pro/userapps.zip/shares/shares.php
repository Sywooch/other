<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/themes/themes' );
Foundry::import( 'admin:/includes/apps/apps' );

class SocialUserAppShares extends SocialAppItem
{
	public function __construct()
	{
	    // Foundry::get( 'Language' )->load( 'app_albums' , JPATH_ROOT );
		parent::__construct();
	}

	/**
	 * Responsible to generate the activity contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareActivityLog( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'shares' )
		{
			return;
		}

		// Get the context id.
		$id 		= $item->contextId;

		// Get the actor
		$actor 		= $item->actor;

		// Set the actor for the themes.
		$this->set( 'actor' , $actor );


		// Load the profiles table.
		$share	= Foundry::table( 'Share' );
		$state 	= $share->load( $id );

		if( !$state )
		{
			Foundry::logError( __FILE__ , __LINE__ , 'Share::onPrepareActivity : Unable to load share item with the id of ' . $id );
			return false;
		}


		$source 	= explode( '.', $share->element );
		$element 	= $source[0];
		$group 		= $source[1];

		$config 	= Foundry::config();
		$file 		= dirname( __FILE__ ) . '/helpers/'.$element.'.php';

		if( JFile::exists( $file ) )
		{
			require_once( $file );

			// Get class name.
			$className 	= 'SocialSharesHelper' . ucfirst( $element );

			// Instantiate the helper object.
			$helper		= new $className( $item, $share );

			$item->content 	= $helper->getContent();
			$item->title 	= $helper->getTitle();

		}

		$item->display 	= SOCIAL_STREAM_DISPLAY_MINI;
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'shares' )
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$uid		= $item->id;
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			$sModel = Foundry::model( 'Stream' );
			$aItem 	= $sModel->getActivityItem( $item->id, 'uid' );

			if( $aItem )
			{
				$uid 	= $aItem[0]->id;

				if( !$privacy->validate( 'core.view', $uid , SOCIAL_TYPE_ACTIVITY , $item->actor_id ) )
				{
					$item->cnt = 0;
				}
			}
		}

		return true;
	}

	private function getHelper( SocialStreamItem $item , SocialTableShare $share )
	{
		$source 	= explode( '.', $share->element );
		$element 	= $source[0];

		$file 		= dirname( __FILE__ ) . '/helpers/' . $element .'.php';
		require_once( $file );

		// Get class name.
		$className 	= 'SocialSharesHelper' . ucfirst( $element );

		// Instantiate the helper object.
		$helper			= new $className( $item, $share );

		return $helper;
	}

	/**
	 * Responsible to generate the stream contents.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		// Only process this if the stream type is shares
		if( $item->context != 'shares' )
		{
			return;
		}

		// Get the single context id
		$id 		= $item->contextId;

		// We only need the single actor.
		// Load the profiles table.
		$share	= Foundry::table( 'Share' );
		$share->load( $id );

		if( !$share->id )
		{
			return;
		}

		$my         = Foundry::user();
		$source 	= explode( '.', $share->element );

		$element 	= $source[0];
		$group 		= $source[1];

		$allowed 	= array( 'albums' , 'photos' , 'stream' );

		if( !in_array( $element , $allowed ) )
		{
			return;
		}

		// Apply likes on the stream
		$likes 			= Foundry::likes();
		$likes->get( $item->contextId , $item->context );
		$item->likes	= $likes;

		// Get the repost helper
		$helper 		= $this->getHelper( $item , $share );

		// Attach comments to the stream
		$comments		= Foundry::comments( $item->contextId , $item->context , SOCIAL_APPS_GROUP_USER , array( 'url' => $helper->getLink() ) );
		$item->comments = $comments;

		// Share app does not allow reposting itself.
		$item->repost	= false;

		// Get the content of the repost
		$item->content 	= $helper->getContent();

		// If the content is a false, there could be privacy restrictions.		
		if( $item->content === false )
		{
			return;
		}

		// Decorate the stream item
		$item->fonticon 	= 'ies-refresh';
		$item->color 		= '#e74c3c';
		$item->label 		= JText::_( 'APP_USER_REPOST_STREAM_TITLE' );
		$item->title 		= $helper->getTitle();

		// Set stream display mode.
		$item->display	= ( $item->display ) ? $item->display : SOCIAL_STREAM_DISPLAY_FULL;
	}

}
