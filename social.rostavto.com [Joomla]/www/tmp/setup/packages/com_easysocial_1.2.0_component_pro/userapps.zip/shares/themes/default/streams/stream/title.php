<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<?php if( $target->isViewer() ){ ?>
	<?php if( $ownPost ) { ?>

		<?php if ( isset( $sourcelink ) ) { ?>
			<?php echo JText::sprintf( 'APP_SHARES_YOU_SHARED_OWN_POST_LINK' , '<a href="' . $sourcelink . '">' . JText::_( 'APP_SHARES_SHARED_OWN_POST' ) . '</a>' ); ?>
		<?php } else { ?>
			<?php echo JText::_( 'APP_SHARES_YOU_SHARED_OWN_POST' ); ?>
		<?php } ?>

	<?php } else { ?>

		<?php if ( isset( $sourcelink ) ) { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_YOUR_OWN_POST_LINK' , $names, '<a href="' . $sourcelink . '">' . JText::_( 'APP_SHARES_SHARED_OWN_POST' ) . '</a>' ); ?>
		<?php } else { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_YOUR_OWN_POST' , $names ); ?>
		<?php } ?>

	<?php } ?>

<?php } else { ?>

	<?php
		$targetLink = '<a href="' . $target->getPermalink() .'" alt=" '. $this->html( 'string.escape' , $target->getName() ) . '">';
		$targetLink .= ( $term ) ? $term : $target->getName();
		$targetLink .= '</a>';

		if( $target->isBlock() )
		{
			$targetLink =  ( $term ) ? $term : $target->getName();
		}
	?>

	<?php if( $ownPost ) { ?>

		<?php if ( isset( $sourcelink ) ) { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_OWN_POST_LINK' , $names,  $targetLink , '<a href="' . $sourcelink . '">' . JText::_( 'APP_SHARES_SHARED_OWN_POST' ) . '</a>'  ) ;?>
		<?php } else { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_OWN_POST' , $names,  $targetLink ) ;?>
		<?php } ?>

	<?php } else { ?>

		<?php if ( isset( $sourcelink ) ) { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_TARGET_POST_LINK' , $names, $targetLink,  '<a href="' . $sourcelink . '">' . JText::_( 'APP_SHARES_SHARED_OWN_POST' ) . '</a>' ); ?>
		<?php } else { ?>
			<?php echo JText::sprintf( 'APP_SHARES_ACTOR_SHARED_TARGET_POST' , $names, $targetLink ); ?>
		<?php } ?>

	<?php } ?>

<?php } ?>
