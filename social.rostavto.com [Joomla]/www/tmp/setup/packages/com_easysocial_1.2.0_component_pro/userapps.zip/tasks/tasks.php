<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

// Include apps interface.
Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Tasks application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialUserAppTasks extends SocialAppItem
{


	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'task' )
		{
			return false;
		}

		$item->cnt = 1;

		if( $includePrivacy )
		{
			$my         = Foundry::user();
			$privacy	= Foundry::privacy( $my->id );

			if( !$privacy->validate( 'core.view', $item->id , SOCIAL_TYPE_STORY , $item->actor_id ) )
			{
				$item->cnt = 0;
			}

		}

		return true;
	}


	public function onPrepareStream( SocialStreamItem &$stream, $includePrivacy = true )
	{
		if( $stream->context != 'tasks')
		{
			return;
		}

		$uid		= $stream->uid;
		$my			= Foundry::user();
		$privacy	= Foundry::privacy( $my->id );

		if( $includePrivacy )
		{
			if( !$privacy->validate( 'core.view', $uid , SOCIAL_TYPE_STORY , $stream->actor->id ) )
			{
				return;
			}

			$stream->privacy 	= $privacy->form( $uid , SOCIAL_TYPE_STORY, $stream->actor->id, 'core.view' );
		}

		$stream->display	= SOCIAL_STREAM_DISPLAY_MINI;

		$stream->likes		= false;
		$stream->comments 	= false;
		$stream->repost		= false;

		// Only add stream for verb = 'add'
		if( $stream->verb == 'add' )
		{
			$me = $stream->actor->id == $my->id;

			$actor = JText::_( 'COM_EASYSOCIAL_STREAM_YOU' );

			if( !$me )
			{
				if( $stream->actor->isBlock() )
				{
					$actor = $stream->actor->getName();
				}
				else
				{
					$actor = "<a href=\"{$stream->actor->getPermalink()}\" alt=\"{Foundry::string()->escape($stream->actor->getName())}\">{$stream->actor->getName()}</a>";
				}
			}

			$this->set( 'actor', $stream->actor );

			$task = $this->getTable( 'task' );

			$task->load( $stream->contextId );

			$this->set( 'task', $task );

			$stream->title 		= parent::display( 'streams/add.title' );
		}

		return true;
	}
}
