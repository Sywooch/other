<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="fd-small">
	<?php echo JText::_( 'You have already associated with your LinkedIn account' );?>.
</div>

<div class="mt-15">
	<a href="#" class="btn btn-es-danger btn-medium"><?php echo JText::_( 'Revoke Access');?></a>
</div>

