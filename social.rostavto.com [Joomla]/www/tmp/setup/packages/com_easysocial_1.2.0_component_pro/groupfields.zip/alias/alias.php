<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

Foundry::import('fields:/user/textbox/textbox');

class SocialFieldsGroupAlias extends SocialFieldsUserTextbox
{
	public function onRegisterBeforeSave(&$post, &$group)
	{
		return $this->beforeSave($post, $group);
	}

	public function onEdit(&$post, &$group, $errors)
	{
		$value = !empty($post[$this->inputName]) ? $post[$this->inputName] : $group->alias;

		// Get the error.
		$error = $this->getError( $errors );

		// Set the value.
		$this->set( 'value'	, $this->escape( $value ) );
		$this->set( 'error'	, $error );

		return $this->display();
	}

	public function onEditBeforeSave(&$post, &$group)
	{
		$alias = !empty($post[$this->inputName]) ? $post[$this->inputName] : '';

		if( $alias != $group->alias )
		{
			return $this->beforeSave($post, $group);
		}

		return true;
	}

	public function beforeSave(&$post, &$group)
	{
		$alias = !empty($post[$this->inputName]) ? $post[$this->inputName] : $group->title;

		$alias = JFilterOutput::stringURLSafe($alias);

		$model = Foundry::model('clusters');

		$i = 2;

		do
		{
			$exist = $model->clusterAliasExists($alias, $group->id);

			if ($exist)
			{
				$alias .= '-' . $i++;
			}
		} while ($exist);

		$group->alias = $alias;

		return true;
	}

	public function onDisplay( $group )
	{
		return;
	}
}
