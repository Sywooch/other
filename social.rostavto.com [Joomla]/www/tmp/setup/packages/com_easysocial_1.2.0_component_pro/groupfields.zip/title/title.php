<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

// Extend from user textbox
Foundry::import('fields:/user/textbox/textbox');

class SocialFieldsGroupTitle extends SocialFieldsUserTextbox
{
	/**
	 * Executes before the group is created
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onRegisterBeforeSave( &$data , &$group )
	{
		$title 	= isset( $data[ $this->inputName ] ) ? $data[ $this->inputName ] : '';

		// Set the title on the group
		$group->title 	= $title;
	}

	/**
	 * Executes before the group is save
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onEditBeforeSave( &$data , &$group )
	{
		$title 	= isset( $data[ $this->inputName ] ) ? $data[ $this->inputName ] : '';

		// Set the title on the group
		$group->title 	= $title;
	}

	/**
	 * Responsible to output the html codes that is displayed to
	 * a user when their profile is viewed.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function onDisplay( $group )
	{
		$value 	= $group->getName();

		// Push variables into theme.
		$this->set( 'value' , $this->escape( $value ) );

		return $this->display();
	}

	/**
	 * Override the editing of the title since the value is different
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onEdit( &$post, &$group , $errors )
	{
		// The value will always be the group title
		$value 	= $group->getName();

		// Get the error.
		$error = $this->getError( $errors );

		// Set the value.
		$this->set( 'value'	, $this->escape( $value ) );
		$this->set( 'error'	, $error );

		return $this->display();
	}
}
