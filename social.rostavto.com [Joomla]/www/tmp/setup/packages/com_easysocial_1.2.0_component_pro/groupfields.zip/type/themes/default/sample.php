<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="control-group">
	<label class="control-label">
		<span data-required <?php if( ( !isset( $options['required'] ) && !$params->get( 'required' ) ) || ( isset( $options['required'] ) && !$options['required'] ) ) { ?>style="display: none;"<?php } ?>><?php echo JText::_( 'COM_EASYSOCIAL_REGISTRATION_REQUIRED_SYMBOL' ); ?></span>
		<span data-display-title data-title <?php if( !$params->get( 'display_title' ) ) { ?>style="display: none;"<?php } ?>><?php echo JText::_( $params->get( 'title' ) ); ?></span>:
	</label>

	<div class="controls controls-description mb-15">
		<label class="radio" for="group_type_public">
			<input type="radio" checked="" value="1" id="group_type_public" name="group_type" />
			<i class="ies-earth"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PUBLIC' ); ?>
		</label>
		<div class="help-block fd-small mt-5" style="padding-left: 26px;">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PUBLIC_DESC' );?>
		</div>
	</div>

	<div class="controls controls-description mb-15">
		<label class="radio" for="group_type_private">
			<input type="radio" checked="" value="2" id="group_type_private" name="group_type" />
			<i class="ies-user-2"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PRIVATE' ); ?>
		</label>

		<div class="help-block fd-small mt-5" style="padding-left: 26px;">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PRIVATE_DESC' );?>
		</div>
	</div>

	<div class="controls controls-description mb-15">
		<label class="radio" for="group_type_invite">
			<input type="radio" checked="" value="3" id="group_type_invite" name="group_type" />
			<i class="ies-ies-locked"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_INVITE_ONLY' ); ?>
		</label>

		<div class="help-block fd-small mt-5" style="padding-left: 26px;">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_INVITE_ONLY_DESC' );?>
		</div>
	</div>

	<div class="controls fd-small" <?php if( !$params->get( 'display_description' ) ) { ?>style="display: none;"<?php } ?> data-display-description>
		<strong>Note:</strong>
		<span data-description><?php echo JText::_( $params->get( 'description' ) ); ?></span>
	</div>

</div>
