<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="form-group">
	<label class="col-sm-3 control-label">
		<span data-required <?php if( ( !isset( $options['required'] ) && !$params->get( 'required' ) ) || ( isset( $options['required'] ) && !$options['required'] ) ) { ?>style="display: none;"<?php } ?>><?php echo JText::_( 'COM_EASYSOCIAL_REGISTRATION_REQUIRED_SYMBOL' ); ?></span>
		<span data-display-title data-title <?php if( !$params->get( 'display_title' ) ) { ?>style="display: none;"<?php } ?>><?php echo JText::_( $params->get( 'title' ) ); ?></span>:
	</label>

	<div class="col-sm-8 controls-description mb-5">
		<label class="radio" for="group_type_public">
			<input type="radio" checked="checked" value="1" id="group_type_public" name="group_type"<?php echo $group->isOpen() ? ' checked="checked"' : '';?>/>
			<i class="ies-earth"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PUBLIC' ); ?>
		</label>
		<div class="help-block fd-small mt-5">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PUBLIC_DESC' );?>
		</div>
	</div>

	<div class="col-sm-8 col-sm-offset-3 controls-description mb-5">
		<label class="radio" for="group_type_private">
			<input type="radio" value="2" id="group_type_private" name="group_type"<?php echo $group->isClosed() ? ' checked="checked"' : '';?> />
			<i class="ies-user-2"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PRIVATE' ); ?>
		</label>

		<div class="help-block fd-small mt-5">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_PRIVATE_DESC' );?>
		</div>
	</div>

	<div class="col-sm-8 col-sm-offset-3 controls-description mb-5">
		<label class="radio" for="group_type_invite">
			<input type="radio" value="3" id="group_type_invite" name="group_type"<?php echo $group->isInviteOnly() ? ' checked="checked"' : '';?> />
			<i class="ies-locked"></i> <?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_INVITE_ONLY' ); ?>
		</label>

		<div class="help-block fd-small mt-5">
			<?php echo JText::_( 'PLG_FIELDS_GROUP_TYPE_INVITE_ONLY_DESC' );?>
		</div>
	</div>

	<?php echo $this->loadTemplate( 'site/fields/description' , array( 'params' => $params ) ); ?>

</div>
