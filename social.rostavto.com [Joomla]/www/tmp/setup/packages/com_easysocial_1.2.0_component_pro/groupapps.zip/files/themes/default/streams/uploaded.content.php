<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div class="stream-files">
	<h4>
		<a href="<?php echo $file->getPreviewURI();?>"><?php echo $file->name; ?></a> <span class="fd-small">(<?php echo $file->getSize( 'kb' );?> <?php echo JText::_( 'COM_EASYSOCIAL_UNIT_KILOBYTES' );?>)</span>
	</h4>

	<div class="file-contents">
		<?php if( $file->hasPreview() ){ ?>
		<div class="file-preview">
			<a href="<?php echo $file->getPreviewURI();?>" target="_blank"><img src="<?php echo $file->getPreviewURI();?>" alt="<?php echo $this->html( 'string.escape' , $file->name );?>" /></a>
		</div>
		<?php } else { ?>
		<div class="file-download">
			<a href="<?php echo $file->getPreviewURI();?>" target="_blank">
				<i class="ies-download-3"></i>
				<span><?php echo JText::_( 'Download' );?></span>
			</a>
		</div>
		<?php } ?>
	</div>
</div>
