<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Groups application for EasySocial
 * @since	1.2
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialGroupAppGroups extends SocialAppItem
{
	/**
	 * Class constructor
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'groups' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}

	/**
	 * Trigger for onPrepareStream
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		// We only want to process related items
		if( $item->context != 'groups' )
		{
			return;
		}

		// $item->display	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->display	= SOCIAL_STREAM_DISPLAY_MINI;
		$item->color 	= '#39769c';
		$item->icon 	= '<i class="ies-users" data-original-title="' . JText::_( 'APP_GROUPS_GROUPS_STREAM_TOOLTIP' ) . '" data-es-provide="tooltip"></i>';

		if( $item->verb == 'create' )
		{
			$this->prepareCreateStream( $item );
		}

		if( $item->verb == 'join' )
		{
			$this->prepareJoinStream( $item );
		}

		if( $item->verb == 'leave' )
		{
			$this->prepareLeaveStream( $item );
		}

		if( $item->verb == 'makeadmin' )
		{
			$this->prepareMakeAdminStream( $item );
		}

		if( $item->verb == 'update' )
		{
			$this->prepareUpdateStream( $item );
		}
	}

	private function prepareLeaveStream( SocialStreamItem &$item )
	{
		$params 	= Foundry::registry( $item->params );
		$obj 		= $params->get( 'group' );

		$group 			= new SocialGroup();
		$group->bind( $obj );


		if( !$group )
		{
			return;
		}

		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/leave.title' );
	}

	private function prepareJoinStream( SocialStreamItem &$item )
	{
		$groupId 	= $item->contextId;
		$params 	= Foundry::registry( $item->params );
		$obj 		= $params->get( 'group' );

		$group 			= new SocialGroup();
		$group->bind( $obj );

		if( !$group )
		{
			return;
		}


		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/join.title' );
		$item->content	= parent::display( 'streams/join.content' );

	}

	private function prepareMakeAdminStream( SocialStreamItem &$item )
	{
		$groupId 	= $item->contextId;

		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}


		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/makeadmin.title' );
	}

	private function prepareUpdateStream( SocialStreamItem &$item )
	{
		$groupId 	= $item->contextId;

		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/update.title' );
	}

	private function prepareCreateStream( SocialStreamItem &$item )
	{
		$groupId 	= $item->contextId;
		$params 	= Foundry::registry( $item->params );
		$obj 		= $params->get( 'group' );

		$group 			= new SocialGroup();
		$group->bind( $obj );

		if( !$group )
		{
			return;
		}

		// We don't want to display groups that are invitation only.
		if( $group->type == SOCIAL_GROUPS_INVITE_TYPE )
		{
			return;
		}

		$actor	 = $item->actor;

		$this->set( 'group'	, $group );
		$this->set( 'actor'	, $actor );

		$item->title 	= parent::display( 'streams/create.title' );
		$item->content	= parent::display( 'streams/create.content' );
	}
}
