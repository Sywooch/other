<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

/**
 * Widgets for group
 *
 * @since	1.0
 * @access	public
 */
class GroupsWidgetsGroups extends SocialAppsWidgets
{
	/**
	 * Display user photos on the side bar
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function sidebarBottom( $groupId )
	{
		// Get the group
		$group		= Foundry::group( $groupId );
		$params 	= $this->app->getParams();

		if( $params->get( 'show_online' , true ) )
		{
			echo $this->getOnlineUsers( $group );
		}

		if( $params->get( 'show_friends' , true ) )
		{
			echo $this->getFriends( $group );			
		}
	}

	/**
	 * Displays a list of friends in the group
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return	
	 */
	public function getFriends( $group )
	{
		$theme 		= Foundry::themes();
		
		// Get the current logged in user.
		$my 		= Foundry::user();

		$options 				= array();
		$options[ 'userId' ]	= $my->id;
		$options[ 'randomize' ]	= true;
		$options[ 'limit' ]		= 5;

		// Get a list of friends in this group based on the current viewer.
		$model 		= Foundry::model( 'Groups' );
		$friends	= $model->getFriendsInGroup( $group->id , $options );

		$theme->set( 'friends' , $friends );

		return $theme->output( 'themes:/apps/group/groups/widgets/widget.friends' );
	}

	/**
	 * Displays a list of online group members
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return	
	 */
	private function getOnlineUsers( $group )
	{
		$model 	= Foundry::model( 'Groups' );
		$users 	= $model->getOnlineMembers( $group->id );

		$theme 	= Foundry::themes();
		$theme->set( 'users' , $users );

		return $theme->output( 'themes:/apps/group/groups/widgets/widget.online' );
	}
}
