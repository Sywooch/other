<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

class NewsControllerNews extends SocialAppsController
{
	/**
	 * Processes deletion
	 *
	 * @since	1.2
	 * @access	public
	 */
	public function delete()
	{
		// Check for request forgeriess
		Foundry::checkToken();

		// Ensure that the user is logged in.
		Foundry::requireLogin();

		$ajax 		= Foundry::ajax();

		$id 		= JRequest::getInt( 'id' );
		$groupId	= JRequest::getInt( 'groupId' );
		$group		= Foundry::group( $groupId );

		if( !$group->isAdmin() )
		{
			return $this->redirect( $group->getPermalink( false ) );
		}

		// Load the news
		$news 		= Foundry::table( 'GroupNews' );
		$news->load( $id );

		if( !$group->isAdmin() )
		{
			return $this->redirect( $group->getPermalink( false ) );
		}

		$state 	= $news->delete();

		// @points: groups.news.delete
		// Deduct points from the news creator when the news is deleted.
		$points = Foundry::points();
		$points->assign( 'groups.news.delete' , 'com_easysocial' , $news->created_by );

		$message = $state ? JText::_( 'APP_GROUP_NEWS_DELETED_SUCCESS' ) : JText::_( 'APP_GROUP_NEWS_DELETED_FAILED' );
		Foundry::info()->set( $message , SOCIAL_MSG_SUCCESS );

		$this->redirect( $group->getPermalink( false ) );
	}

	/**
	 * Displays confirmation dialog to delete a news
	 *
	 * @since	1.2
	 * @access	public
	 */
	public function confirmDelete()
	{
		// Check for request forgeriess
		Foundry::checkToken();

		// Ensure that the user is logged in.
		Foundry::requireLogin();

		$ajax 	= Foundry::ajax();

		$id 		= JRequest::getInt( 'id' );
		$groupId	= JRequest::getInt( 'groupId' );
		$group		= Foundry::group( $groupId );

		if( !$group->isAdmin() )
		{
			return $ajax->reject();
		}

		$theme 	= Foundry::themes();
		$theme->set( 'group' , $group );
		$theme->set( 'appId' , $this->getApp()->id );
		$theme->set( 'id' , $id );
		$output	= $theme->output( 'apps/group/news/canvas/dialog.delete' );

		return $ajax->resolve( $output );
	}

	/**
	 * Retrieves the new article form
	 *
	 * @since	1.2
	 * @access	public
	 * @return	
	 */
	public function save()
	{
		// Check for request forgeriess
		Foundry::checkToken();

		// Ensure that the user is logged in.
		Foundry::requireLogin();

		// Get the posted data
		$post 	= JRequest::get( 'post' );

		// Determines if this is an edited news.
		$id 	= JRequest::getInt( 'newsId' );

		// Load up the news obj
		$news 	= Foundry::table( 'GroupNews' );
		$news->load( $id );

		$message 	= !$news->id ? JText::_( 'APP_GROUP_NEWS_CREATED_SUCCESSFULLY' ) : JText::_( 'APP_GROUP_NEWS_UPDATED_SUCCESSFULLY' );
		
		// Get the group
		$groupId 	= JRequest::getInt( 'cluster_id' );
		$group 		= Foundry::group( $groupId );
		$my 		= Foundry::user();

		// Get the app id
		$app 		= $this->getApp();

		if( !$group->isAdmin() )
		{
			$url 	= FRoute::groups( $group->getPermalink( false ) );
			return $this->redirect( $url );
		}

		$options					= array();
		$options[ 'title' ]			= JRequest::getVar( 'title' );
		$options[ 'content' ]		= JRequest::getVar( 'news_content' , '', 'post', 'string', JREQUEST_ALLOWRAW );
		$options[ 'comments' ]		= JRequest::getBool( 'comments' );
		$options[ 'state' ]			= SOCIAL_STATE_PUBLISHED;

		// Only bind this if it's a new item
		if( !$news->id )
		{
			$options[ 'cluster_id' ]	= $groupId;
			$options[ 'created_by' ]	= $my->id;
			$options[ 'hits' ]			= 0;	
		}

		// Bind the data
		$news->bind( $options );

		// Check if there are any errors
		if( !$news->check() )
		{
			Foundry::info()->set( $news->getError() , SOCIAL_MSG_ERROR );

			$url 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'form' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $app->id ) , false );

			return $this->redirect( $url );
		}

		// If everything is okay, bind the data.
		$news->store();

		// If it is a new item, we want to run some other stuffs here.
		if( !$id )
		{
			// @points: groups.news.create
			// Add points to the user that updated the group
			$points = Foundry::points();
			$points->assign( 'groups.news.create' , 'com_easysocial' , $my->id );
		}

		// Redirect to the appropriate page now
		$url 		= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $app->id , 'newsId' => $news->id ) , false );
		$permalink	= FRoute::controller( 'groups' , array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $app->id , 'newsId' => $news->id ) );

		// Notify users about the news.
		$options 	= array( 'userId' => $my->id , 'permalink' => $permalink , 'newsTitle' => $news->title , 'newsContent' => strip_tags( $news->content ) );

		$group->notifyMembers( 'news.create' , $options );

		Foundry::info()->set( $message , SOCIAL_MSG_SUCCESS );

		// Perform a redirection
		$this->redirect( $url );
	}

}