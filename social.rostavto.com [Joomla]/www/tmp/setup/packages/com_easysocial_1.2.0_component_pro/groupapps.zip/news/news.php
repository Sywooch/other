<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Friends application for EasySocial.
 *
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialGroupAppNews extends SocialAppItem
{
	/**
	 * Class constructor.
	 *
	 * @since	1.0
	 * @access	public
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'news' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}


	/**
	 * Prepares the stream item for groups
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'news' )
		{
			return;
		}

		// Define standard stream looks
		$item->display 	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#8e0000';
		$item->icon 	= '<i class="ies-broadcast-2" data-original-title="' . JText::_( 'APP_GROUP_NEWS_STREAM_TOOLTIP' ) . '" data-es-provide="tooltip"></i>';


		if( $item->verb == 'create' )
		{
			$this->prepareCreateStream( $item );
		}
	}

	private function prepareCreateStream( &$item )
	{
		$params = Foundry::registry( $item->params );

		$data 	= $params->get( 'news' );

		// Load the group
		$group	= Foundry::group( $data->cluster_id );

		$news	= Foundry::table( 'GroupNews' );
		$news->bind( $data );

		// Get the permalink
		$permalink 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $this->getApp()->id , 'newsId' => $news->id ) , false );

		// Get the app params
		$appParams 	= $this->getApp()->getParams();

		// Format the content
		$this->format( $news , $appParams->get( 'stream_length' ) );

		// Attach actions to the stream
		$this->attachActions( $item , $news , $permalink , $appParams );

		$this->set( 'appParams'	, $appParams );
		$this->set( 'permalink' , $permalink );
		$this->set( 'news' , $news );
		$this->set( 'actor'	, $item->actor );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/create.title' );
		$item->content 	= parent::display( 'streams/create.content' );
	}

	private function format( &$news , $length = 0 )
	{
		if( $length == 0 )
		{
			return;
		}

		$news->content 	= JString::substr( strip_tags( $news->content ) , 0 , $length ) . ' ' . JText::_( 'COM_EASYSOCIAL_ELLIPSES' );
	}

	private function attachActions( &$item , &$news , $permalink , $appParams )
	{
		// We need to link the comments to the news
		$item->comments 	= Foundry::comments( $news->id , 'news' , SOCIAL_APPS_GROUP_GROUP , array( 'url' => $permalink ) );

		// The comments for the stream item should link to the news itself.
		if( !$appParams->get( 'allow_comments' ) || !$news->comments )
		{
			$item->comments 	= false;
		}

		// The likes needs to be linked to the news itself
		$likes 			= Foundry::likes();
		$likes->get( $news->id , 'news' );

		$item->likes = $likes;
	}
}
