<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

/**
 * Photos application for EasySocial
 * @since	1.0
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialGroupAppPhotos extends SocialAppItem
{
	/**
	 * Class constructor
	 *
	 * @since	1.2
	 * @access	public
	 */
	public function __construct()
	{
		JFactory::getLanguage()->load( 'app_photos' , JPATH_ROOT );

		parent::__construct();
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'photos' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}

	/**
	 * Trigger for onPrepareStream
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onPrepareStream( SocialStreamItem &$item )
	{
		// We only want to process related items
		if( $item->context != 'photos' )
		{
			return;
		}

		$config	= Foundry::config();

		// Do not allow user to access photos if it's not enabled
		if( !$config->get( 'photos.enabled' ) && $item->verb != 'uploadAvatar' && $item->verb != 'updateCover' )
		{
			return;
		}

		// Get current logged in user.
		$my         = Foundry::user();

		$element	= $item->context;
		$uid     	= $item->contextId;

		$photoId	= $item->contextId;
		$photo		= $this->getPhotoFromParams( $item );

		// Process actions on the stream
		$this->processActions( $item );

		// Decorate the stream
		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->fonticon = 'ies-picture';
		$item->color 	= '#F8829C';
		$item->label	= JText::_( 'APP_GROUP_PHOTOS_STREAM_TOOLTIP' );

		// Get the app params.
		$params 		= $this->getParams();

		if( $item->verb == 'uploadAvatar' && $params->get( 'stream_avatar' , true ) )
		{
			$this->prepareUploadAvatarStream( $item );
		}

		if( $item->verb == 'updateCover' && $params->get( 'stream_cover' , true ) )
		{
			$this->prepareUpdateCoverStream( $item );
		}

		// Photo stream types. Uploaded via the story form
		if( $item->verb == 'share' && $params->get( 'stream_share' , true ) )
		{
			$this->preparePhotoStream( $item );
		}

		if( ( $item->verb == 'add' || $item->verb == 'create' ) && $params->get( 'stream_upload' , true ) )
		{
			$this->preparePhotoStream( $item );
		}

		return true;
	}

	/**
	 * Processes the actions for the stream
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return	
	 */
	private function processActions( SocialStreamItem &$item )
	{
		// Apply repost on the stream
		$repost 		= Foundry::get( 'Repost', $item->uid , SOCIAL_TYPE_STREAM );
		$item->repost	= $repost;

		if( $item->verb == 'share' )
		{
			$likes 			= Foundry::likes();
			$likes->get( $item->uid , SOCIAL_TYPE_STREAM );
			$item->likes	= $likes;

			// Apply comments on the stream
			$comments			= Foundry::comments( $item->uid , SOCIAL_TYPE_STREAM, SOCIAL_APPS_GROUP_GROUP , array( 'url' => FRoute::stream( array( 'layout' => 'item', 'id' => $item->uid ) ) ) );
			$item->comments 	= $comments;

			return;
		}

		// photos has the special threatment. if the item is a aggregated item, then the context is album and the uid is albumid.
		if( count( $item->contextIds ) > 1 )
		{
			$photos 	= $this->getPhotoFromParams( $item );
			$photo		= $photos[ 0 ];

			if( $photo->id )
			{
				$element 	= SOCIAL_TYPE_ALBUM;
				$uid 		= $photo->album_id;

				// Format the likes for the stream
				$likes 			= Foundry::likes();
				$likes->get( $photo->album_id , 'albums' );
				$item->likes	= $likes;

				// Apply comments on the stream
				$comments			= Foundry::comments( $photo->album_id , 'albums' , SOCIAL_APPS_GROUP_GROUP , array( 'url' => FRoute::albums( array( 'layout' => 'item', 'id' => $photo->album_id ) ) ) );
				$item->comments 	= $comments;
			}

		}
		else
		{
			$likes 			= Foundry::likes();
			$likes->get( $item->contextId , $item->context );
			$item->likes	= $likes;

			// Apply comments on the stream
			$comments			= Foundry::comments( $item->contextId , $item->context , SOCIAL_APPS_GROUP_GROUP , array( 'url' => FRoute::photos( array( 'layout' => 'item', 'id' => $item->contextId ) ) ) );
			$item->comments 	= $comments;
		}

	}

	/**
	 * Retrieve the table object from the stream item params
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return	
	 */
	public function getPhotoFromParams( SocialStreamItem &$item , $privacy = null )
	{
		if( count( $item->contextIds ) > 0 && $item->verb != 'uploadAvatar' && $item->verb != 'updateCover' )
		{
			$photos = array();

			// We only want to get a maximum of 5 photos if we have more than 1 photo to show.
			$ids 	= array_reverse( $item->contextIds );

			foreach( $ids as $id )
			{
				$photo 	= Foundry::table( 'Photo' );
				$raw 	= isset( $item->contextParams[ $id ] ) ? $item->contextParams[ $id ] : '';

				if( $raw )
				{
					$obj 	= Foundry::json()->decode( $raw );
					$photo->bind( $obj );

					if( !$photo->id )
					{
						$photo->load( $id );
					}
				}
				else
				{
					$photo->load( $id );
				}
				
				$photos[]	= $photo;
			}

			return $photos;
		}

		// Load up the photo object
		$photo	= Foundry::table( 'Photo' );

		// Get the context id.
		$id 	= $item->contextId;
		$raw 	= isset( $item->contextParams[ $id ] ) ? $item->contextParams[ $id ] : '';

		if( $raw )
		{
			$obj 	= Foundry::json()->decode( $raw );
			$photo->bind( $obj );

			if( !$photo->id )
			{
				$photo->load( $id );
			}

			return $photo;
		}

		$photo->load( $id );

		return $photo;
	}

	/**
	 * Prepares the stream items for photo uploads
	 *
	 * @since	1.0
	 * @access	public
	 * @return
	 */
	public function preparePhotoStream( SocialStreamItem &$item )
	{
		// Get photo objects
		$photos 	= $this->getPhotoFromParams( $item );

		// Get the first photo's album id.
		$albumId 	= $photos[ 0 ]->album_id;
		$album		= Foundry::table( 'Album' );
		$album->load( $albumId );

		// Get total number of items uploaded.
		$count 		= count( $item->contextIds );

		// Get the actor
		$actor 		= $item->actor;
		$group		= Foundry::group( $item->cluster_id );

		$this->set( 'count'			, $count );
		$this->set( 'group'			, $group );
		$this->set( 'totalPhotos'	, count( $photos ) );
		$this->set( 'photos'		, $photos );
		$this->set( 'album'			, $album );
		$this->set( 'actor'			, $actor );

		// old data compatibility
		$verb = ( $item->verb == 'create' ) ? 'add' : $item->verb;

		// Set the display mode to be full.
		$item->title 	= parent::display( 'streams/' . $verb . '.title' );
		$item->content 	= parent::display( 'streams/' . $verb . '.content' );
	}

	/**
	 * Prepares the upload avatar stream
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStream
	 * @return
	 */
	public function prepareUploadAvatarStream( SocialStreamItem &$item )
	{
		// Get the photo object
		$photo 		= $this->getPhotoFromParams( $item );

		$this->set( 'photo' , $photo );
		$this->set( 'actor'	, $item->actor );

		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;

		$item->title 	= parent::display( 'streams/upload.avatar.title' );
		$item->content 	= parent::display( 'streams/upload.avatar.content' );
	}

	/**
	 * Prepares the upload avatar stream
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStream
	 * @return
	 */
	public function prepareUpdateCoverStream( SocialStreamItem &$item )
	{
		$element = $item->context;
		$uid     = $item->contextId;

		// Get the photo object
		$photo		= $this->getPhotoFromParams( $item );

		// Get the cover of the group
		$group 		= Foundry::group( $item->cluster_id );
		$cover 		= $group->getCover();

		$this->set( 'cover'	, $cover );
		$this->set( 'photo' , $photo );
		$this->set( 'actor'	, $item->actor );

		$item->title 	= parent::display( 'streams/upload.cover.title' );
		$item->content 	= parent::display( 'streams/upload.cover.content' );
	}

	/**
	 * Processes a saved story.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onAfterStorySave( &$stream , $streamItem , &$template )
	{
		$photos	= JRequest::getVar( 'photos' );

		// If there's no data, we don't need to do anything here.
		if( empty( $photos ) )
		{
			return;
		}

		if( empty( $template->content ) )
		{
			$template->content 	.= '<br />';
		}


		// Now that we know the saving is successfull, we want to update the state of the photo table.
		foreach( $photos as $photoId )
		{
			$table 	= Foundry::table( 'Photo' );
			$table->load( $photoId );

			$album	= Foundry::table( 'Album' );
			$album->load( $table->album_id );

			$table->state	= SOCIAL_STATE_PUBLISHED;
			$table->store();

			// Determine if there's a cover for this album.
			if( !$album->hasCover() )
			{
				$album->cover_id	= $table->id;
				$album->store();
			}

			$template->content 	.= '<img src="' . $table->getSource( 'thumbnail' ) . '" width="128" />';
		}

		return true;
	}

	/*
	 * Save trigger which is called after really saving the object.
	 */
	public function onAfterSave( &$data )
	{
	    // for now we only support the photo added by person. later on we will support
	    // for groups, events and etc.. the source will determine the type.
	    $source		= isset( $data->source ) ? $data->source : 'people';
	    $actor		= ($source == 'people' ) ? Foundry::get('People', $data->created_by) : '0';

	    // save into activity streams
	    $item   = new StdClass();
	    $item->actor_id 	= $actor->get( 'node_id' );
	    $item->source_type	= $source;
	    $item->source_id 	= $actor->id;
	    $item->context_type = 'photos';
	    $item->context_id 	= $data->id;
	    $item->verb 		= 'upload';
	    $item->target_id 	= $data->album_id;

	    //$item   = get_object_vars($item);
        //Foundry::get('Stream')->addStream( array($item, $item, $item) );
        Foundry::get('Stream')->addStream( $item );
		return true;
	}


	public function onPrepareStoryPanel($story)
	{
		$config 	= Foundry::config();

		if( !$config->get( 'photos.enabled' ) )
		{
			return;
		}

		// Get current logged in user.
		$my 	= Foundry::user();

		// Get user access
		$access	= Foundry::access( $my->id , SOCIAL_TYPE_USER );

		$plugin = $story->createPlugin("photos", "panel");

		$theme = Foundry::get('Themes');

		// check max photos upload here.
		if ($access->exceeded('photos.uploader.max', $my->getTotalPhotos())) {
			$theme->set('exceeded', JText::sprintf('COM_EASYSOCIAL_PHOTOS_EXCEEDED_MAX_UPLOAD', $access->get('photos.uploader.max')));
		}

		// check max photos upload daily here.
		if ($access->exceeded('photos.uploader.maxdaily', $my->getTotalPhotos(true))) {
			$theme->set('exceeded', JText::sprintf('COM_EASYSOCIAL_PHOTOS_EXCEEDED_DAILY_MAX_UPLOAD', $access->get('photos.uploader.maxdaily')));
		}

		$plugin->button->html = $theme->output('themes:/apps/user/photos/story/panel.button');
		$plugin->content->html = $theme->output( 'themes:/apps/user/photos/story/panel.content' );

		$script = Foundry::get('Script');
		$plugin->script = $script->output('apps:/user/photos/story');

		return $plugin;
	}

	/**
	 * Triggers when unlike happens
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onAfterLikeDelete( &$likes )
	{
		if( !$likes->type )
		{
			return;
		}

		// Set the default element.
		$element 	= $likes->type;
		$uid 		= $likes->uid;

		if( strpos( $element , '.' ) !== false )
		{
			$data		= explode( '.', $element );
			$group		= $data[1];
			$element	= $data[0];
		}

		if( $element != SOCIAL_TYPE_PHOTO )
		{
			return;
		}

		// Get the photo object
		$photo 	= Foundry::table( 'Photo' );
		$photo->load( $uid );

		// @points: photos.unlike
		// Deduct points for the current user for unliking this item
		$photo->assignPoints( 'photos.unlike' , Foundry::user()->id );
	}

	/**
	 * Triggers after a like is saved
	 *
	 * @since	1.0
	 * @access	public
	 * @param	object	$params		A standard object with key / value binding.
	 *
	 * @return	none
	 */
	public function onAfterLikeSave( &$likes )
	{
		if( !$likes->type )
		{
			return;
		}

		// Set the default element.
		$element 	= $likes->type;
		$uid 		= $likes->uid;

		if( strpos( $element , '.' ) !== false )
		{
			$data		= explode( '.', $element );
			$group		= $data[1];
			$element	= $data[0];
		}

		if( $element != SOCIAL_TYPE_PHOTO )
		{
			return;
		}

		// Get the photo object
		$photo 	= Foundry::table( 'Photo' );
		$photo->load( $uid );

		// @points: photos.like
		// Assign points for the author for liking this item
		$photo->assignPoints( 'photos.like' , Foundry::user()->id );

		// Default recipients
		$recipients = array();

		// Get a list of tagged users
		$tags 	= $photo->getTags( true );

		if( $tags )
		{
			foreach( $tags as $tag )
			{
				$recipients[]	= $tag->uid;
			}
		}

		// Get a list of likers
		$likers 		= Foundry::likes( $uid , $element , $group )->getParticipants( false );

		// Merge the list now
		$recipients		= array_merge( $recipients , $likers );

		// Get people who are part of the comments
		$comments		= Foundry::comments( $uid , $element , $group );
		$recipients 	= array_merge( $recipients , $comments->getParticipants( array() , false ) );

		// Notify the actor of the story that someone likes this.
		$recipients[]	= $photo->uid;

		// Ensure that recipients are unique now.
		$recipients		= array_unique( $recipients );

		// Reset the indexes
		$recipients 	= array_values( $recipients );

		if( $recipients )
		{
			// Remove the current user from the list since it doesn't make sense to notify himself
			for( $i = 0; $i < count( $recipients ); $i++ )
			{
				if( $recipients[ $i ] == $likes->created_by )
				{
					unset( $recipients[ $i ] );
				}
			}
		}

		// Reset the indexes
		$recipients 	= array_values( $recipients );

		// Stop if there's nothing to process
		if( !$recipients )
		{
			return;
		}

		// Load up recipients
		$recipients 	= Foundry::user( $recipients );

		// Get the author of the item
		$poster 	= Foundry::user( $likes->created_by );
		$photoOwner	= Foundry::user( $photo->uid );

		foreach( $recipients as $recipient )
		{
			// Determine if this user is involved in this or the user created this item.
			$mailParams 	= array();

			$mailTemplate 	= $recipient->id == $photo->uid ? 'new.likes.owner' : 'new.likes.involved';
			$emailTitle 	= $recipient->id == $photo->uid ? JText::sprintf( 'COM_EASYSOCIAL_EMAILS_LIKES_PHOTO_OWNER_EMAIL_TITLE' , $poster->getName() ) : JText::sprintf( 'COM_EASYSOCIAL_EMAILS_LIKES_PHOTO_INVOLVED_EMAIL_TITLE' , $poster->getName() , $photoOwner->getName() );

			$mailParams[ 'posterName' ]		= $poster->getName();
			$mailParams[ 'posterAvatar' ]	= $poster->getAvatar( SOCIAL_AVATAR_LARGE );
			$mailParams[ 'posterLink' ]		= $poster->getPermalink( true, true );
			$mailParams[ 'permalink' ]		= $photo->getPermalink( false, true );
			$mailParams[ 'photoThumbnail' ]	= $photo->getSource();
			$mailParams[ 'photoPermalink' ]	= $photo->getPermalink( false, true );
			$mailParams[ 'photoTitle' ]		= $photo->get( 'title' );
			$mailParams[ 'photoOwner' ]		= $photoOwner->getName();

			$systemOptions 	= array( 'type' => SOCIAL_TYPE_LIKES ,'context_type' => $element , 'url' => $photo->getPermalink( false ) ,  'actor_id' => $likes->created_by , 'uid' => $uid , 'aggregate' => true , 'image' => $photo->getSource() );

			// Add new notification item
			$state 			= Foundry::notify(	'photos.likes' ,  array( $recipient->id ) , array( 'title' => $emailTitle , 'params' => $mailParams , 'template' => 'site/photos/' . $mailTemplate ), $systemOptions );
		}
	}

	/**
	 * Triggered when a comment save occurs
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialTableComments	The comment object
	 * @return
	 */
	public function onAfterCommentSave( &$comment )
	{
		$element 	= explode( '.' , $comment->element );
		$element 	= $element[ 0 ];

		// We don't want to modify anything if this wasn't a comment for the photo
		if( $element != 'photos' )
		{
			return;
		}

		// Get a list of users that are tagged in this photo.

		// Determine the owner of this commented item.
		$photo 		= Foundry::table( 'Photo' );
		$photo->load( $comment->uid );

		// @points: photos.comment.add
		// Assign points to the user for posting a new comment
		$photo->assignPoints( 'photos.comment.add' , $comment->created_by );

		// Default recipients
		$recipients = array();

		// Only get tags that are relevant to other users
		$tags 		= $photo->getTags( true );

		if( $tags )
		{
			foreach( $tags as $tag )
			{
				$recipients[]	= $tag->uid;
			}
		}

		// Add the owner of the photo if it's not him that is commenting on the item.
		if( $comment->created_by != $photo->uid )
		{
			$recipients 	= array_merge( $recipients , array( $photo->uid ) );
		}

		// Unique the list of items now
		$recipients 	= array_unique( $recipients );

		// Remove myself from the recipients
		if( $recipients )
		{
			for( $i = 0; $i < count( $recipients ); $i++ )
			{
				if( $recipients[ $i ] == $comment->created_by )
				{
					unset( $recipients[ $i ] );
				}
			}
		}

		// If there's no recipients, forget about it.
		if( !$recipients )
		{
			return;
		}

		// Re-index the array again
		$recipients 	= array_values( $recipients );

		$recipients 	= Foundry::user( $recipients );

		// Get the poster of the comment
		$poster 		= Foundry::user( $comment->created_by );

		// Get the owner of the photo
		$photoOwner		= Foundry::user( $photo->uid );

		foreach( $recipients as $recipient )
		{
			$mailParams 	= array();

			$mailTemplate 	= $recipient->id == $photo->uid ? 'new.comment.owner' : 'new.comment.involved';
			$emailTitle 	= $recipient->id == $photo->uid ? JText::sprintf( 'COM_EASYSOCIAL_EMAILS_COMMENT_OWNER_PHOTO_TITLE' , $poster->getName() ) : JText::sprintf( 'COM_EASYSOCIAL_EMAILS_COMMENT_INVOLVED_PHOTO_TITLE' , $poster->getName() );

			$mailParams[ 'posterName' ]		= $poster->getName();
			$mailParams[ 'posterAvatar' ]	= $poster->getAvatar( SOCIAL_AVATAR_LARGE );
			$mailParams[ 'posterLink' ]		= $poster->getPermalink( true, true );
			$mailParams[ 'comment' ]		= $comment->comment;
			$mailParams[ 'permalink' ]		= $photo->getPermalink( false, true );
			$mailParams[ 'photoThumbnail' ]	= $photo->getSource();
			$mailParams[ 'photoPermalink' ]	= $photo->getPermalink( false, true );
			$mailParams[ 'photoTitle' ]		= $photo->get( 'title' );
			$mailParams[ 'photoOwner' ]		= $photoOwner->getName();

			$systemOptions 	= array(
									'type'			=> SOCIAL_TYPE_COMMENTS,
									'title' 		=> $comment->comment,
									'context_type'	=> $element ,
									'url' 			=> $photo->getPermalink( false ),
									'actor_id'	 	=> $comment->created_by ,
									'uid' 			=> $comment->uid ,
									'aggregate' 	=> true,
									'image'			=> $photo->getSource()
								);

			// Determine if this user is involved in this or the user created this ite
			$state 	= Foundry::notify( 'photos.comment.add' , array( $recipient ),  array( 'title' => $emailTitle , 'params' => $mailParams , 'template' => 'site/photos/' . $mailTemplate , ''), $systemOptions );

		}
	}

	/**
	 * Renders the notification item
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onNotificationLoad( $item )
	{
		if( $item->context_type != SOCIAL_TYPE_PHOTO )
		{
			return;
		}

		// Load up the photos table based on the uid
		$photo 	= Foundry::table( 'Photo' );
		$photo->load( $item->uid );

		// Get a list of tagged users
		$tags 			= $photo->getTags( true );
		$taggedUsers	= array();

		if( $tags )
		{
			foreach( $tags as $tag )
			{
				$taggedUsers[]	= $tag->uid;
			}
		}

		// Default list of users
		$users 		= array();

		// Process like notifications
		if( $item->type == SOCIAL_TYPE_LIKES )
		{
			// Load up likes model
			$model 			= Foundry::model( 'Likes' );

			// Get list of users who liked this story.
			$users 			= $model->getLikerIds( $item->uid , 'photos.user' );

			// Exclude myself from the list of users.
			$index 			= array_search( Foundry::user()->id , $users );

			if( $index !== false )
			{
				unset( $users[ $index ] );

				$users 	= array_values( $users );
			}

			// Add the author of the photo as the recipient
			if( $item->actor_id != $photo->uid )
			{
				$users[]	= $photo->uid;
			}

			// Ensure that the values are unique
			$users		= array_unique( $users );
			$users 		= array_values( $users );

			// Exclude the stream creator and the current logged in user from the list.
			if( $users )
			{
				for($i = 0; $i < count( $users ); $i++ )
				{
					if( $users[ $i ] == Foundry::user()->id )
					{
						unset( $users[ $i ] );
					}
				}

				$users 	= array_values( $users );
			}

			// We need to determine if this is singular or not
			$usePlural	 	= false;
			$total 			= count( $users );

			// Singular items
			if( $total == 1 )
			{
				$user 	= Foundry::user( $users[ 0 ] );

				if( !$user->isViewer() )
				{
					$usePlural 	= true;
				}
			}
			else
			{
				$usePlural 	= false;
			}

			// Convert the names to stream-ish
			$names 			= Foundry::string()->namesToStream( $users , false , 2 , true , false );
			$usePlural 		= false;

			// We need to generate the notification message differently for the author of the item and the recipients of the item.
			if( $photo->uid == $item->target_id && $item->target_type == SOCIAL_TYPE_USER )
			{
				// This is for 3rd party viewers
				if( $usePlural )
				{
					$item->title 	= JText::sprintf( 'APP_GROUP_PHOTOS_LIKES_OWNER_PHOTO_PLURAL' , $names );
				}
				else
				{
					$item->title 	= JText::sprintf( 'APP_GROUP_PHOTOS_LIKES_OWNER_PHOTO' , $names );
				}


				return $item;
			}

			// This is for 3rd party viewers
			if( $usePlural )
			{
				$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_LIKES_USER_PHOTO_PLURAL" , $names , Foundry::user( $photo->uid )->getName() );
			}
			else
			{
				$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_LIKES_USER_PHOTO" , $names , Foundry::user( $photo->uid )->getName() );
			}

			// This is for 3rd party viewers


			return $item;
		}

		// Process comment notifications
		if( $item->type == SOCIAL_TYPE_COMMENTS )
		{
			// Get a list of comment participants
			$model 		= Foundry::model( 'Comments' );
			$users 		= $model->getParticipants( $item->uid , 'photos.user' );

			// Include the actor of the stream item as the recipient
			$users 		= array_merge( array( $item->actor_id ) , $users );

			// Ensure that the values are unique
			$users		= array_unique( $users );
			$users 		= array_values( $users );

			// Exclude myself from the list of users.
			$index 		= array_search( Foundry::user()->id , $users );

			if( $index !== false )
			{
				unset( $users[ $index ] );

				$users 	= array_values( $users );
			}

			// Only show the content when there is only 1 item
			if( count( $users ) == 1 )
			{
				// We want to format the content so that it's suitable to display in the notifications area.
				$content 		= $item->title;
				$content 		= JString::substr( strip_tags( $content ) , 0 , 30 );

				if( JString::strlen( $item->title ) > 30 )
				{
					$content .= JText::_( 'COM_EASYSOCIAL_ELLIPSES' );
				}
			}
			else
			{
				$content 	= '';
			}

			// Convert the names to stream-ish
			$names 			= Foundry::string()->namesToStream( $users , false , 3 , true , false );

			// We need to generate the notification message differently for the author of the item and the recipients of the item.
			if( $photo->uid == $item->target_id && $item->target_type == SOCIAL_TYPE_USER )
			{
				if( $content )
				{
					$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_YOUR_PHOTO_CONTENT" , $names , $content );
				}
				else
				{
					$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_YOUR_PHOTO" , $names );
				}

				return $item;
			}

			// We need to generate the notification message differently for users that are tagged in the photo
			if( in_array( $item->target_id , $taggedUsers ) && $item->target_type == SOCIAL_TYPE_USER )
			{
				if( $content )
				{
					$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_PHOTO_YOU_ARE_TAGGED_CONTENT" , $names , $content );
				}
				else
				{
					$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_PHOTO_YOU_ARE_TAGGED" , $names );
				}

				return $item;
			}

			// This is for 3rd party viewers
			if( $content )
			{
				$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_PHOTO_INVOLVING_YOU_CONTENT" , $names , Foundry::user( $photo->uid )->getName() , $content );
			}
			else
			{
				$item->title 	= JText::sprintf( "APP_GROUP_PHOTOS_COMMENTS_PHOTO_INVOLVING_YOU" , $names , Foundry::user( $photo->uid )->getName() );
			}


			return $item;
		}
	}
}
