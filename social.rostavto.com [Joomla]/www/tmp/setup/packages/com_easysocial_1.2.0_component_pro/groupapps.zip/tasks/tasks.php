<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

// Include apps interface.
Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Tasks application for Groups in EasySocial.
 *
 * @since	1.2
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialGroupAppTasks extends SocialAppItem
{
	/**
	 * Processes a saved story.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onBeforeStorySave( &$streamTemplate , &$streamItem , &$template )
	{
		// Get the link information from the request
		$items 			= JRequest::getVar( 'tasks_items' , '' );
		$milestoneId 	= JRequest::getInt( 'tasks_milestone' , '' );
		$milestone 		= Foundry::table( 'Milestone' );
		$milestone->load( $milestoneId );

		if( !$items || empty( $items ) || !$milestone->id )
		{
			return;
		}

		// Get the group object
		$group 				= Foundry::group( $streamTemplate->cluster_id );

		// Set the verb of the stream
		$streamTemplate->setVerb( 'createTask' );

		$tasks	= array();

		// We need to store the tasks item now.
		foreach( $items as $item )
		{
			if( !$item )
			{
				continue;
			}

			$task 				= Foundry::table( 'task' );
			$task->title		= $item;
			$task->state 		= SOCIAL_STATE_PUBLISHED;
			$task->uid 			= $group->id;
			$task->type 		= SOCIAL_TYPE_GROUP;
			$task->user_id 		= Foundry::user()->id;
			$task->milestone_id = $milestone->id;
			$task->store();

			$tasks[]	= $task;
		}

		$params 	= Foundry::registry();
		$params->set( 'tasks' 		, $tasks );
		$params->set( 'group'		, $group );
		$params->set( 'milestone' 	, $milestone );

		$streamTemplate->setParams( $params );

		return true;
	}

	/**
	 * Prepares what should appear in the story form.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onPrepareStoryPanel( $story )
	{
		$params 		= $this->getApp()->getParams();

		if( !$params->get( 'story_form' , true ) )
		{
			return;
		}

		// Get the group data
		$group 		= Foundry::group( $story->cluster );

		$tasks 		= Foundry::model( 'Tasks' );
		$milestones	= $tasks->getMilestones( $group->id , SOCIAL_TYPE_GROUP );

		// If there is no milestone, do not need to display the tasks embed in the story form.
		if( !$milestones )
		{
			return false;
		}

		// Create plugin object
		$plugin		= $story->createPlugin( 'tasks' , 'panel' );

		// We need to attach the button to the story panel
		$theme 		= Foundry::themes();
		$theme->set( 'milestones' , $milestones );

		$plugin->button->html 	= $theme->output('themes:/apps/group/tasks/story/panel.button');
		$plugin->content->html 	= $theme->output( 'themes:/apps/group/tasks/story/panel.content' );

		// Attachment script
		$script				= Foundry::get('Script');
		$plugin->script		= $script->output('apps:/group/tasks/story');

		return $plugin;
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'tasks' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}

	/**
	 * Triggered when the prepare stream is rendered
	 *
	 * @since	1.2
	 * @access	public
	 * @param	string
	 * @return
	 */
	public function onPrepareStream( SocialStreamItem &$item , $includePrivacy = true )
	{
		if( $item->context != 'tasks')
		{
			return;
		}

		$item->display	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#658ea6';
		$item->fonticon = 'ies-checkbox-checked';
		$item->label 	= JText::_( 'APP_GROUPS_TASKS_STREAM_TOOLTIP' );

		// Get the verb
		$verb 	= $item->verb;

		if( $verb == 'createTask' )
		{
			$this->prepareCreatedTaskStream( $item , $includePrivacy );
		}

		if( $verb == 'createMilestone' )
		{
			$this->prepareCreateMilestoneStream( $item , $includePrivacy );
		}
	}

	public function prepareCreatedTaskStream( SocialStreamItem $streamItem , $includePrivacy = true )
	{
		$params 	= Foundry::registry( $streamItem->params );

		// Get the tasks available from the cached data
		$items 		= $params->get( 'tasks' );
		$tasks 		= array();

		foreach( $items as $item )
		{
			$task 	= Foundry::table( 'Task' );
			$task->load( $item->id );

			$tasks[]	= $task;
		}

		// Get the milestone
		$milestone 	= Foundry::table( 'Milestone' );
		$milestone->bind( $params->get( 'milestone' ) );

		// Get the group data
		Foundry::load( 'group' );
		$group 		= new SocialGroup();
		$group->bind( $params->get( 'group' ) );

		$app 		= $this->getApp();
		$permalink	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $app->id , 'milestoneId' => $milestone->id ) );

		$this->set( 'permalink' , $permalink );
		$this->set( 'stream'	, $streamItem );
		$this->set( 'milestone', $milestone );
		$this->set( 'total'	, count( $tasks ) );
		$this->set( 'actor'	, $streamItem->actor );
		$this->set( 'group' , $group );
		$this->set( 'tasks' , $tasks );

		$streamItem->title	= parent::display( 'streams/create.task.title' );
		$streamItem->content	= parent::display( 'streams/create.task.content' );
	}

	public function prepareCreateMilestoneStream( SocialStreamItem $item , $includePrivacy = true )
	{
		$params 	= Foundry::registry( $item->params );

		$milestone	= Foundry::table( 'Milestone' );
		$milestone->bind( $params->get( 'milestone' ) );

		// Get the group data
		Foundry::load( 'group' );
		$group 		= new SocialGroup();
		$group->bind( $params->get( 'group' ) );

		// Get the actor
		$actor 		= $item->actor;
		$app 		= $this->getApp();
		$permalink	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $app->id , 'milestoneId' => $milestone->id ) );

		$this->set( 'permalink'	, $permalink );
		$this->set( 'milestone' , $milestone );
		$this->set( 'actor'		, $actor );
		$this->set( 'group'		, $group );

		$item->title 	= parent::display( 'streams/create.milestone.title' );
		$item->content 	= parent::display( 'streams/create.milestone.content' );
	}
}
