
EasySocial.require()
.script( 'site/groups/apps/tasks' )
.done(function($)
{
	$( '[data-group-tasks-milestones]' ).implement( EasySocial.Controller.Groups.Apps.Tasks.Milestones.Browse )
});