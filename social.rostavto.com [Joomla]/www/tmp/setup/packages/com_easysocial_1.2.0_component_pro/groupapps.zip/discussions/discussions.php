<?php
/**
* @package		%PACKAGE%
* @subpackge	%SUBPACKAGE%
* @copyright	Copyright (C) 2010 - 2012 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );

Foundry::import( 'admin:/includes/apps/apps' );

/**
 * Discussions app for EasySocial Group
 *
 * @since	1.2
 * @author	Mark Lee <mark@stackideas.com>
 */
class SocialGroupAppDiscussions extends SocialAppItem
{
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Performs clean up when a group is deleted
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialGroup		The group object
	 */
	public function onBeforeDelete( &$group )
	{
		// Delete all discussions from a group
		$model 	= Foundry::model( 'Discussions' );
		$model->delete( $group->id , SOCIAL_TYPE_GROUP );
	}

	/**
	 * Triggered to validate the stream item whether should put the item as valid count or not.
	 *
	 * @since	1.2
	 * @access	public
	 * @param	jos_social_stream, boolean
	 * @return  0 or 1
	 */
	public function onStreamCountValidation( &$item, $includePrivacy = true )
	{
		// If this is not it's context, we don't want to do anything here.
		if( $item->context_type != 'discussions' )
		{
			return false;
		}

		// if this is a cluster stream, let check if user can view this stream or not.
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' ) );

		if( !$group )
		{
			return;
		}

		$item->cnt = 1;

		if( $group->type != SOCIAL_GROUPS_PUBLIC_TYPE )
		{
			if( !$group->isMember( Foundry::user()->id ) )
			{
				$item->cnt = 0;
			}
		}

		return true;
	}


	/**
	 * Prepares the stream item
	 *
	 * @since	1.0
	 * @access	public
	 * @param	SocialStreamItem	The stream object.
	 * @param	bool				Determines if we should respect the privacy
	 */
	public function onPrepareStream( SocialStreamItem &$item, $includePrivacy = true )
	{
		if( $item->context != 'discussions' )
		{
			return;
		}

		// Define standard stream looks
		$item->display 	= SOCIAL_STREAM_DISPLAY_FULL;
		$item->color 	= '#69b598';
		$item->fonticon	= 'ies-comments';
		$item->label	= JText::_( 'COM_EASYSOCIAL_STREAM_CONTEXT_TITLE_DISCUSSIONS_TOOLTIP' );

		$params 	= $this->getApp()->getParams();

		if( $params->get( 'stream_' . $item->verb , true ) == false )
		{
			return;
		}

		if( $item->verb == 'create' )
		{
			$this->prepareCreateDiscussionStream( $item );
		}

		if( $item->verb == 'reply' )
		{
			$this->prepareReplyStream( $item );
		}

		if( $item->verb == 'answered' )
		{
			$this->prepareAnsweredStream( $item );
		}

		if( $item->verb == 'lock' )
		{
			$this->prepareLockedStream( $item );
		}
	}

	/**
	 * Prepares the stream item for new discussion creation
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareCreateDiscussionStream( &$item )
	{
		// Get the context params
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' )->id );

		$discussion	= Foundry::table( 'Discussion' );
		$discussion->bind( $params->get( 'discussion' ) );

		$permalink 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $this->getApp()->id , 'discussionId' => $discussion->id ) , false );

		$content 	= $this->formatContent( $discussion );

		$this->set( 'actor'		, $item->actor );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'discussion', $discussion );
		$this->set( 'content'	, $content );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/create.title' );
		$item->content 	= parent::display( 'streams/create.content' );
	}

	/**
	 * Prepares the stream item for new discussion creation
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareReplyStream( &$item )
	{
		// Get the context params
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' )->id );

		$discussion = Foundry::table( 'Discussion' );
		$discussion->bind( $params->get( 'discussion' ) );

		$reply	= Foundry::table( 'Discussion' );
		$reply->bind( $params->get( 'reply' ) );

		$permalink 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $this->getApp()->id , 'discussionId' => $discussion->id ) , false );

		$content 	= $this->formatContent( $reply );

		$this->set( 'actor'		, $item->actor );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'discussion', $discussion );
		$this->set( 'reply'		, $reply );
		$this->set( 'content'	, $content );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/reply.title' );
		$item->content 	= parent::display( 'streams/reply.content' );
	}

	/**
	 * Prepares the stream item for new discussion creation
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareAnsweredStream( &$item )
	{
		// Get the context params
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' )->id );

		$discussion = Foundry::table( 'Discussion' );
		$discussion->bind( $params->get( 'discussion' ) );

		$reply	= Foundry::table( 'Discussion' );
		$reply->bind( $params->get( 'reply' ) );

		$permalink 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $this->getApp()->id , 'discussionId' => $discussion->id ) , false );

		$content 	= $this->formatContent( $reply );

		// Get the reply author
		$reply->author	= Foundry::user( $reply->created_by );

		$this->set( 'actor'		, $item->actor );
		$this->set( 'permalink'	, $permalink );
		$this->set( 'discussion', $discussion );
		$this->set( 'reply'		, $reply );
		$this->set( 'content'	, $content );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/answered.title' );
		$item->content 	= parent::display( 'streams/answered.content' );
	}

	/**
	 * Prepares the stream item for new discussion creation
	 *
	 * @since	1.2
	 * @access	public
	 * @param	SocialStreamItem	The stream item.
	 * @return
	 */
	private function prepareLockedStream( &$item )
	{
		// Get the context params
		$params 	= Foundry::registry( $item->params );
		$group 		= Foundry::group( $params->get( 'group' )->id );

		$discussion = Foundry::table( 'Discussion' );
		$discussion->bind( $params->get( 'discussion' ) );

		$permalink 	= FRoute::apps( array( 'layout' => 'canvas' , 'customView' => 'item' , 'uid' => $group->getAlias() , 'type' => SOCIAL_TYPE_GROUP , 'id' => $this->getApp()->id , 'discussionId' => $discussion->id ) , false );

		$item->display 	= SOCIAL_STREAM_DISPLAY_MINI;

		$this->set( 'permalink'	, $permalink );
		$this->set( 'actor'		, $item->actor );
		$this->set( 'discussion', $discussion );

		// Load up the contents now.
		$item->title 	= parent::display( 'streams/locked.title' );
	}

	public function formatContent( $discussion )
	{
		$bbcode 	= Foundry::bbcode();
		$content 	= $bbcode->parse( $discussion->content );

		// Remove [file] from contents
		$content 	= $discussion->removeFiles( $content );

		return $content;
	}
}
