<a href="javascript:void(0);" class="ico-dzemanta float-l prel ui-togmenu zemantaButton" togbox="zemantaPanel">
	<b><?php echo JText::_( 'COM_EASYBLOG_DASHBOARD_ZEMANTA' ); ?></b>
	<span class="ui-toolnote">
		<i></i>
		<b><?php echo JText::_( 'COM_EASYBLOG_DASHBOARD_EDITOR_INSERT_ZEMANTA' ); ?></b>
		<span><?php echo JText::_('COM_EASYBLOG_DASHBOARD_EDITOR_INSERT_ZEMANTA_TIPS'); ?></span>
	</span>
</a>
