<a href="javascript:void(0);" class="ico-dglobe float-l prel mrs ui-togmenu olderPosts" togbox="olderPosts">
	<b><?php echo JText::_('COM_EASYBLOG_DASHBOARD_EDITOR_OLDER_POSTS'); ?></b>
	<span class="ui-toolnote">
		<i></i>
		<b><?php echo JText::_('COM_EASYBLOG_DASHBOARD_EDITOR_OLDER_POSTS'); ?></b>
		<span><?php echo JText::_('COM_EASYBLOG_DASHBOARD_EDITOR_INSERT_LINK_ADD_TO_CONTENT_TIPS'); ?></span>
	</span>
</a>
