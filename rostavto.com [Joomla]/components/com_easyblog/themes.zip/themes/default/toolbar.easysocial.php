<?php
/**
* @package 		EasyBlog
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license 		Proprietary Use License
* @website 		http://stackideas.com
* @author 		StackIdeas
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<div id="es-wrap">
	<?php echo $output; ?>
</div>