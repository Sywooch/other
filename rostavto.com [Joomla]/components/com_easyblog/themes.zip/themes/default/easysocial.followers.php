<?php
/**
* @package 		EasyBlog
* @copyright	Copyright (C) 2010 - 2013 Stack Ideas Sdn Bhd. All rights reserved.
* @license 		Proprietary Use License http://stackideas.com/licensing.html
* @author 		Stack Ideas Sdn Bhd
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<a href="javascript:void(0);" class="author-friend" data-es-followers-follow data-es-followers-id="<?php echo $id;?>"><span><?php echo JText::_( 'COM_EASYBLOG_FOLLOW_AUTHOR' ); ?></span></a>